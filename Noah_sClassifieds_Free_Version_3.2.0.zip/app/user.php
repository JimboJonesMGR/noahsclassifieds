<?php
defined('_NOAH') or die('Restricted access');
$user_typ=
    array(
        "attributes"=>array(
            "id"=>array(
                "type"=>"INT",
                "min" =>"1",
                "create_form: form invisible",
                "login_form: form invisible",
                "remind_password_form: form invisible",
                "form hidden"
            ),
            "name"=>array(
                "type"=>"VARCHAR",
                "text",
                "max" =>"32",
                "min" =>"1",
                "mandatory",
                "detailslink",
                "remind_password_form: form invisible",
            ),
            "email"=>array(
                "type"=>"VARCHAR",
                "text",
                "max" =>"64",
                "min" =>"1",
            ),
            "changePassword"=>array(
                "type"=>"INT",
                "section",
                "no column",
                "remind_password_form: form invisible",
                "create_form: form invisible",
                "login_form: form invisible",
            ),
            "password"=>array(
                "type"=>"VARCHAR",
                "max" =>"32",
                "remind_password_form: form invisible",
                "create_form: form invisible",
                "password"
            ),
            "passwordCopy"=>array(
                "type"=>"VARCHAR",
                "max" =>"32",
                "password",
                "remind_password_form: form invisible",
                "login_form: form invisible",
                "create_form: form invisible",
                "no column"
            ),
            "newPassword"=>array(
                "type"=>"VARCHAR",
                "max" =>"32",
                "default"=>"",
                "password",
                "form invisible",
            ),
            "rememberPassword"=>array(
                "type"  =>"INT",
                "bool",
                "default"=>"0",
                "remind_password_form: form invisible",
                "create_form: form invisible",
            ),
            "isAdm"=>array(
                "type"  =>"INT",
                "default"=>"0",
                "form invisible",
            ),
            "creationtime"=>array(
                "type"=>"DATETIME",
                "form invisible",
            ),
            "lastClickTime"=>array(
                "type"=>"DATETIME",
                "prototype"=>"date",
                "form invisible",
            ),
            "active"=>array(
                "type"  =>"INT",
                "default"=>"0",
                "form invisible",
            ),
            "captchaField"=>array(
                "type"=>"VARCHAR",
                "conditions"=>array("\$this->hasCaptchaInForm()"=>"text"),
                "max" =>"250",
                "length"=>10,
                "no column",
            ),
            "remindPasswordLink"=>array(
                "type"=>"INT",
                "no column",
                "txtsection"
            ),
            "favorities"=>array(
                "type"=>"TEXT",
                "form invisible",
            ),
            "viewAdsLink"=>array(
                "type"=>"INT",
                "no column",
                "form invisible",
            )
        ),
        "primary_key"=>"id",
        "unique_keys"=>"name",
        "delete_confirm"=>"name",
        "sort_criteria_attr"=>"name",
        "sort_criteria_dir"=>"a",
        "detailsTemplate"=>"item_details.tpl.php",
        "detailsPresentationClassName"=>"ItemDetailsPresentation",
    );

class User extends CustomFieldContainer
{
   
function getCustomFieldClass() { return "userfield"; }

function getPicDir() { return USER_PIC_DIR; }
function getUploadDir() { return USER_UPLOAD_DIR; }

function getUniqueAttr()
{
    global $emailAccount;
    return $emailAccount ? "email" : "name";
}

function getUniqueValue()
{
    return isset($this->{$this->getUniqueAttr()}) ? $this->{$this->getUniqueAttr()} : null;
}

function setUniqueValue($value)
{
    return $this->{$this->getUniqueAttr()} = $value;
}

function hasObjectRights(&$hasRight, $method, $giveError=FALSE)
{
    global $gorumrecognised, $gorumuser;
    
    hasAdminRights($isAdm);
    $hasRight->generalRight = TRUE;
    if( $method=="login" || $method=="logout" || $method=="remind_password" )  $hasRight->objectRight=TRUE;
    elseif( $method=="delete" )  $hasRight->objectRight=$isAdm;
    elseif( $method=="load" || $method=="create" )  $hasRight->objectRight=TRUE;
    elseif( $method=="modify" || $method=="change_password" )  
    {
        $hasRight->objectRight= $isAdm || ($gorumrecognised && @$this->id==$gorumuser->id);
    }
    elseif( $method="remove_favorities" || $method=="add_favorities" ) $hasRight->objectRight=TRUE;  
    else $hasRight->objectRight=FALSE;  
    if( !$hasRight->objectRight && $giveError ) handleErrorPerm(__FILE__,__LINE__);
}

function getFields()
{
    if( !$this->fields ) 
    {
        G::load($this->fields, "SELECT * FROM @userfield WHERE cid=0 AND isCommon=0 ORDER BY sortId ASC");
    }
    return $this->fields;
}

function loginForm($elementName="")
{
    global $gorumuser, $gorumauthlevel, $user_typ, $lll;

    if( !Roll::isPreviousFormSubmitInvalid() )
    {
        $this->password="";
        if( $gorumauthlevel<=Loginlib_GuestLevel ) $this->rememberPassword = TRUE;
        elseif( $gorumauthlevel==Loginlib_BasicLevel )
        {
            // Ha egy initial password emailben kattintanak ra a linkre,
            // akkor a $this->name ki lesz toltve, kulonben pedig az
            // azonositas soran megallapitott juzernevet kell a Name
            // mezoben megjeleniteni
            if( $this->getUniqueValue()==null ) $this->setUniqueValue($gorumuser->getUniqueValue());
            $this->rememberPassword = FALSE;
        }
        else return; // nagyobb egyenlo, mint low level
    }
    $ctrl =& new AppController("user/remind_password_form");
    $lll["remindPasswordLink"] = $ctrl->generAnchor($lll["remind_me_pw"]);
    $this->activateVariableFields();
    $this->generForm($elementName);
}

function remindPasswordForm($elementName="")
{
    $this->activateVariableFields();
    $this->generForm($elementName);
}

function modifyForm($elementName="")
{
    global $gorumroll, $user_typ, $emailAccount, $gorumuser;

    $this->id = $gorumroll->rollid ? $gorumroll->rollid : $gorumuser->id;
    hasAdminRights( $isAdm );
    $this->hasObjectRights($hasRight, "modify", TRUE);
    $this->activateVariableFields();
    $this->initClassVars();
    if( !Roll::isPreviousFormSubmitInvalid() )
    {
        $ret = $this->load();
        if( $ret ) handleErrorNotFound($this,__FILE__,__LINE__);
    }
    if( !$isAdm && !$emailAccount ) // az emailt csak az adm valtoztathatja meg
    {
        $user_typ["attributes"]["email"][]="modify_form: form invisible";
    }
    // A password mezok kezdetben mindig uresek:
    $this->password = $this->passwordCopy = "";
    $this->generForm($elementName);
}

function modify()
{
    global $cookiePath, $gorumuser;
    
    $this->activateVariableFields();
    $this->initClassVars();
    LocationHistory::savePost($this);
    if( !$this->validModify() ) return;
    if( $this->password )
    {
        $this->password = getPassword($this->password);
    }
    else unset($this->password);
    parent::modify();
    if( !Roll::isFormInvalid() )
    {
        $this->storeAttachment();
        // Ha a sajat passwordjet modositja:
        if( $this->id==$gorumuser->id && !empty($this->password) )
        {
            setcookie("usrPassword", $this->password, Loginlib_ExpirationDate, $cookiePath);
            Roll::setInfoText("passwordModified");
        }
    }
}

function validModify()
{
    global $minPasswordLength, $siteDemo;
    
    if( $siteDemo )
    {
        Roll::setInfoText("This operation is not permitted in the demo.");
        return;
    }
    if( $this->password )
    {
        if( $this->password!=$this->passwordCopy )
        {
            return Roll::setFormInvalid("mistypedPassword");
        }
        elseif( strlen($this->password)<$minPasswordLength )
        {
            return Roll::setFormInvalid("passwordTooShort", $minPasswordLength);
        }
    }
    return TRUE;
}

function createForm($elementName="")
{
    global $gorumrecognised;

    hasAdminRights( $isAdm );
    if( $gorumrecognised && !$isAdm )
    {
        Roll::setInfoText("cantRegisterUntilLoggedIn");
    }
    else 
    {
        $this->activateVariableFields();
        $this->initClassVars();
        parent::createForm($elementName);
    }
}

function create()
{
    global $gorumuser, $gorumauthlevel;

    $this->activateVariableFields();
    LocationHistory::resetPost();
    $this->initClassVars();
    LocationHistory::savePost($this);
    if( !$this->validRegistration() ) return;
    
    unset($this->isAdm);
    $this->active=FALSE; // Majd az elso bejelentkezes utan lesz true
    $plainPassword = $this->generatePassword();
    $this->setDefaultsOfFieldsThatDontAppearInForm();
    if( $gorumauthlevel==Loginlib_GuestLevel )
    {
        // don't create a new user, only updating the current
        // nameless user with the newly registered username and
        // password:
        $this->id = $gorumuser->id;
        modify($this);
        if( Roll::isFormInvalid()) return;
    }
    else if( $gorumauthlevel==Loginlib_BasicLevel  || $gorumauthlevel==Loginlib_LowLevel )
    {
        generateRandomId( $randomId );
        $this->id = $randomId;
        create($this);
        if( Roll::isFormInvalid()) return;
    }
    $this->storeAttachment();
    $this->sendPassword( $plainPassword, Notification_initialPassword, "youWillGetAEmailCheckEmail" );
    return $plainPassword;
}

function validRegistration()
{
    global $gorumuser, $gorumauthlevel, $gorumrecognised;

    if( !$this->validateCaptcha() ) return FALSE;
    if( $gorumauthlevel==Loginlib_NewUser )  // nem tud kukizni
    {
        return Roll::setFormInvalid("cannotAcceptCookie");
    }
    if( $gorumrecognised && !$gorumuser->isAdm )
    {
        return Roll::setFormInvalid("cantRegisterUntilLoggedIn");
    }
    if( !preg_match('/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,6}$/i', $this->email) )
    {
        return Roll::setFormInvalid("invalidEmail");
    }
    if( $this->userExistsAlready() ) return FALSE;
    if( $this->checkMandatoryFileUpload() ) return FALSE;
    return TRUE;
}

// Stores an encoded password in $this->password and returns the plain password:
function generatePassword( $passwordField="password" )
{
    mt_srand((double)microtime()*1000000);
    $plainPassword = mt_rand(1000000, 10000000);
    settype($plainPassword, "string");
    $this->$passwordField = getPassword($plainPassword);
    return $plainPassword;
}

function userExistsAlready()
{
    $userCheck = new User;
    $userCheck->name = $this->name;
    if( !load($userCheck, array("name"))  )
    {
        return !Roll::setFormInvalid("userAllreadyExists");
    }
    $userCheck = new User;
    $userCheck->email = $this->email;
    if( !load($userCheck, array("email"))  )
    {
        return !Roll::setFormInvalid("userAllreadyExistsWithEmail");
    }
    return FALSE;
}

function sendPassword( $plainPassword, $notification, $infoTextLabel )
{
    $n = new Notification;
    $n->id = $notification;
    $n->load();
    $ctrl =& new AppController("user/login/$this->name---$plainPassword");
    $url = $ctrl->makeUrl(TRUE);
    $sp = new SendingParameters;
    $sp->to = $this->email;
    $sp->replyTo = $this->s->adminEmail;
    $n->send( $sp, $this->getUniqueValue(), $plainPassword, $url );
    Roll::setInfoText($infoTextLabel);
}

function remindPassword()
{
    if( !$this->validRemindPassword($users) ) return;
    foreach( $users as $user )
    {
        $newPassword = $user->generatePassword("newPassword");
        modify($user);
        $user->sendPassword( $newPassword, Notification_remindPassword, "remindmail_sent" );
    }
}

function validRemindPassword( &$users )
{
    if( !$this->email ) return Roll::setFormInvalid("mandatoryField","email");
    if( !G::load( $users, array("SELECT * FROM @user WHERE email=#this->email#", $this->email) ) )
    {
        return Roll::setFormInvalid("invalid_email");
    }
    return TRUE;
}

function hasCaptcha($postfix="")
{
    global $gorumroll;
    if( $gorumroll->method=="create$postfix" && 
        in_array(Settings_register, explode(",", $this->s->applyCaptcha))) return TRUE;
    if( $gorumroll->method=="login$postfix" && 
        in_array(Settings_login, explode(",", $this->s->applyCaptcha))) return TRUE;
    return FALSE;
}

function showListVal($attr, $format="")
{
    global $lll,$gorumroll;
    $s=FALSE;
    if( ($s=parent::showListVal($attr, $format))!==FALSE )
    {
        return $s;
    }
    if ($attr=="creationtime" || $attr=="lastClickTime")
    {
        if (isset($this->{$attr})) $s=$this->{$attr}->format();
        else $s=$lll["never"];
    }
    else if( $attr=="email" )
    {
        if( $this->{$attr} )
        {
            $m=htmlspecialchars($this->{$attr});
            $s="<a href='mailto:$m'>$m</a>";
        }
    }
    elseif( $attr=="viewAdsLink" )
    {
        $ctrl =& new AppController("item_my/list/$this->name");
        $s=$ctrl->generAnchor($lll["viewAds"]);
    }
    else $s=parent::showListVal($attr, "safetext");
    return $s;
}

function getListSelect()
{
    global $lll, $gorumroll, $gorumuser;
    
    if ($gorumroll->list=="user") $select = "SELECT n.* ".$this->getSpecialSortAttrs()." FROM @user AS n WHERE id!=name && isAdm=0";
    elseif ($gorumroll->list=="user_search") 
    {
        loadSQL($search = new Search, array("SELECT query FROM @search WHERE uid=#uid# AND name=''", $gorumuser->id));
        $select = $search->query;
    }
    CustomField::addCustomColumns("user");
    //echo("$select<br><br>");
    return $select;
}

function showDetailsTool()
{
    return "";
}

function showDetails($whereFields="", $withLoad=TRUE, $elementName="")
{
    $this->activateVariableFields();
    parent::showDetails($whereFields, $withLoad, $elementName);
}

function applyPurchaseActions( $orderId )
{
    // Legalabb ennyit meg kell tennunk akkor is, ha felulirjuk ezt a 
    // fuggvenyt, hogy elmentjuk a tranzakcio soran esetleg 
    // megvaltoztatott cim, nev, varos, stb adatokat:
    modify($this);
}

function delete()
{
    global $siteDemo;
    
    if( $siteDemo )
    {
        Roll::setInfoText("This operation is not permitted in the demo.");
        return;
    }
    parent::delete();
    G::load( $items, array("SELECT * FROM @item WHERE ownerId=#this->id#", $this->id) );
    foreach( $items as $item ) $item->delete("", "userDelete");    
}

// hozzaad es torol kedvenceket:
function manageFavorities($which)
{
    global $gorumuser, $gorumroll;
    
    if( !isset($gorumuser->favorities) ) 
    {
        Roll::setInfoText("cannotAcceptCookieFav");
    }
    else
    {
        if( $which=="add" )
        {
            if( $gorumuser->favorities ) $gorumuser->favorities.=",";
            $gorumuser->favorities.=$gorumroll->rollid;
            Roll::setInfoText("favAdded");
        }
        else
        {
            $gorumuser->favorities = preg_replace("{(,)?\\b$gorumroll->rollid\\b(?(1)|(,|$))}", "", $gorumuser->favorities);
            Roll::setInfoText("favRemoved");
        }
        executeQuery( "UPDATE @user SET favorities=#gorumuser->favorities# WHERE id=#gorumuser->id#", 
                      $gorumuser->favorities, $gorumuser->id );
    }
    $this->rollBackNum = 1;
}

function showFavoritiesTool($itemId)
{
    global $lll;
    if( !$this->s->favoritiesEnabled()) return "";
    if( !isset($this->favorities) ) $favorities=array();
    elseif( !is_array($this->favorities) ) $favorities = explode(",", $this->favorities );
    if( in_array($itemId, $favorities) )
    {
        $ctrl =& new AppController("user/remove_favorities/$itemId");
        return $ctrl->generAnchor($lll["removeFavorities"]);
    }
    else
    {
        $ctrl =& new AppController("user/add_favorities/$itemId");
        return $ctrl->generAnchor($lll["addFavorities"]);
    }
}

// azert kell felulirni, hogy a capchca validation ne legyen benne
function valid()
{
    parent::valid();
    if( !Roll::isFormInvalid() ) $this->validateAttributes();
}

function lowLevelLogin()
{
    global $gorumuser, $gorumroll;

    if( $firstLogin = strstr($gorumroll->rollid, "---") )
    {
        list( $this->name, $this->password) = explode("---", $gorumroll->rollid);
    }
    elseif( !$this->validateCaptcha() ) return;
    if( !$this->validLogin() ) return;
    // A regi usert es azokat a dolgokat, amiket o hozott letre,
    // de mar nem kellenek toroljuk:
    if( $gorumuser->name==$gorumuser->id && $this->id!=$gorumuser->id )
    {
        delete($gorumuser);
    }
    $this->setCookies();
    
    authenticate(TRUE); // Reauthenticate:
    Roll::setInfoText("greeting", htmlspecialchars($gorumuser->name));
    // az uj userhez rogton az uj settingek is kellenek:
    $init = new AppInit;
    $init->initializeUserSettings();
    $this->updateUserAfterLogin();
    hasAdminRights($isAdm);
    if( $isAdm ) $this->checkForUpdates();
    elseif( $firstLogin ) $this->nextAction =& new AppController("user/modify_form");
}

function validLogin()
{
    $user = new User;
    $user->setUniqueValue($this->getUniqueValue());
    if( load($user, array($this->getUniqueAttr())) || $user->id==$user->name ) Roll::setFormInvalid();
    else
    {
        if( getPassword($this->password)==$user->password ) $this->id = $user->id;
        elseif($user->newPassword) 
        {
            if( getPassword($this->password)==$user->newPassword )
            {
                executeQuery(array("UPDATE @user SET password='$user->newPassword', newPassword='' WHERE id=#id#", $user->id));
            }
            else Roll::setFormInvalid();
            $this->id = $user->id;
        }        
        else
        {
            Roll::setFormInvalid();
            $this->id = $user->id;
        }
    }
    if( Roll::isFormInvalid() ) Roll::setInfoText("loginInvalid");    
    return !Roll::isFormInvalid();
}

function setCookies()
{
    global $cookiePath;
    
    $_COOKIE["globalUserId"] = $_COOKIE["sessionUserId"] =$this->id;
    $_COOKIE["usrPassword"] = getPassword($this->password);
    setcookie("globalUserId", $this->id, Loginlib_ExpirationDate, $cookiePath);
    setcookie("sessionUserId", $this->id, 0, $cookiePath);
    setcookie("usrPassword", $_COOKIE["usrPassword"], Loginlib_ExpirationDate, $cookiePath);
}

function updateUserAfterLogin()
{
    global $gorumuser;
    
    // modositjuk a rememberPassword-ot, ha szukseges:
    if( !isset($this->rememberPassword) ) $this->rememberPassword=0;
    if( $this->rememberPassword!=$gorumuser->rememberPassword || !$gorumuser->active )
    {
        $gorumuser->rememberPassword = $this->rememberPassword;
        $gorumuser->active = 1;
        executeQuery("UPDATE @user SET rememberPassword=#rememberPassword#, active=#active# WHERE id=#id#",
                     $gorumuser->rememberPassword, $gorumuser->active, $gorumuser->id);
    }
}

function checkForUpdates()
{
    global $noahsHost, $noahsVersionCheckScript, $now, $siteDemo;

    if( $this->s->updateCheckInterval && !$siteDemo )
    {
        $globalStat = new GlobalStat;
        if( $globalStat->lastUpdateCheck->isEmpty() || $globalStat->lastUpdateCheck->getDayDiff()>=$this->s->updateCheckInterval )
        {
            $cc = new CheckConf;
            if( ($latestVersionInfo = $cc->getVersionInfo($noahsHost, "POST", $noahsVersionCheckScript, ""))===FALSE )
            {
                return; // connection error - we will try next time        
            }
            else
            {
                echo $latestVersionInfo;
                // sets $response and $latestVersion:
                $latestVersionInfo = explode("Version-Info:", $latestVersionInfo);
                eval($latestVersionInfo[1]);
                if( $latestVersion!=$globalStat->instver )
                {
                    $this->nextAction =& new AppController("checkconf/updates");
                }
                $globalStat->lastUpdateCheck = $now;
                modify($globalStat);
            }
        }
        
    }
}

function showDetailsMethods()
{
    global $lll,$gorumroll,$gorumuser,$chAdmAct;

    $s="";
    hasAdminRights($isAdm);
    if( $chAdmAct && $isAdm ) 
    {
        $ctrl =& new AppController();
        $ctrl->list = "user";
        $ctrl->method = "changeAdmStatus";
        $ctrl->id = $this->id;
        $ctrl->rollid = 0;
        saveInFrom($ctrl);
        $s.="<tr><td class='cell' colspan='2'>";
        if ($this->isAdm) $s.=$ctrl->generAnchor($lll["removeAdmRights"]);
        else $s.=$ctrl->generAnchor($lll["giveAdmRights"]);
        $s.="</td></tr>\n";
    }
    return $s;
}

function changeAdmStatus()
{
    hasAdminRights( $isAdm );
    if( !$isAdm ) handleErrorPerm(__FILE__,__LINE__);
    load($this);
    $this->isAdm = $this->isAdm ? FALSE : TRUE;
    modify($this);
    Roll::setInfoText("admstatchanged");
}

function showHtmlList($elementName="")
{
    $this->activateVariableFields();
    parent::showHtmlList($elementName);
}

function showNavBar($withLink=FALSE)
{
    global $gorumroll, $lll, $navBarSeparator;
    
    if( $gorumroll->method!="showdetails" ) return "";
    $s="";
    $ctrl =& new AppController("/");
    $s.=$ctrl->generAnchor($lll["home"]);
    $ctrl =& new AppController("user/list");
    $s.=$navBarSeparator . $ctrl->generAnchor($lll["users"]);
    $s.=$navBarSeparator . htmlspecialchars($this->name);
    return $s;
}

} // end class

function deleteInactiveGuests()
{
    global $deleteInactiveGuestsAfterDays, $deleteInactiveGuestsWithFavoritiesAfterDays, $deleteNonActivatedRegistrationsAfterDays;
    
    executeQuery("DELETE FROM @user WHERE id=name AND 
                  (lastClickTime < NOW() - INTERVAL $deleteInactiveGuestsWithFavoritiesAfterDays DAY OR
                   (favorities='' AND lastClickTime < NOW() - INTERVAL $deleteInactiveGuestsAfterDays DAY))");
    $whereCond = "u.id!=u.name AND u.active=0 AND ISNULL(i.id) AND 
                    ((lastClickTime!=0 AND lastClickTime < NOW() - INTERVAL $deleteNonActivatedRegistrationsAfterDays DAY) 
                    OR
                    (lastClickTime=0 AND u.creationtime < NOW() - INTERVAL $deleteNonActivatedRegistrationsAfterDays DAY))";
    // Csak azokat toroljuk, akiknek nincs hirdetesuk:                
    G::load( $users, "SELECT DISTINCT(u.id) FROM @user AS u LEFT JOIN @item AS i ON i.ownerId=u.id WHERE $whereCond" );
    foreach( $users as $u ) executeQuery("DELETE FROM @user WHERE id=$u->id");
}

function hasAdminRights( &$hasRight, $base="", $method="" )
{
    global $gorumuser, $gorumrecognised;
    if( function_exists("hasAdminRightsApp") ) {
        hasAdminRightsApp( $hasRight, $base, $method);
    }
    else $hasRight = ($gorumrecognised && !empty($gorumuser->isAdm));
    return ok;
}

?>
