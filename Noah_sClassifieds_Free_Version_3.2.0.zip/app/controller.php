<?php
defined('_NOAH') or die('Restricted access');

$allowedMethods = array_merge($allowedMethods, array(
    "recalculate"=>'$base->recalculateAllItemNums();',
    "prolong_expiration"=>'$base->prolongExpiration();',
    "approve"=>'$base->approve();',
    "remove_first_check"=>'$base->removeFirstCheck();',
    "payment_processed"=>'paymentProcessed();',
    "customer_return"=>'customerReturn();',
    "callback_failed"=>'callbackFailed();',
    "get"=>'$base->getFeed();',
    "get_dump"=>'$base->getDump();',
    "sortfield_form"=>'$base->sortFieldForm($elementName);',
    "sortfield"=>'$base->sortField();',
    "advanced_form"=>'$base->generForm($elementName);',
    "advanced"=>'$base->advancedOperations();',
    "organize_form"=>'$base->organizeForm($elementName);',
    "organize"=>'$base->organize();',
    "show"=>'$base->show();',
    "preview"=>'$base->preview();',
    "inst_file_remove"=>'$base->removeInstFiles();',
    "app_file_remove"=>'$base->removeAppFiles();',
    "backup_file_remove"=>'$base->removeBackupFiles();',
    "mailtest"=>'$base->mailTest();',
    "delete_expired"=>'$base->deleteExpiredAds();',
    "check_expired"=>'$base->checkExpiration();',
    "remove_favorities"=>'$base->manageFavorities("remove");',
    "add_favorities"=>'$base->manageFavorities("add");',
    "updates"=>'$base->updates();',
    "check_updates"=>'$base->checkUpdates();',
    "register"=>'$base->register();',
    "do_register"=>'$base->doRegister();',
    "do_update"=>'$base->doUpdate();',
    "move_form"=>'$base->moveForm($elementName);',
    "move"=>'$base->move();',
    "save"=>'$base->save();',
    "get_json_tree"=>'$base->getJsonTree();',
    "remind_password_form"=>'$ret=$base->remindPasswordForm($elementName);',
    "remind_password"=>'$ret=$base->remindPassword();',
    "login_form"=>'$ret=$base->loginForm($elementName);',
    "login"=>'$ret=$base->lowLevelLogin();',
    "logout"=>'$ret=logout();',
    "clone"=>'$ret=$base->cloneCategory();',
));    

$actionMethods = array_merge($actionMethods, array(
    "prolong_expiration",
    "approve",
    "remove_first_check",
    "payment_processed",
    "customer_return",
    "callback_failed",
    "get_feed",
    "get_dump",
    "sortfield",
    "advanced",
    "recalculate",
    "delete_expired",
    "check_expired",
    "remove_favorities",
    "add_favorities",
    "inst_file_remove",
    "app_file_remove",
    "backup_file_remove",
    "do_update",
    "move",
    "save",
    "organize",
    "get_json_tree",
    "remind_password",
    "change_password",
    "login",
    "logout",
    "clone"
));  

$ajaxMethods = array_merge($ajaxMethods, array(
    "appcategory"=>array(
        "organize",
        "get_json_tree"
    ),
    "customlist"=>array(
        "showdetails"
    )    
));  

$controllerShortcuts = array(
    "list" =>"showhtmllist",
    "view" =>"showdetails",
    "cat"  =>"appcategory",
    "cart" =>"shoppingcart",
    "user" =>"user",
    "field"=>"itemfield",
    "settings"=>"appsettings",
    "content"=>"appsettings_content"
);    
$reverseShortcuts = array_flip($controllerShortcuts);
    
$includeOnceList = array(
    "clonecat"=>array(NOAH_APP . "/clonecat.php")
);

class AppController extends Controller
{
    
function init($queryString)
{
    global $globalStat;
    if( !count($queryPieces = AppController::getQueryPieces($queryString)) ) 
    {
        $globalStat = & new GlobalStat();
        if( $globalStat->defPageConf ) $this->Controller("checkconf", "show");  // config check page
        else $this->Controller("appcategory", "showhtmllist", 0);  // default application home
    }
    elseif( is_numeric($queryPieces[0]) ) 
    {
        // Pl: /123     /123/attr1/val1/attr2/val2
        $this->Controller("item", "showdetails", array_shift($queryPieces), $queryPieces);
    }
    elseif( $queryPieces[0]=="list" )
    {
        array_shift($queryPieces);
        if( is_numeric($queryPieces[0]) || $queryPieces[0]=='*' )
        {
            // Pl: /list/23     /list/23/attr1/val1/attr2/val2
            // ha nincs ilyen category id, de van olyan user, aminek ez a neve:
            if( G::load( $obj, $queryPieces[0], "appcategory" ) && 
                !loadSQL( $obj=new User, array("SELECT id FROM @user WHERE name=#name# LIMIT 1", $queryPieces[0]) ) )
            {
                $this->Controller("item_my", "showhtmllist", array_shift($queryPieces), $queryPieces);
            }
            else $this->Controller("appcategory", "showhtmllist", array_shift($queryPieces), $queryPieces);
        }
        else
        {
            // Egy user osszes iteme: Pl: /list/henry
            $this->Controller("item_my", "showhtmllist", urldecode(array_shift($queryPieces)), $queryPieces);
        }
    }
    elseif( $queryPieces[0]=="rss" )
    {
        // Pl: /rss/category/10/latest/20/days/3
        array_shift($queryPieces);
        if( $queryPieces[0]=="modify_form" ) $this->Controller("rss", "modify_form", "1");
        else $this->Controller("rss", "get", "0", $queryPieces);
    }
    elseif( count($queryPieces)==1 )
    {
        if( $queryPieces[0]=="control_panel" )
        {
            $this->Controller("controlpanel", "showhtmllist");
        }
        else $this->Controller("staticpage", "show", $queryPieces[0]); // Pl: /faqpage
    }
    elseif( is_numeric($queryPieces[1]) || $queryPieces[1]=='*' ) 
    {
        // Pl: /item/123     /item/123/attr1/val1/attr2/val2
        $this->Controller(array_shift($queryPieces), "showdetails", array_shift($queryPieces), $queryPieces);
    }
    elseif( count($queryPieces)==2 )
    {
        // Pl: /user/create_form/
        $this->Controller(array_shift($queryPieces), array_shift($queryPieces), 0);
    }
    elseif( count($queryPieces)>=3 )
    {
        if( $queryPieces[2]=="off" ) //pl. notification/list/off/3
        {
            $this->Controller(array_shift($queryPieces), array_shift($queryPieces), 0, $queryPieces);
        }
        else $this->Controller(array_shift($queryPieces), array_shift($queryPieces), array_shift($queryPieces), $queryPieces);
    }
    else
    {
        trigger_error( "Invalid query string: $queryString", E_USER_ERROR );
    }
}

function getQueryPieces( $queryString )
{
    if( !$queryString || $queryString=="/" ) return array();
    $queryPieces = explode("/", $queryString );
    // ha az elejere vagy a vegere valahogy ures kerult, azt levagdossuk:
    if( $queryPieces[0]==="" ) array_shift($queryPieces);
    if( end($queryPieces)==="" ) array_pop($queryPieces);
    return $queryPieces;
}

// Gyakorlatilag az init() ellentete:
function makeQueryString()
{
    global $reverseShortcuts;
    
    if( !count($this->classVars) && $this->list=="appcategory" && $this->method=="showhtmllist" && $this->rollid==0) return "";
    if( $this->list=="appcategory" && $this->method=="showhtmllist" ) 
    {
        return "list/" . $this->makeQueryStringFromRollIdAndClassVars();
    }
    if( $this->list=="controlpanel" && $this->method=="showhtmllist" ) 
    {
        return "control_panel";
    }
    if( $this->list=="staticpage" && $this->method=="show" ) 
    {
        return urlencode($this->rollid);
    }
    if( $this->method=="showdetails" ) 
    {
        $list = isset($reverseShortcuts[$this->list]) ? $reverseShortcuts[$this->list] : $this->list;
        return "$list/" . $this->makeQueryStringFromRollIdAndClassVars();
    }
    if( $this->list=="item_my" && $this->method=="showhtmllist"  && is_string($this->rollid) ) 
    {
        return "list/" . $this->makeQueryStringFromRollIdAndClassVars();
    }
    if( $this->list=="rss" && $this->method=="get" ) 
    {
        return "rss/" . $this->makeQueryStringFromRollIdAndClassVars();
    }
    $list = isset($reverseShortcuts[$this->list]) ? $reverseShortcuts[$this->list] : $this->list;
    $method = isset($reverseShortcuts[$this->method]) ? $reverseShortcuts[$this->method] : $this->method;
    return "$list/$method/" . $this->makeQueryStringFromRollIdAndClassVars();    
}

function makeQueryStringFromRollIdAndClassVars()
{
    if( !$this->rollid && !count($this->classVars) ) return "";
    $pieces = $this->rollid ? array(urlencode($this->rollid)) : array();
    foreach( $this->classVars as $key=>$val ) $pieces[]="$key/" . urlencode($val);
    return implode("/", $pieces);
}

}
?>
