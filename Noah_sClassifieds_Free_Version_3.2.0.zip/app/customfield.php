<?php
defined('_NOAH') or die('Restricted access');

$customfield_typ =
    array(
        "attributes"=>array(
            "id"=>array(
                "type"=>"INT",
                "auto increment",
                "form hidden"
            ),
            "cid"=>array(
                "type"=>"INT",
                "form hidden"
            ),
            "name"=>array(
                "type"=>"VARCHAR",
                "conditions"=>array("\$this->isFixField()===TRUE && @\$this->name"=>array("readonly", "nohidden"),
                                    "!\$this->isFixField()"=>"text"),
                "max" =>"120",
                "list",
                "details",
                "safetext",
            ),
            "userField"=>array(
                "type"=>"INT",
                "nothing selected"=>"selectUserField",
                "class"=>"customfield",
                "where"=>"cid=0 AND isCommon=0 AND columnIndex NOT LIKE '%password%' AND columnIndex!='creationtime' AND columnIndex!='lastClickTime' AND type!=".customfield_separator."  AND type!=".customfield_picture,
                "labelAttr"=>"name",
                "order"=>"sortId ASC",
                "conditions"=>array("\$gorumroll->method=='modify_form' && @\$this->userField"=>array("modify_form: readonly"),
                                    "\$gorumroll->method=='create_form'"=>"classselection"),
            ),
            "isCommon"=>array(
                "type"=>"INT",
                "values"=>array(0,1),
                "default"=>"0",
                "cols"=>"1",
                "conditions"=>array("!\$this->isFixField() && @\$this->cid"=>"radio",
                                    "@!\$this->cid"=>"modify_form: readonly"),
            ),
/**************************************************************************
Form properties
**************************************************************************/
            "formProperties"=>array(
                "type"=>"INT",
                //"conditions"=>array("!\$this->isFixField()"=>"section"),
                "section",
                "no column",
            ),
            "showInForm"=>array(
                "type"=>"INT",
                "radio",
                "default"=>"1",
                "cols"=>"1",
                "values"=>array(customfield_forNone, customfield_forAll, customfield_forAdmin),
            ),
            "expl"=>array(
                "type"=>"TEXT",
                //"conditions"=>array("!\$this->isFixField()"=>"textarea"),
                "textarea",
                "cols"=>50,
                "rows"=>5,
                "details",
            ),
            "type"=>array(
                "type"=>"INT",
                "conditions"=>array("!\$this->isFixField()"=>"selection",
                                    "\$this->isFixField()===TRUE"=>"form hidden"),
                "modify_form: readonly",
                "enum",
                "list",
                "details",
                "values"=>array(customfield_text,
                                customfield_textarea,
                                customfield_bool,
                                customfield_selection,
                                customfield_separator,
                                customfield_multipleselection,
                                customfield_checkbox,
                                customfield_picture,
                                customfield_media,
                                customfield_url,
                                customfield_date),
                "default" =>customfield_text,
            ),
            "subType"=>array(
                "type"=>"INT",
                "conditions"=>array("!\$this->isFixField()"=>"radio",
                                    "\$this->isFixField()===TRUE"=>"form hidden"),
                "cols"=>1,
                "values"=>array(customfield_alnum,
                                customfield_integer,
                                customfield_float),
                "default" =>customfield_alnum,
            ),
            "values"=>array(
                "type"=>"TEXT",
                "mandatory",
                "cols"=>50,
                "rows"=>5,
                "conditions"=>array("!\$this->isFixField()"=>"textarea",
                                    "@in_array(\$this->type, 
                                             array(".customfield_selection.", 
                                                   ".customfield_multipleselection.", 
                                                   ".customfield_checkbox."))"=>"details"),
            ),
            "default_text"=>array(
                "type"=>"VARCHAR",
                "max"=>255,
                "conditions"=>array("!\$this->isFixField()"=>"text",
                                    "@in_array(\$this->type, 
                                             array(".customfield_text.", 
                                                   ".customfield_selection."))"=>"details"),
            ),
            "default_bool"=>array(
                "type"=>"INT",
                "conditions"=>array("!\$this->isFixField()"=>"bool",
                                    "@\$this->type==".customfield_bool=>"details"),
            ),
            "default_multiple"=>array(
                "type"=>"TEXT",
                "cols"=>50,
                "rows"=>5,
                "conditions"=>array("!\$this->isFixField()"=>"textarea",
                                    "@in_array(\$this->type, 
                                             array(".customfield_multipleselection.", 
                                                   ".customfield_checkbox."))"=>"details"),
            ),
            "checkboxCols"=>array(
                "type"=>"VARCHAR",
                "max"=>5,
                "default"=>3,
                "length"=>5,
                "min"=>1,
                "mandatory",
                "filterCharacters"=>"numeric()",
                "conditions"=>array("!\$this->isFixField()"=>"text",
                                    "@in_array(\$this->type,".customfield_checkbox.")"=>"details"),
            ),
            "mandatory"=>array(
                "type"=>"INT",
                "conditions"=>array("!\$this->isFixField()"=>"bool"),
            ),
            "allowHtml"=>array(
                "type"=>"INT",
                "conditions"=>array("!\$this->isFixField()"=>"bool"),
                "default"=>"0",
            ),
            "useMarkitup"=>array(
                "type"=>"INT",
                "conditions"=>array("!\$this->isFixField()"=>"bool"),
                "default"=>"0",
            ),
            "dateDefaultNow"=>array(
                "type"=>"INT",
                "conditions"=>array("!\$this->isFixField()"=>"bool"),
                "default"=>"0",
            ),
            "fromyear"=>array(
                "type"=>"VARCHAR",
                "conditions"=>array("!\$this->isFixField()"=>"text"),
                "max"=>20,
                "default"=>"now",
            ),
            "toyear"=>array(
                "type"=>"VARCHAR",
                "conditions"=>array("!\$this->isFixField()"=>"text"),
                "max"=>20,
                "default"=>"now",
            ),
/**************************************************************************
Display formatting
**************************************************************************/
            "formatSection"=>array(
                "type"=>"INT",
                "conditions"=>array("!\$this->isFixField() || \$this->columnIndex=='id'"=>"section"),
                "no column",
            ),
            "formatPrefix"=>array(
                "type"=>"VARCHAR",
                "conditions"=>array("!\$this->isFixField() || \$this->columnIndex=='id'"=>"text"),
                "max"=>255,
                "notrim",
                "length"=>5,
            ),
            "formatPostfix"=>array(
                "type"=>"VARCHAR",
                "conditions"=>array("!\$this->isFixField() || \$this->columnIndex=='id'"=>"text"),
                "max"=>255,
                "notrim",
                "length"=>5,
            ),
            "precision"=>array(
                "type"=>"INT",
                "conditions"=>array("!\$this->isFixField()"=>"text"),
                "default"=>2,
                "length"=>1,
            ),
            "precisionSeparator"=>array(
                "type"=>"VARCHAR",
                "conditions"=>array("!\$this->isFixField()"=>"text"),
                "max"=>1,
                "notrim",
                "length"=>1,
                "default"=>$defaultPrecisionSeparator,
            ),
            "thousandsSeparator"=>array(
                "type"=>"VARCHAR",
                "conditions"=>array("!\$this->isFixField()"=>"text"),
                "max"=>1,
                "length"=>1,
                "notrim",
                "default"=>$defaultThousandsSeparator,
            ),
            "format"=>array(
                "type"=>"VARCHAR",
                "conditions"=>array("!\$this->isFixField() || \$this->columnIndex=='id'"=>"text"),
                "notrim",
                "max"=>255,
            ),
/**************************************************************************
List properties
**************************************************************************/
            "listProperties"=>array(
                "type"=>"INT",
                "section",
                "no column",
            ),
            "showInList"=>array(
                "type"=>"INT",
                "radio",
                "default"=>"0",
                "cols"=>"1",
                "values"=>array(customfield_forNone, customfield_forAll, customfield_forLoggedin, customfield_forAdmin),
            ),
            "innewline"=>array(
                "type"=>"INT",
                "bool",
                "default"=>"0",
            ),
            "rowspan"=>array(
                "type"=>"INT",
                "bool",
                "default"=>"0",
            ),
            "displaylength"=>array(
                "type"=>"INT",
                "text",
                "length" =>"5",
            ),
            "sortable"=>array(
                "type"=>"INT",
                "bool",
                "default" =>"0",
            ),
            "mainPicture"=>array(
                "type"=>"INT",
                "bool",
                "default" =>"0",
            ),
/**************************************************************************
Details properties
**************************************************************************/
            "detailsProperties"=>array(
                "type"=>"INT",
                "no column",
                "section"
            ),
            "showInDetails"=>array(
                "type"=>"INT",
                "default"=>"1",
                "cols"=>"1",
                "radio"
            ),
            "displayLabel"=>array(
                "type"=>"INT",
                "bool",
                "default"=>"1",
            ),
            "detailsPosition"=>array(
                "type"=>"INT",
                "radio",
                "default"=>"0",
                "cols"=>1,
                "values"=>array(customfield_normal, customfield_topright, customfield_bottomright), 
            ),
/**************************************************************************
Misc properties
**************************************************************************/
            "miscProperties"=>array(
                "type"=>"INT",
                "section",
                "no column",
            ),
            "searchable"=>array(
                "type"=>"INT",
                "radio",
                "default"=>"0",
                "cols"=>"1",
                "values"=>array(customfield_forNone, customfield_forAll, customfield_forLoggedin, customfield_forAdmin),
            ),
            "rangeSearch"=>array(
                "type"=>"INT",
                "bool",
            ),
            "seo"=>array(
                "type"=>"INT",
                "conditions"=>array("@\$this->columnIndex!='clicked' && @\$this->columnIndex!='responded' && @\$this->columnIndex!='ownerName' && @\$this->cid"=>"radio"),
                "cols"=>1,
                "values"=>array(0, customfield_title,
                                customfield_description,
                                customfield_keywords),
                "default" =>"0",
            ),
            "columnIndex"=>array(
                "type"=>"VARCHAR",
                "max"=>20,
                //"list"
            ),
            "oldColumnIndex"=>array(  // just for updating purposes
                "type"=>"VARCHAR",
                "max"=>255,
            ),
            "sortId"=>array(
                "type"=>"INT",
                "list",
            ),
            "fields"=>array(  // a sort form outputjanak tarolasara
                "type"=>"INT",
            ),
        ),
        "primary_key"=>"id",
        "sort_criteria_sql"=>"sortId ASC",
        "delete_confirm"=>"name",
        "zebraList"=>"no",
        "sortfield_form: submit"=>array("customfield_savesorting"),
        "wrap_form",
        "no_pager",
    );
    
class CustomField extends Object 
{
 
function get_table() { return "customfield"; }

// hogy ne legyen lapozo tool:
function getLimit() { return "";}
   
function hasObjectRights(&$hasRight, $method, $giveError=FALSE)
{
    global $lll;

    hasAdminRights($isAdm);
    $hasRight->generalRight = TRUE;
    if( $method=="delete" )
    {
        $hasRight->generalRight = FALSE;
        $hasRight->objectRight = $isAdm && $this->isFixField()===FALSE;
    }
    else $hasRight->objectRight=($method=="load" || $isAdm);
    if( !$hasRight->objectRight && $giveError ) {
        handleError($lll["permission_denied"]);
    }
}

function isFixField()
{
    if( !isset($this->columnIndex) && !empty($this->id) ) $this->columnIndex = G::getAttr( $this->id, "customfield", "columnIndex" ); 
    return isset($this->columnIndex) ? substr($this->columnIndex, 0, 4)!="col_" : null;
}

function updateDefaultOfSelectionTypeFieldOfCustomList()
{
    if( in_array($this->type, array(customfield_bool, customfield_picture, customfield_media, customfield_selection)) )
    {
        // ezeknel a tipusoknal a -1 a default ertek - az osszes customlist-et updatelni kell, ami az adott categoriara vonatkozik
        executeQuery("UPDATE @search SET $this->columnIndex='-1' WHERE uid=0 AND cid='$this->cid'");
    }
}

function showListVal($attr)
{
    if( ($s=parent::showListVal($attr))!==FALSE ) return $s;
    if(  $attr=="sortId" )
    {
        $s="<span style='display:none;'>$this->sortId</span>";
        $s.=CustomField::showMoveTool($this->id);
    }
    else
    {
        $s=parent::showListVal($attr, "safetext");
    }
    return $s;
}

function sortFieldForm($elementName="")
{
    global $jQueryLib;
    
    JavaScript::addInclude(GORUM_JS_DIR . $jQueryLib);
    JavaScript::addInclude(GORUM_JS_DIR . "/jquery/form.js");
    JavaScript::addInclude(JS_DIR . "/sort_custom_fields.js");
    $this->showHtmlList($elementName);
}   

function getAdditionalHiddens(&$fieldList)
{
    global $gorumroll;
    
    if( $gorumroll->method!="sortfield_form" ) return "";
    $s = "";
    foreach( $fieldList as $field )
    {
        $s.="<input type='hidden' id='i$field->id' name=\"fields[$field->id]\" value='$field->sortId'>\n";
    }
    return $s;
}

function sortField()
{
    global $gorumroll;
    
    asort( $this->fields, SORT_NUMERIC );  // rendezes a tombindexek megtartasaval
    $sortId = 900;
    foreach( $this->fields as $id=>$sId )
    {
        executeQuery("UPDATE @customfield SET sortId=#index# WHERE id=#id#", $sortId+=100, $id);
    }
    Roll::setInfoText("customfield_sortingsaved");
    $this->nextAction =& new AppController("$gorumroll->list/sortfield_form/$gorumroll->rollid");
}   

function showMoveTool($fieldId)
{
    return "
    <img src='".IMAGES_DIR . "/arrow_bottom.gif' onclick=\"move(this, '$fieldId', 'bottom');\"> 
    <img src='".IMAGES_DIR . "/arrow_down.gif' onclick=\"move(this, '$fieldId', 'down');\"> 
    <img src='".IMAGES_DIR . "/arrow_up.gif' onclick=\"move(this, '$fieldId', 'up');\">  
    <img src='".IMAGES_DIR . "/arrow_top.gif' onclick=\"move(this, '$fieldId', 'top');\">";    
}   

function createForm()
{
    global $gorumroll;
    $this->cid = $gorumroll->rollid;
    parent::createForm();
}

function generForm()
{
    global $gorumroll, $jQueryLib;
    if( $gorumroll->method=="modify_form" || $gorumroll->method=="create_form" )
    {
        JavaScript::addInclude(GORUM_JS_DIR . $jQueryLib);
        JavaScript::addInclude(GORUM_JS_DIR . "/jquery/field.js");
        JavaScript::addInclude(JS_DIR . "/custom_field_form.js");
    }
    parent::generForm();
}

function create()
{
    global $gorumroll, $gorumuser, $gorumrecognised, $shoppingCartClassName;
    
    if( empty($this->columnIndex) )
    {
        $this->columnIndex = "col_".CustomField::getNextColumnIndex($this->cid);
    }
    $this->sortId = CustomField::getNextSortId($this->cid);
    parent::create();
    if( !Roll::isFormInvalid() )
    {
        if( !empty($this->seo) ) $this->handleSeoChange();
        if( !empty($this->mainPicture) ) $this->handleMainPictureChange();
        // Uj oszlopot kell letrehoznunk, ha az ujonan krealt fielddel egyutt a szukseges oszlopok szama meghaladja az eddigi maximumot:
        $this->addNewColumnToManagedTable();
        $this->handleDefaultValue();
        $this->nextAction =& new AppController("$gorumroll->list/sortfield_form/$this->cid");
    }
}

// visszaadja a kovetkezo felhasznalhato columnIndex-et egy kategoriaban, 
// vagy globalisan, ha nullaval hivjak meg:
function getNextColumnIndex( $cid=0 )
{
    $cidCond = $cid ? "cid=#cid# AND" : "";
    $query = "SELECT MAX(0+SUBSTRING(columnIndex, 5)) as columnIndex FROM @customfield WHERE $cidCond columnIndex LIKE 'col_%'";
    loadSQL( $fieldStat = new CustomField, array($query, $cid) );
    return isset($fieldStat->columnIndex) ? $fieldStat->columnIndex+1 : 0;
}

// visszaadja a kovetkezo felhasznalhato sortId-t egy kategoriaban, 
// vagy globalisan, ha nullaval hivjak meg:
function getNextSortId( $cid )
{
    $query = "SELECT MAX(sortId) as sortId FROM @customfield WHERE cid=#cid#";
    loadSQL( $fieldStat = new CustomField, array($query, $cid) );
    return isset($fieldStat->sortId) ? $fieldStat->sortId+100 : 1000;
}

function addNewColumnToManagedTable()
{
    $table = $this->getManagedTable();
    // TODO: optimalizalni, hogy a getCustomColumnIndexes ne csinaljon annyi query-t minden esetben,
    // ha tobbszor meghivjak (common field letrehozasanal):
    if( $this->type!=customfield_separator && !$this->isFixField() &&
        !in_array( $this->columnIndex, CustomField::getCustomColumnIndexes($this->getManagedTable()) ) )
    {
        if( empty($this->userField) ) executeQuery("ALTER TABLE @$table ADD $this->columnIndex TEXT NOT NULL;");
        if( $table=="item" && !in_array( $this->columnIndex, CustomField::getCustomColumnIndexes("search")) )
        {
            executeQuery("ALTER TABLE @search ADD $this->columnIndex TEXT NOT NULL;");
            $this->updateDefaultOfSelectionTypeFieldOfCustomList(); 
        }
        return TRUE;
    }
    return FALSE;
}

function modifyForm()
{
    parent::modifyForm();
    if( $this->isFixField() ) Roll::setInfoText("customfield_fixInfoText");
}

function modify()
{
    parent::modify();
    if( !Roll::isFormInvalid() )
    {
        if( !empty($this->seo) ) $this->handleSeoChange();
        if( !empty($this->mainPicture) ) $this->handleMainPictureChange();
    }
}

// Ha uj custom fieldet adunk egy olyan kategoriahoz, aminek mar vannak itemei, az itemekben be kell allitani az uj field default ertekeit:
function handleDefaultValue()
{
    if( !$this->isFixField() && empty($this->userField) && $this->type!=customfield_separator )
    {
        $default = $this->getDefaultValue();
        $query = "UPDATE @". $this->getManagedTable() ." SET $this->columnIndex=#default#";
        if( $this->cid ) $query.=" WHERE cid=#cid#";
        executeQuery($query, $default, $this->cid);
    }
}

function getDefaultValue()
{
    switch($this->type)
    {
    case customfield_text: 
        return isset($this->default_text) ? $this->default_text : "";
    case customfield_selection: 
        if( empty($this->default_text) ) return 0;
        $values = split(", *", $this->values);
        for( $i=0; $i<count($values); $i++ )
        {
            if( $values[$i]==$this->default_text ) return $i;
        }
        return 0;
    case customfield_bool: 
        return isset($this->default_bool) ? $this->default_bool : 0;
    case customfield_multipleselection: 
    case customfield_checkbox: 
        if( empty($this->default_multiple) ) return "";
        $vals = split(", *", $this->values);
        $defs = split(", *", $this->default_multiple);
        for( $i=0, $default=array(); $i<count($vals); $i++ )
        {
            if( in_array($vals[$i], $defs) ) $default[]=$i;
        }
        return implode(",", $default);
    default: return "";            
    }
}

function handleSeoChange()
{
    // hogy egy kategorian belul pl. csak egy TITLE lehessen:
    executeQuery(array("UPDATE @customfield SET seo=0 WHERE cid=#cid# AND id!=#id# AND seo=#seo#", $this->cid, $this->id, $this->seo));
}

function handleMainPictureChange()
{
    // hogy egy kategorian belul pl. csak egy main picture lehessen:
    executeQuery(array("UPDATE @customfield SET mainPicture=0 WHERE cid=#cid# AND id!=#id# AND mainPicture=1", $this->cid, $this->id));
}

function showNewToolPlusUrl()
{
    global $gorumroll;
    return $gorumroll->rollid;
}

function getSortType( $cid, $attr )
{
    if( preg_match("/col_(\d+)/", $attr, $matches) )
    {
        if( !loadSQL( $cf=new CustomField, array("SELECT * FROM @customfield WHERE cid=#cid# AND columnIndex='$attr' LIMIT 1", $cid) ) )
        {
            if( $cf->type==customfield_date ) return customfield_date;
            if( $cf->subType==customfield_integer || $cf->subType==customfield_float ) return $cf->subType;
        }
    }
    return 0;
}

function addCustomColumns( $table )
{
    global ${"{$table}_typ"};
    static $maxColumnIndex=0;
    
    // hogy a load a custom fieldeket is betoltse az objektumba:
    //$customColumnIndexes or $customColumnIndexes = self::getCustomColumnIndexes($table);
    $maxColumnIndex or $maxColumnIndex = CustomField::getNextColumnIndex()-1;
    //foreach( $customColumnIndexes as $columnIndex )
    //{
    //    if( !isset(${"{$table}_typ"}["attributes"][$columnIndex]) ) ${"{$table}_typ"}["attributes"][$columnIndex]=array("type"=>"TEXT");
    //}
    for( $i=0; $i<=$maxColumnIndex; $i++ )
    {
        if( !isset(${"{$table}_typ"}["attributes"]["col_$i"]) ) ${"{$table}_typ"}["attributes"]["col_$i"]=array("type"=>"TEXT");
    }
}

function getCustomColumnIndexes( $table )
{
    $result = executeQuery("SHOW COLUMNS FROM @$table");
    $num = mysql_num_rows($result); 
    $columnIndexes = array();
    for( $i=0, $count=0; $i<$num; $i++ ) 
    {
        $row=mysql_fetch_array($result, MYSQL_ASSOC);
        if( preg_match( "/^col_/", $row["Field"] ) ) $columnIndexes[]=$row["Field"];
    }
    return $columnIndexes;
}

function showDetailsTool()
{
    return "";
}

function displayInDetails( &$attrInfo, $ownerId )
{
    if( $this->displayInDetailsCondition($ownerId) ) $attrInfo[]="details";
}

function displayInDetailsCondition($ownerId=0)
{
    global $gorumrecognised;
    
    hasAdminRights($isAdm);
    return $this->showInDetails==customfield_forAll ||
        ($this->showInDetails==customfield_forAdmin && $isAdm) ||
        ($this->showInDetails==customfield_forLoggedin && $gorumrecognised);
}

function displayInForm( &$attrInfo )
{
    hasAdminRights($isAdm);
    if( $this->showInForm==customfield_forNone || (!$isAdm && $this->showInForm==customfield_forAdmin) ) 
    {
        $attrInfo[]="form invisible";
    }
}

function displayInList( &$attrInfo )
{
    if( $this->displayInListCondition() ) $attrInfo[]="list";
}

function displayInListCondition()
{
    global $gorumrecognised, $gorumuser;
    
    hasAdminRights($isAdm);
    return $this->showInList==customfield_forAll ||
        ($this->showInList==customfield_forAdmin && $isAdm) ||
        ($this->showInList==customfield_forLoggedin && $gorumrecognised);
}

function displayInSearchFormCondition()
{
    return AppSettings::isEnabled($this->searchable);
}

}// end class CustomField

?>
