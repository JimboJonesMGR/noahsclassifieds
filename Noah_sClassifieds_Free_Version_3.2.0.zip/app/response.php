<?php
defined('_NOAH') or die('Restricted access');
$response_typ =
    array(
        "attributes"=>array(
            "id"=>array(
                "type"=>"INT",
                "auto increment",
                "form hidden"
            ),
            "yourname"=>array(
                "type"=>"VARCHAR",
                "text",
                "max" =>"250"
            ),
            "youremail"=>array(
                "type"=>"VARCHAR",
                "min"=>"1",
                "mandatory",
                "text",
                "max" =>"250"
            ),
            "mess"=>array(
                "type"=>"TEXT",
                "textarea",
                "cols"=>"40",
                "rows"=>"10"
            ),
            "captchaField"=>array(
                "type"=>"VARCHAR",
                "conditions"=>array("\$this->hasCaptchaInForm()"=>"text"),
                "max" =>"250",
                "length"=>10,
                "no column",
            ),
        ),
        "primary_key"=>"id"
    );
class Response extends Object
{
    
function hasCaptcha($postfix="")
{
    global $gorumroll;
    if( $gorumroll->method=="create$postfix" && 
        in_array(Settings_response, explode(",", $this->s->applyCaptcha))) return TRUE;
    return FALSE;
}
    
function create()
{
    global $gorumroll, $webSiteUrl, $replyToAddress;

    CustomField::addCustomColumns("item");
    if( !isset($webSiteUrl) ) $webSiteUrl="";
    $this->valid();
    if( Roll::isFormInvalid() ) return;
    if( !preg_match('/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,6}$/i', $this->youremail) )
    {
        return Roll::setFormInvalid("invalidEmail");
    }
    executeQuery("UPDATE @item SET responded=responded+1 WHERE id=#id#", $gorumroll->rollid);
    G::load($a, $gorumroll->rollid, "item");
    G::load($u, $a->ownerId, "user");
    G::load($n, Notification_adReply, "notification");
    if( $n->active )
    {
        $sp = new SendingParameters;
        $sp->to = $u->email;
        $sp->replyTo = $this->youremail;
        $ctrl =& new AppController("item/$gorumroll->rollid");
        $url = $ctrl->makeUrl(TRUE);
        $n->send( $sp, $a->getTitle(),$url, $this->yourname,
                    $this->youremail,$this->mess); // TODO:url
    }
    //TODO: respnum increase
    Roll::setInfoText("mail_sent");
}
}

//---------------------------------------------------------------------
//---------------------------------------------------------------------
//---------------------------------------------------------------------

$friendmail_typ =
    array(
        "attributes"=>array(
            "id"=>array(
                "type"=>"INT",
                "auto increment",
                "form hidden"
            ),
            "yourname"=>array(
                "type"=>"VARCHAR",
                "text",
                "max" =>"250"
            ),
            "youremail"=>array(
                "type"=>"VARCHAR",
                "min"=>"1",
                "mandatory",
                "text",
                "max" =>"250"
            ),
            /*
            "friendsname"=>array(
                "type"=>"VARCHAR",
                "text",
                "max" =>"250"
            ),
            */
            "friendsemail"=>array(
                "type"=>"VARCHAR",
                "min"=>"1",
                "mandatory",
                "text",
                "max" =>"250"
            ),
            "mess"=>array(
                "type"=>"TEXT",
                "textarea",
                "cols"=>"40",
                "rows"=>"10"
            ),
            "captchaField"=>array(
                "type"=>"VARCHAR",
                "conditions"=>array("\$this->hasCaptchaInForm()"=>"text"),
                "max" =>"250",
                "length"=>10,
                "no column",
            ),
        ),
        "primary_key"=>"id"
    );
class Friendmail extends Object
{

function hasCaptcha($postfix="")
{
    global $gorumroll;
    if( $gorumroll->method=="create$postfix" && 
        in_array(Settings_response, explode(",", $this->s->applyCaptcha))) return TRUE;
    return FALSE;
}

function create()
{
    global $gorumroll;

    $this->valid();
    if( Roll::isFormInvalid() ) return;
    if( !preg_match('/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,6}$/i', $this->youremail) ||
        !preg_match('/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,6}$/i', $this->friendsemail) )
    {
        return Roll::setFormInvalid("invalidEmail");
    }
    G::load($n, Notification_adToAFriend, "notification");
    if( $n->active )
    {
        $ctrl =& new AppController("item/$gorumroll->rollid");
        $url = $ctrl->makeUrl(TRUE);

        $sp = new SendingParameters;
        $sp->to = $this->friendsemail;
        $sp->from = $this->youremail;
        $sp->replyTo = $this->youremail;
        $sp->replyToName = $this->yourname;
        $n->send( $sp, $this->yourname,
                  $url,$this->mess);
    }
    //TODO: respnum increase
    Roll::setInfoText("mail_fr_sent");
}

}
?>