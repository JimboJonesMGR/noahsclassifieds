<?php
defined('_NOAH') or die('Restricted access');
define("varfields_text", 1);
define("varfields_textarea", 2);
define("varfields_bool", 3);
define("varfields_selection", 4);
define("varfields_separator", 5);
define("varfields_multipleselection", 6);
define("varfields_checkbox", 7);
define("varfields_picture", 8);
define("varfields_url", 9);
define("varfields_media", 10);
define("varfields_date", 11);
define("varfields_nopic", 0);
define("varfields_thumbnail", 2);
define("varfields_mouseover", 3);
define("varfields_inlineThumbnail", 4);
define("varfields_inlineMouseover", 5);

// Orientation
define("varfields_top", 1);
define("varfields_left", 2);
define("varfields_bottom", 3);
define("varfields_right", 4);

define("varfields_nosort", 1);
define("varfields_asstring", 2);
define("varfields_asint", 3);
global $variableFieldsNum;
$variableFieldsNum = 100;
global $varfields_typ;
$varfields_typ =
    array(
        "attributes"=>array(
            "id"=>array(
                "type"=>"INT",
                "form hidden"
            ),
            "showCreationTime"=>array(
                "type"=>"INT",
                "bool",
                "default" =>"0",
                "modifydetails_form: form invisible",
            ),
            "showExpirationTime"=>array(
                "type"=>"INT",
                "bool",
                "default" =>"0",
                "modifydetails_form: form invisible",
            ),
            "pictureDisplayProperties"=>array(
                "section",
                "no column",
            ),
            "showMainPicture"=>array(
                "type"=>"INT",
                "bool",
                "default" =>"1",
                "modifydetails_form: form invisible",
            ),
            "displayType"=>array(
                "type"=>"INT",
                "selection",
                "values"=>array(varfields_nopic,
                                varfields_thumbnail,
                                varfields_mouseover,
                                varfields_inlineThumbnail,
                                varfields_inlineMouseover),
                "default" =>varfields_mouseover,
                "modifydetails_form: readonly",
            ),
            "thumbnailWidth"=>array(
                "type"=>"INT",
                "text",
                "lenght"=>"3",
                "modify_form: form invisible",
            ),
            "thumbnailHeight"=>array(
                "type"=>"INT",
                "text",
                "lenght"=>"3",
                "modify_form: form invisible",
            ),
            "displayWidth"=>array(
                "type"=>"INT",
                "text",
                "lenght"=>"3",
                "default"=>"300",
                "modify_form: form invisible",
            ),
            "displayHeight"=>array(
                "type"=>"INT",
                "text",
                "lenght"=>"3",
                "default"=>"300",
                "modify_form: form invisible",
            ),
            "thumbnailCols"=>array(
                "type"=>"INT",
                "text",
                "lenght"=>"3",
                "default"=>"3",
                "modify_form: form invisible",
            ),
            "orientation"=>array(
                "type"=>"INT",
                "selection",
                "values"=>array(varfields_top,
                                varfields_left,
                                varfields_bottom,
                                varfields_right),
                "default" =>varfields_top,
                "modify_form: form invisible",
            ),
            "thumbnailFirst"=>array(
                "type"=>"INT",
                "bool",
                "default" =>"0",
                "modify_form: form invisible",
            ),
        ),
        "primary_key"=>"id"
    );

for( $i=0; $i<$variableFieldsNum; $i++ )
{
    $varfields_typ["attributes"]["separator_$i"]=array(
                                             "section",
                                             "no column",
                                             );
    $varfields_typ["attributes"]["name_$i"]=array("type"=>"VARCHAR",
                                             "text",
                                             "max" =>"120",
                                             );
    $varfields_typ["attributes"]["expl_$i"]=array("type"=>"TEXT",
                                             "textarea",
                                             "cols"=>50,
                                             "rows"=>5,
                                             );
    $varfields_typ["attributes"]["type_$i"]=array("type"=>"INT",
                                             "selection",
                                             "values"=>array(varfields_text,
                                                             varfields_textarea,
                                                             varfields_bool,
                                                             varfields_selection,
                                                             varfields_separator,
                                                             varfields_multipleselection,
                                                             varfields_checkbox,
                                                             varfields_picture,
                                                             varfields_media,
                                                             varfields_url,
                                                             varfields_date),
                                             "default" =>varfields_text,
                                             );
    $varfields_typ["attributes"]["active_$i"]=array("type"=>"INT",
                                             "bool",
                                             "default" =>"0",
                                             "modifydetails_form: form invisible",
                                             );
    $varfields_typ["attributes"]["everActivated_$i"]=array("type"=>"INT",
                                             "bool",
                                             "default" =>"0",
                                             "form invisible",
                                             );
    $varfields_typ["attributes"]["values_$i"]=array("type"=>"TEXT",
                                             "textarea",
                                             "modify_form: form invisible",
                                             "mandatory",
                                             "cols"=>50,
                                             "rows"=>5,
                                             );
    $varfields_typ["attributes"]["default_$i"]=array("type"=>"TEXT",
                                             "modify_form: form invisible",
                                             );
    $varfields_typ["attributes"]["mandatory_$i"]=array("type"=>"INT",
                                             "bool",
                                             "modify_form: form invisible",
                                             );
    $varfields_typ["attributes"]["list_$i"]=array("type"=>"INT",
                                             "bool",
                                             "modify_form: form invisible",
                                             );
    $varfields_typ["attributes"]["innewline_$i"]=array("type"=>"INT",
                                             "bool",
                                             "modify_form: form invisible",
                                             );
    $varfields_typ["attributes"]["displaylength_$i"]=array("type"=>"INT",
                                             "text",
                                             "length" =>"5",
                                             "modify_form: form invisible",
                                             );
    $varfields_typ["attributes"]["searchable_$i"]=array("type"=>"INT",
                                             "bool",
                                             "modify_form: form invisible",
                                             );
    $varfields_typ["attributes"]["rangeSearch_$i"]=array("type"=>"INT",
                                             "bool",
                                             "modify_form: form invisible",
                                             );
    $varfields_typ["attributes"]["allowHtml_$i"]=array("type"=>"INT",
                                             "bool",
                                             "modify_form: form invisible",
                                             );
    $varfields_typ["attributes"]["private_$i"]=array("type"=>"INT",
                                             "bool",
                                             "modify_form: form invisible",
                                             );
    $varfields_typ["attributes"]["hidden_$i"]=array("type"=>"INT",
                                             "bool",
                                             "modify_form: form invisible",
                                             );
    $varfields_typ["attributes"]["format_$i"]=array("type"=>"VARCHAR",
                                             "max"=>255,
                                             "modify_form: form invisible",
                                             );
    $varfields_typ["attributes"]["sortable_$i"]=array("type"=>"INT",
                                             "selection",
                                             "values"=>array(varfields_nosort,
                                                             varfields_asstring,
                                                             varfields_asint),
                                             "default" =>varfields_nosort,
                                             "modify_form: form invisible",
                                             );
    $varfields_typ["attributes"]["fromyear_$i"]=array("type"=>"INT",
                                             "text",
                                             "modify_form: form invisible",
                                             );
    $varfields_typ["attributes"]["toyear_$i"]=array("type"=>"INT",
                                             "text",
                                             "modify_form: form invisible",
                                             );
}

class VarFields extends Object
{

function hasObjectRights(&$hasRight, $method, $giveError=FALSE)
{
    global $lll;

    hasAdminRights($isAdm);
    $hasRight->generalRight = FALSE;
    $hasRight->objectRight=($method=="load" || $isAdm);
    if( !$hasRight->objectRight && $giveError ) {
        handleError($lll["permission_denied"]);
    }
}

function modifyForm()
{
    global $gorumroll, $lll, $variableFieldsNum, $varfields_typ;

    $this->id = $gorumroll->rollid;
    if( !$gorumroll->isFormInvalid() )
    {
        $ret = $this->load();
        if( $ret )
        {
            $txt = $lll["not_found_in_db"];
            handleError($txt);
        }
    }
    $this->hasObjectRights($hasRight, "modify", TRUE);
    getDbCount($count, array("SELECT COUNT(*) FROM @item WHERE cid=#this->id#", $this->id));
    if( $count )
    {
        for( $i=0; $i<$variableFieldsNum; $i++ )
        {
            if( $this->{"everActivated_$i"} )
            {
                $varfields_typ["attributes"]["type_$i"][] = "modify_form: readonly";
            }
        }
    }
    $this->generForm();
}

function modifyDetailsForm(&$s)
{
    global $gorumroll, $lll, $variableFieldsNum, $varfields_typ;

    if( (int)$gorumroll->invalid==2 ) // ez valojaban nem invalid eset,
    // de csak igy tudtunk a modify-bol pont ide jutni.
    {
        $ret = $this->load();
        if( $ret )
        {
            $txt = $lll["not_found_in_db"];
            handleError($txt);
        }
    }
    else
    {
        // Ha invalid volt a form, akkor is kell egyet loadoznunk, mert
        // a fg-nek kesobb szuksege lesz az active_i ertekekre, ezek
        // pedig a a modifydetails_form-ban nincsenek benne, es igy a
        // modify-bol nem jonnek at.
        $ret = $this->load();
        if( $ret )
        {
            $txt = $lll["not_found_in_db"];
            handleError($txt);
        }
        // Betoltottuk az active_i ertekeket, de sajnos minden mast is.
        // A tobbit most felul kell irnunk azokkal az ertekekkel, amiket
        // a form-ba beirtak:
        $this->initClassVars();
        $gorumroll->invalid = FALSE;
    }
    switch( $this->displayType )
    {
    case varfields_nopic:
        $varfields_typ["attributes"]["pictureDisplayProperties"][] = "modifydetails_form: form invisible";
        $varfields_typ["attributes"]["thumbnailWidth"][] = "modifydetails_form: form invisible";
        $varfields_typ["attributes"]["thumbnailHeight"][] = "modifydetails_form: form invisible";
        $varfields_typ["attributes"]["displayWidth"][] = "modifydetails_form: form invisible";
        $varfields_typ["attributes"]["displayHeight"][] = "modifydetails_form: form invisible";
        $varfields_typ["attributes"]["thumbnailCols"][] = "modifydetails_form: form invisible";
        $varfields_typ["attributes"]["orientation"][] = "modifydetails_form: form invisible";
        $varfields_typ["attributes"]["thumbnailFirst"][] = "modifydetails_form: form invisible";
        break;
    case varfields_thumbnail:
        $varfields_typ["attributes"]["displayWidth"][] = "modifydetails_form: form invisible";
        $varfields_typ["attributes"]["displayHeight"][] = "modifydetails_form: form invisible";
        $varfields_typ["attributes"]["thumbnailFirst"][] = "modifydetails_form: form invisible";
        break;
    case varfields_mouseover:
        break;
    case varfields_inlineThumbnail:
        $varfields_typ["attributes"]["displayWidth"][] = "modifydetails_form: form invisible";
        $varfields_typ["attributes"]["displayHeight"][] = "modifydetails_form: form invisible";
        $varfields_typ["attributes"]["thumbnailCols"][] = "modifydetails_form: form invisible";
        $varfields_typ["attributes"]["orientation"][] = "modifydetails_form: form invisible";
        $varfields_typ["attributes"]["thumbnailFirst"][] = "modifydetails_form: form invisible";
        break;
    case varfields_inlineMouseover:
        $varfields_typ["attributes"]["displayWidth"][] = "modifydetails_form: form invisible";
        $varfields_typ["attributes"]["displayHeight"][] = "modifydetails_form: form invisible";
        $varfields_typ["attributes"]["thumbnailCols"][] = "modifydetails_form: form invisible";
        $varfields_typ["attributes"]["thumbnailFirst"][] = "modifydetails_form: form invisible";
        break;
    }
    if( !$this->thumbnailWidth ) $this->thumbnailWidth =$this->s->thumbnailWidth;
    if( !$this->thumbnailHeight ) $this->thumbnailHeight =$this->s->thumbnailHeight;
    $this->hasObjectRights($hasRight, "modify", TRUE);
    for( $i=0; $i<$variableFieldsNum; $i++ )
    {
        if( $this->{"active_$i"} && $this->{"type_$i"}!=varfields_separator )
        {
            $varfields_typ["attributes"]["name_$i"][] = "modifydetails_form: readonly";
            $varfields_typ["attributes"]["type_$i"][] = "modifydetails_form: readonly";
            $varfields_typ["attributes"]["expl_$i"][] = "modifydetails_form: readonly";
            switch( $this->{"type_$i"} )
            {
            case varfields_text:
                $varfields_typ["attributes"]["default_$i"][]="text";
                $varfields_typ["attributes"]["default_$i"]["max"]=120;
                $varfields_typ["attributes"]["values_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["innewline_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["displaylength_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["format_$i"][]="text";
                $varfields_typ["attributes"]["format_$i"]["max"]=120;
                $varfields_typ["attributes"]["fromyear_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["toyear_$i"][] = "modifydetails_form: form invisible";
                break;
            case varfields_textarea:
                $varfields_typ["attributes"]["default_$i"][]="textarea";
                $varfields_typ["attributes"]["default_$i"]["cols"]=50;
                $varfields_typ["attributes"]["default_$i"]["rows"]=5;
                $varfields_typ["attributes"]["values_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["format_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["sortable_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["rangeSearch_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["fromyear_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["toyear_$i"][] = "modifydetails_form: form invisible";
                break;
            case varfields_bool:
                $varfields_typ["attributes"]["default_$i"][]="bool";
                $varfields_typ["attributes"]["values_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["innewline_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["displaylength_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["allowHtml_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["mandatory_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["format_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["rangeSearch_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["fromyear_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["toyear_$i"][] = "modifydetails_form: form invisible";
                break;
            case varfields_selection:
                $varfields_typ["attributes"]["default_$i"][]="text";
                $varfields_typ["attributes"]["default_$i"]["max"]=120;
                $varfields_typ["attributes"]["innewline_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["displaylength_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["allowHtml_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["format_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["rangeSearch_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["fromyear_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["toyear_$i"][] = "modifydetails_form: form invisible";
                break;
            case varfields_multipleselection:
            case varfields_checkbox:
                $varfields_typ["attributes"]["default_$i"][]="text";
                $varfields_typ["attributes"]["default_$i"]["max"]=120;
                $varfields_typ["attributes"]["innewline_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["displaylength_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["allowHtml_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["format_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["sortable_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["rangeSearch_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["fromyear_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["toyear_$i"][] = "modifydetails_form: form invisible";
                break;
            case varfields_picture:
                $varfields_typ["attributes"]["default_$i"][]="modifydetails_form: form invisible";
                $varfields_typ["attributes"]["values_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["list_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["searchable_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["rangeSearch_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["allowHtml_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["innewline_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["displaylength_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["hidden_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["format_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["private_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["sortable_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["fromyear_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["toyear_$i"][] = "modifydetails_form: form invisible";
                break;
            case varfields_media:
                $varfields_typ["attributes"]["default_$i"][]="modifydetails_form: form invisible";
                $varfields_typ["attributes"]["values_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["searchable_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["rangeSearch_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["allowHtml_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["innewline_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["displaylength_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["hidden_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["format_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["private_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["sortable_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["fromyear_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["toyear_$i"][] = "modifydetails_form: form invisible";
                break;
            case varfields_url:
                $varfields_typ["attributes"]["default_$i"][]="modifydetails_form: form invisible";
                $varfields_typ["attributes"]["values_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["innewline_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["displaylength_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["format_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["sortable_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["allowHtml_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["rangeSearch_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["fromyear_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["toyear_$i"][] = "modifydetails_form: form invisible";
                break;
            case varfields_date:
                $varfields_typ["attributes"]["default_$i"][]="modifydetails_form: form invisible";
                $varfields_typ["attributes"]["values_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["innewline_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["displaylength_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["allowHtml_$i"][] = "modifydetails_form: form invisible";
                $varfields_typ["attributes"]["sortable_$i"][] = "modifydetails_form: form invisible";
                if( !$this->{"fromyear_$i"} ) $this->{"fromyear_$i"}="";
                if( !$this->{"toyear_$i"} ) $this->{"toyear_$i"}="";
                break;
            default:
                break;
            }
        }
        else
        {
            $varfields_typ["attributes"]["separator_$i"][] = "modifydetails_form: form invisible";
            $varfields_typ["attributes"]["name_$i"][] = "modifydetails_form: form invisible";
            $varfields_typ["attributes"]["type_$i"][] = "modifydetails_form: form invisible";
            $varfields_typ["attributes"]["expl_$i"][] = "modifydetails_form: form invisible";
            $varfields_typ["attributes"]["values_$i"][] = "modifydetails_form: form invisible";
            $varfields_typ["attributes"]["mandatory_$i"][] = "modifydetails_form: form invisible";
            $varfields_typ["attributes"]["list_$i"][] = "modifydetails_form: form invisible";
            $varfields_typ["attributes"]["searchable_$i"][] = "modifydetails_form: form invisible";
            $varfields_typ["attributes"]["rangeSearch_$i"][] = "modifydetails_form: form invisible";
            $varfields_typ["attributes"]["allowHtml_$i"][] = "modifydetails_form: form invisible";
            $varfields_typ["attributes"]["innewline_$i"][] = "modifydetails_form: form invisible";
            $varfields_typ["attributes"]["displaylength_$i"][] = "modifydetails_form: form invisible";
            $varfields_typ["attributes"]["private_$i"][] = "modifydetails_form: form invisible";
            $varfields_typ["attributes"]["hidden_$i"][] = "modifydetails_form: form invisible";
            $varfields_typ["attributes"]["format_$i"][] = "modifydetails_form: form invisible";
            $varfields_typ["attributes"]["sortable_$i"][] = "modifydetails_form: form invisible";
            $varfields_typ["attributes"]["fromyear_$i"][] = "modifydetails_form: form invisible";
            $varfields_typ["attributes"]["toyear_$i"][] = "modifydetails_form: form invisible";
        }
    }
    $this->generForm($s);
}

function modify( $whereFields="" )
{
    global $whatHappened, $gorumroll, $variableFieldsNum;

    Object::modify($whereFields);
    if( $whatHappened=="form_submitted" && $gorumroll->method=="modify")
    {
        $whatHappened="invalid_form";
        $gorumroll->invalid = 2; // ebbol tudja a modifydetails_form,
        // hogy valojaban nem invalid-rol van szo. Az invalid beallitast
        // itt csak a navigacio elosegitesere hasznaljuk es nem arra,
        // hogy tenyleg valami invalidot jelezzunk, erted mar?
        $gorumroll->method = "modifydetails";
    }
    // ha vannak hirdetesek, akkor vegigmegyunk rajtuk es ahol ahol az
    // attributum tipusa bool, vagy selection, ott a default ertekeket
    // megfeleloen beallitjuk, amennyiben az veletlenul ures sztring:
    elseif( $whatHappened=="form_submitted" && $gorumroll->method=="modifydetails")
    {
        getDbCount($count, array("SELECT COUNT(*) FROM @item WHERE cid=#this->id#", $this->id));
        if( $count )
        {
            //ez azert kell, mert az activ_i maskulonben nincs betoltve:
            $this->load();
            for( $i=0; $i<$variableFieldsNum; $i++ )
            {
                if( $this->{"active_$i"} )
                {
                    if( $this->{"type_$i"}==varfields_selection )
                    {
                        if( $this->{"default_$i"} )
                        {
                            $vals = split(", *", $this->{"values_$i"});
                            $valNum = count($vals);
                            for( $j=0; $j<$valNum; $j++ )
                            {
                                if($vals[$j]==$this->{"default_$i"})$default=$j;
                            }
                        }
                        else $default=0;
                    }
                    elseif( $this->{"type_$i"}==varfields_multipleselection ||
                            $this->{"type_$i"}==varfields_checkbox )
                    {
                        if( $this->{"default_$i"} )
                        {
                            $vals = split(", *", $this->{"values_$i"});
                            $defaults = split(", *", $this->{"default_$i"});
                            $valNum = count($vals);
                            $default=array();
                            for( $j=0; $j<$valNum; $j++ )
                            {
                                if(in_array($vals[$j], $defaults)) $default[]=$j;
                            }
                            $default=implode(",", $default);
                        }
                        else $default=0;
                    }
                    elseif( $this->{"type_$i"}==varfields_bool )
                    {
                        $default = $this->{"default_$i"};
                    }
                    if( isset($default) )
                    {
                        $query = "UPDATE @item SET col_$i='$default' ".
                                 "WHERE cid='$this->id' AND col_$i=''";
                        executeQuery($query);
                        unset($default);
                    }
                }
            }
        }
    }
}

function valid()
{
    global $variableFieldsNum, $whatHappened, $infoText,$lll,$gorumroll;

    if( !isset($gorumroll->method) ) // az install soran lehet ez
    {
        return ok;
    }
    for( $i=0; $i<$variableFieldsNum; $i++ )
    {
        if( $gorumroll->method=="modify" &&
            $this->{"active_$i"} && $this->{"name_$i"}=="" )
        {
            $whatHappened="invalid_form";
            $infoText = $lll["defineTheName"];
            $gorumroll->invalid=TRUE;
        }
        elseif( $gorumroll->method=="modifydetails" &&
                isset($this->{"type_$i"}) &&
                $this->{"type_$i"}==varfields_selection )
        {
            if( $this->{"values_$i"}=="" )
            {
                $whatHappened="invalid_form";
                $infoText = $lll["defineTheValues"];
                $gorumroll->invalid=TRUE;
            }
            if( $this->{"default_$i"}!="" &&
                !in_array( $this->{"default_$i"}, split(", *", $this->{"values_$i"})))
            {
                $whatHappened="invalid_form";
                $infoText = $lll["invalidDefaultValue"];
                $gorumroll->invalid=TRUE;
            }
        }
        elseif( $gorumroll->method=="modifydetails" &&
                isset($this->{"type_$i"}) &&
                ($this->{"type_$i"}==varfields_multipleselection ||
                 $this->{"type_$i"}==varfields_checkbox) )
        {
            if( $this->{"values_$i"}=="" )
            {
                $whatHappened="invalid_form";
                $infoText = $lll["defineTheValues"];
                $gorumroll->invalid=TRUE;
            }
            $defs = split(", *", $this->{"default_$i"});
            $vals = split(", *", $this->{"values_$i"});
            foreach( $defs as $def )
            {
                if( !in_array( $def, $vals))
                {
                    $whatHappened="invalid_form";
                    $infoText = $lll["invalidDefaultValue"];
                    $gorumroll->invalid=TRUE;
                }
            }

        }
    }
    // Ha a legelso modify formben voltunk es nincs benne hiba, akkor
    // ujra vegigmegyunk az attributumokon, es ahol az active TRUE-ra
    // van allitva, ott beallitjuk, hogy ezt az attr-t mar egyszer
    // aktivaltak:
    if( !$gorumroll->invalid && $gorumroll->method=="modify" )
    {
        for( $i=0; $i<$variableFieldsNum; $i++ )
        {
            if( $this->{"active_$i"} ) $this->{"everActivated_$i"}=TRUE;
        }
    }
}

function showListVal($attr)
{
    global $lll;

    $s="";
    if( strstr($attr, "type") || $attr=="displayType" ) {
        $s=$lll["$attr"."_".$this->{$attr}];
    }
    else
    {
        $s=htmlspecialchars($this->{$attr});
    }
    return $s;
}


}

?>
