<?php
defined('_NOAH') or die('Restricted access');
global $item_typ;
$item_typ =
    array(
        "attributes"=>array(
            "id"=>array(
                "type"=>"INT",
                "auto increment",
                "form hidden",
                "export"
            ),
            "cid"=>array(
                //"form hidden",
                "type"=>"INT",
                "classselection",
                "class"=>"category",
                "labelAttr"=>"wholeName",
                "ordered"=>"sortId ASC, wholeName ASC",
                "values"=>array(),
                "modify_form: form invisible",
                "conditions"=>array("!\$gorumroll->rollid"=>array("nothing selected"=>"selectCategory"),
                                    "\$gorumroll->method=='move_form'"=>array("get_values_callback"=>'getCompatibleCategories()'),
                                    "\$isAdm"=>array("where"=>"allowAd=1"),
                                    "!\$isAdm"=>array("where"=>"allowAd=1 AND allowSubmitAdAdmin=0"))
            ),
            "firstCid"=>array(
                "type"=>"INT",
                "form invisible",
            ),
            "cName"=>array(
                "type"=>"VARCHAR",
                "max" =>"120",
                "link_to"=>array("class"=>"appcategory", "id"=>"cid", "other_attr"=>"name"),
                "create_form: form readonly",
                "no column",
                "sorta",
            ),
            "title"=>array(  // a nem kategory specifikus item listak Title oszlopahoz
                "type"=>"INT",
                "form invisible",
                "no column"
            ),
            "description"=>array(  // a nem kategory specifikus item listak Description-jehez
                "type"=>"INT",
                "form invisible",
                "no column",
                "in new line"
            ),
            "creationtime"=>array(
                "type"=>"DATETIME",
                "prototype"=>"date",
                "form invisible",
                "sorta",
            ),
            "status"=>array(
                "type"=>"INT",
                "values"=>array(0, 1),  // Inactive, Active, Rejected
                "default"=>1,
                "enum",
                "conditions"=>array("\$isAdm && \$gorumroll->method!='move_form'"=>"selection")
            ),
            "clicked"=>array(
                "type"=>"INT",
                "form invisible",
                "sorta"
            ),
            "responded"=>array(
                "type"=>"INT",
                "form invisible",
                "sorta"
            ),
            "ownerId"=>array(
                "type"=>"INT",
                "form invisible",
            ),
            "ownerName"=>array(
                "type"=>"INT",
                "form invisible",
                "no column",
                "link_to"=>array("class"=>"user", "id"=>"ownerId", "other_attr"=>"name"),
            ),
            "expEmailSent"=>array(
                "type"=>"INT",
                "form invisible",
                "default"=>"0"
            ),
            "expirationTime"=>array(
                "type"=>"DATETIME",
                "prototype"=>"date",
                "form invisible",
                "sorta"
            ),
            "renewalNum"=>array(
                "type"=>"INT",
                "form invisible",
            ),
            "email"=>array(
                "no column",
                "form invisible",
            ),
            "expiration"=>array(
                "type"=>"INT",
                "conditions"=>array("\$gorumroll->method!='move_form'"=>"text")
            ),
            "expirationEnabled"=>array(
                "type"=>"INT",
                "no column",
                "form invisible"
            ),
            "expirationOverride"=>array(
                "type"=>"INT",
                "no column",
                "form invisible"
            ),
            "immediateAppear"=>array(
                "type"=>"INT",
                "no column",
                "form invisible"
            ),
            "captchaField"=>array(
                "type"=>"VARCHAR",
                "conditions"=>array("\$this->hasCaptchaInForm()"=>"text"),
                "max" =>"250",
                "length"=>10,
                "no column",
            ),
        ),
        "primary_key"=>"id",
        //"delete_confirm"=>"",
        "sort_criteria_sql"=>"creationtime DESC",
        "detailsTemplate"=>"item_details.tpl.php",
        "detailsPresentationClassName"=>"ItemDetailsPresentation",
    );

    
?>
