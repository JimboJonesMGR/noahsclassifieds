<?php
defined('_NOAH') or die('Restricted access');
$tA["appcategory-showhtmllist"]="category_list.tpl.php";
$tA["controlpanel-showhtmllist"]="control_panel.tpl.php";
$tA["checkconf"]="checkconf.tpl.php";
$tA["checkconf-show"]="checkconf_main.tpl.php";
$tA["checkconf-register"]="checkconf_register.tpl.php";
$tA["checkconf-updates"]="checkconf_update.tpl.php";
$tA["staticpage-preview"]="preview.tpl.php";
$tA["appcategory-organize_form"]="organize.tpl.php";
$tA["customlist-showhtmllist"]="customlists.tpl.php";
?>
