<?php
defined('_NOAH') or die('Restricted access');
function appFillTables()
{
    global $lll,$gorumuser,$fixCss, $withShoppingCart;
    global $gorumroll, $ommitNotifications, $noahVersion, $versionFooterText;

    ini_set("max_execution_time", 0);
    $ommitNotifications = TRUE;  // so that the install scipt doesn't send out notifications       
    $gorumroll = new Roll();

    $g = new GlobalStat;
    $g->id=1;
    $g->instver=$noahVersion;
    create($g);
    
    executeQuery("
    INSERT INTO @settings (
        `id`, 
        `menuPoints`, 
        `allowedThemes`, 
        `allowedLanguages`, 
        `titlePrefix`, 
        `blockSize`, 
        `showExplanation`, 
        `dateFormat`,
        `updateCheckInterval`,
        `versionFooter`) VALUES 
    (1, '1,2,3,4,5,6,7,8,9,10,11,12','classic,modern', 'en', '[Noah''s Classifieds]', 20, 0, 'Y-m-d',7,
    '$versionFooterText');");
 
    ItemField::addDefaultCustomFields();
    
    $v = new UserField;
    $v->cid = 0;
    $v->name = "Name";
    $v->type = customfield_text;
    $v->showInList = customfield_forAll;
    $v->mandatory = TRUE;
    $v->searchable = customfield_forAll;
    $v->sortable = TRUE;
    $v->columnIndex = "name";
    $v->sortId = 1000;
    $v->create();

    $v = new UserField;
    $v->cid = 0;
    $v->name = "Email";
    $v->type = customfield_text;
    $v->showInList = customfield_forAdmin;
    $v->showInDetails = customfield_forAdmin;
    $v->showInForm = customfield_forAdmin;
    $v->mandatory = TRUE;
    $v->searchable = customfield_forAdmin;
    $v->sortable = TRUE;
    $v->columnIndex = "email";
    $v->sortId = 1100;
    $v->create();

    $v = new UserField;
    $v->cid = 0;
    $v->name = "Change password";
    $v->type = customfield_separator;
    $v->showInList = customfield_forNone;
    $v->showInDetails = customfield_forNone;
    $v->columnIndex = "changePassword";
    $v->sortId = 1200;
    $v->create();

    $v = new UserField;
    $v->cid = 0;
    $v->name = "Password";
    $v->type = customfield_text;
    $v->showInList = customfield_forNone;
    $v->showInDetails = customfield_forNone;
    $v->columnIndex = "password";
    $v->sortId = 1300;
    $v->create();

    $v = new UserField;
    $v->cid = 0;
    $v->name = "Repeat password";
    $v->type = customfield_text;
    $v->default_text = "";
    $v->showInList = customfield_forNone;
    $v->showInDetails = customfield_forNone;
    $v->columnIndex = "passwordCopy";
    $v->sortId = 1400;
    $v->create();

    $v = new UserField;
    $v->cid = 0;
    $v->name = "Remember password";
    $v->type = customfield_bool;
    $v->showInList = customfield_forNone;
    $v->showInDetails = customfield_forNone;
    $v->columnIndex = "rememberPassword";
    $v->sortId = 1500;
    $v->create();

    $v = new UserField;
    $v->cid = 0;
    $v->name = "Password reminder";
    $v->type = customfield_url;
    $v->showInList = customfield_forNone;
    $v->showInDetails = customfield_forNone;
    $v->showInForm = customfield_forAll;
    $v->columnIndex = "remindPasswordLink";
    $v->sortId = 1550;
    $v->create();

    $v = new UserField;
    $v->cid = 0;
    $v->name = "First name";
    $v->type = customfield_text;
    $v->showInList = customfield_forNone;
    $v->showInDetails = customfield_forAll;
    $v->searchable = customfield_forAll;
    $v->sortId = 1560;
    $v->create();

    $v = new UserField;
    $v->cid = 0;
    $v->name = "Last name";
    $v->type = customfield_text;
    $v->showInList = customfield_forNone;
    $v->showInDetails = customfield_forAll;
    $v->searchable = customfield_forAll;
    $v->sortId = 1570;
    $v->create();

    $v = new UserField;
    $v->cid = 0;
    $v->name = "About me";
    $v->type = customfield_textarea;
    $v->showInList = customfield_forNone;
    $v->showInDetails = customfield_forAll;
    $v->searchable = customfield_forAll;
    $v->sortId = 1580;
    $v->create();

    $v = new UserField;
    $v->cid = 0;
    $v->name = "Location";
    $v->type = customfield_separator;
    $v->showInList = customfield_forNone;
    $v->showInDetails = customfield_forLoggedin;
    $v->searchable = customfield_forLoggedin;
    $v->sortId = 1600;
    $v->create();

    $v = new UserField;
    $v->cid = 0;
    $v->name = "Street";
    $v->type = customfield_text;
    $v->showInList = customfield_forNone;
    $v->showInDetails = customfield_forLoggedin;
    $v->searchable = customfield_forLoggedin;
    $v->sortId = 1700;
    $v->create();

    $v = new UserField;
    $v->cid = 0;
    $v->name = "Post code";
    $v->type = customfield_text;
    $v->showInList = customfield_forNone;
    $v->showInDetails = customfield_forLoggedin;
    $v->searchable = customfield_forLoggedin;
    $v->sortId = 1800;
    $v->create();

    $v = new UserField;
    $v->cid = 0;
    $v->name = "City";
    $v->type = customfield_text;
    $v->showInList = customfield_forNone;
    $v->showInDetails = customfield_forLoggedin;
    $v->searchable = customfield_forLoggedin;
    $v->sortId = 1900;
    $v->create();

    $v = new UserField;
    $v->cid = 0;
    $v->name = "State";
    $v->type = customfield_selection;
    $v->values = "Other,Alabama,Alaska,Arizona,Arkansas,California,Colorado,Connecticut,District of Columbia,Delaware,Flordia,Georgia,Hawaii,Iowa,Idaho,Illinois,Indiana,Kansas,Kentucky,Louisiana,Maine,Maryland,Massachusetts,Michigan,Minnesota,Mississippi,Missouri,Montana,Nebraska,Nevada,New Hampshire,New Jersey,New Mexico,New York,North Carolina,North Dakota,Ohio,Oklahoma,Oregon,Pennsylvania,Rhode Island,South Carolina,South Dakota,Tennessee,Texas,Utah,Vermont,Virginia,Washington,West Virginia,Wisconsin,Wyoming";
    $v->default_text = "Other";
    $v->showInList = customfield_forNone;
    $v->showInDetails = customfield_forLoggedin;
    $v->searchable = customfield_forLoggedin;
    $v->sortId = 2000;
    $v->create();

    $v = new UserField;
    $v->cid = 0;
    $v->name = "Country";
    $v->type = customfield_selection;
    $v->values = "Afghanistan,Albania,Algeria,American Samoa,Andorra,Angola,Anguilla,Antarctica,Antigua And Barbuda,Argentina,Armenia,Aruba,Australia,Austria,Azerbaijan,Bahamas,Bahrain,Bangladesh,Barbados,Belarus,Belgium,Belize,Benin,Bermuda,Bhutan,Bolivia,Bosnia And Herzegowina,Botswana,Bouvet Island,Brazil,British Indian Ocean Territory,Brunei Darussalam,Bulgaria,Burkina Faso,Burundi,Cambodia,Cameroon,Canada,Cape Verde,Cayman Islands,Central African Republic,Chad,Chile,China,Christmas Island,Cocos (Keeling) Islands,Colombia,Comoros,Congo,Cook Islands,Costa Rica,Cote D'Ivoire,Croatia (Local Name: Hrvatska),Cuba,Cyprus,Czech Republic,Denmark,Djibouti,Dominica,Dominican Republic,East Timor,Ecuador,Egypt,El Salvador,Equatorial Guinea,Eritrea,Estonia,Ethiopia,Falkland Islands (Malvinas),Faroe Islands,Fiji,Finland,France,French Guiana,French Polynesia,French Southern Territories,Gabon,Gambia,Georgia,Germany,Ghana,Gibraltar,Greece,Greenland,Grenada,Guadeloupe,Guam,Guatemala,Guinea,Guinea-Bissau,Guyana,Haiti,Heard And Mc Donald Islands,Holy See (Vatican City State),Honduras,Hong Kong,Hungary,Icel And,India,Indonesia,Iran (Islamic Republic Of),Iraq,Ireland,Israel,Italy,Jamaica,Japan,Jordan,Kazakhstan,Kenya,Kiribati,Korea - Dem People'S Republic,Korea - Republic Of,Kuwait,Kyrgyzstan,Lao People'S Dem Republic,Latvia,Lebanon,Lesotho,Liberia,Libyan Arab Jamahiriya,Liechtenstein,Lithuania,Luxembourg,Macau,Macedonia,Madagascar,Malawi,Malaysia,Maldives,Mali,Malta,Marshall Islands,Martinique,Mauritania,Mauritius,Mayotte,Mexico,Micronesia - Federated States,Moldova - Republic Of,Monaco,Mongolia,Montserrat,Morocco,Mozambique,Myanmar,Namibia,Nauru,Nepal,Netherlands,Netherlands Ant Illes,New Caledonia,New Zealand,Nicaragua,Niger,Nigeria,Niue,Norfolk Island,Northern Mariana Islands,Norway,Oman,Pakistan,Palau,Panama,Papua New Guinea,Paraguay,Peru,Philippines,Pitcairn,Poland,Portugal,Puerto Rico,Qatar,Reunion,Romania,Russian Federation,Rwanda,Saint K Itts And Nevis,Saint Lucia,Saint Vincent - The Grenadines,Samoa,San Marino,Sao Tome And Principe,Saudi Arabia,Senegal,Seychelles,Sierra Leone,Singapore,Slovakia (Slovak Republic),Slovenia,Solomon Islands,Somalia,South Africa,South Georgia - S Sandwich Is.,Spain,Sri Lanka,St.  Helena,St.  Pierre And Miquelon,Sudan,Suriname,Svalbard - Jan Mayen Islands,Sw Aziland,Sweden,Switzerland,Syrian Arab Republic,Taiwan,Tajikistan,Tanzania - United Republic Of,Thailand,Togo,Tokelau,Tonga,Trinidad And Tobago,Tunisia,Turkey,Turkmenistan,Turks And Caicos Islands,Tuvalu,Uganda,Ukraine,United Arab Emirates,United Kingdom,United States,United States Minor Is.,Uruguay,Uzbekistan,Vanuatu,Venezuela,Viet Nam,Virgin Islands (British),Virgin Islands (U.S.),Wallis And Futuna Islands,Western Sahara,Yemen,Yugoslavia,Zaire,Zambia,Zimbabwe";
    $v->default_text = "United States";
    $v->showInList = customfield_forNone;
    $v->showInDetails = customfield_forLoggedin;
    $v->searchable = customfield_forLoggedin;
    $v->sortId = 2100;
    $v->create();

    $v = new UserField;
    $v->cid = 0;
    $v->name = "Age";
    $v->type = customfield_text;
    $v->subType = customfield_integer;
    $v->showInList = customfield_forNone;
    $v->showInDetails = customfield_forLoggedin;
    $v->searchable = customfield_forLoggedin;
    $v->rangeSearch = TRUE;
    $v->sortId = 2200;
    $v->create();

    $v = new UserField;
    $v->cid = 0;
    $v->name = "Married";
    $v->type = customfield_bool;
    $v->showInList = customfield_forNone;
    $v->showInDetails = customfield_forLoggedin;
    $v->searchable = customfield_forLoggedin;
    $v->sortId = 2300;
    $v->create();

    $v = new UserField;
    $v->cid = 0;
    $v->name = "Date of birth";
    $v->type = customfield_date;
    $v->showInList = customfield_forNone;
    $v->showInDetails = customfield_forLoggedin;
    $v->rangeSearch = TRUE;
    $v->searchable = customfield_forLoggedin;
    $v->sortId = 2400;
    $v->create();

    $v = new UserField;
    $v->cid = 0;
    $v->name = "Picture";
    $v->type = customfield_picture;
    $v->mainPicture = TRUE;
    $v->showInList = customfield_forAll;
    $v->showInDetails = customfield_forAll;
    $v->searchable = customfield_forAll;
    $v->create();

    $v = new UserField;
    $v->cid = 0;
    $v->name = "Picture 2";
    $v->type = customfield_picture;
    $v->showInList = customfield_forNone;
    $v->showInDetails = customfield_forAll;
    $v->create();

    $v = new UserField;
    $v->cid = 0;
    $v->name = "Picture 3";
    $v->type = customfield_picture;
    $v->showInList = customfield_forNone;
    $v->showInDetails = customfield_forAll;
    $v->create();

    $v = new UserField;
    $v->cid = 0;
    $v->name = "Other";
    $v->type = customfield_separator;
    $v->showInList = customfield_forNone;
    $v->showInDetails = customfield_forAdmin;
    $v->showInForm = customfield_forNone;
    $v->searchable = customfield_forAdmin;
    $v->sortId = 2200;
    $v->create();

    $v = new UserField;
    $v->cid = 0;
    $v->name = "Registration";
    $v->type = customfield_date;
    $v->showInList = customfield_forNone;
    $v->showInDetails = customfield_forAdmin;
    $v->showInForm = customfield_forNone;
    $v->columnIndex = "creationtime";
    $v->searchable = customfield_forAdmin;
    $v->rangeSearch = TRUE;
    $v->sortId = 2300;
    $v->create();

    $v = new UserField;
    $v->cid = 0;
    $v->name = "Last log in";
    $v->type = customfield_date;
    $v->showInList = customfield_forNone;
    $v->showInDetails = customfield_forAdmin;
    $v->showInForm = customfield_forNone;
    $v->columnIndex = "lastClickTime";
    $v->searchable = customfield_forAdmin;
    $v->sortId = 2400;
    $v->create();

    $v = new UserField;
    $v->cid = 0;
    $v->name = "Ads of this user";
    $v->type = customfield_url;
    $v->showInList = customfield_forNone;
    $v->showInDetails = customfield_forAll;
    $v->showInForm = customfield_forNone;
    $v->columnIndex = "viewAdsLink";
    $v->sortId = 2500;
    $v->create();

    $demoText = "This is a test user only, whose sole purpose is to demonstrate the feature of adding and using user custom fields. It is supposed to be deleted from the live program.";
    // Tesztjuzerek:
    $u = new User;
    $u->activateVariableFields();
    $u->id = "10";
    $u->name="john";
    $u->email="";
    $u->active=1;
    $u->password=getPassword("a");
    $u->set("First name", "John");
    $u->set("Last name", "Wayne");
    $u->set("State", 3);  // Arizona
    $u->set("Country", 222);// USA
    $u->set("City", "Chicago");
    $u->set("Post code", "55555");
    $u->set("Street", "Apple st. 15");
    $u->set("Married", TRUE);
    $u->set("Age", 77);
    $u->set("Date of birth", new Date("1931-10-23"));
    $u->set("About me", $demoText);
    $u->set("Picture", "jpg");
    create($u);

    $u = new User;
    $u->activateVariableFields();
    $u->id = "20";
    $u->name="jack";
    $u->email="";
    $u->active=1;
    $u->password=getPassword("a");
    $u->set("First name", "Jack");
    $u->set("Last name", "Lemmon");
    $u->set("State", 3);  // Arizona
    $u->set("Country", 222);// USA
    $u->set("Post code", "55551");
    $u->set("City", "New York");
    $u->set("Street", "Orange st. 25");
    $u->set("Married", TRUE);
    $u->set("Age", 66);
    $u->set("Date of birth", new Date("1942-11-13"));
    $u->set("About me", $demoText);
    $u->set("Picture", "jpg");
    create($u);

    $u = new User;
    $u->activateVariableFields();
    $u->id = "30";
    $u->name="al";
    $u->email="";
    $u->active=1;
    $u->password=getPassword("a");
    $u->set("First name", "Al");
    $u->set("Last name", "Pachino");
    $u->set("State", 2);
    $u->set("Country", 222);// USA
    $u->set("Post code", "45551");
    $u->set("Street", "Peach st. 25");
    $u->set("City", "Chicago");
    $u->set("Married", FALSE);
    $u->set("Age", 55);
    $u->set("Date of birth", new Date("1953-01-18"));
    $u->set("About me", $demoText);
    $u->set("Picture", "jpg");
    create($u);

    $u = new User;
    $u->activateVariableFields();
    $u->id = "40";
    $u->name="mel";
    $u->email="";
    $u->active=1;
    $u->password=getPassword("a");
    $u->set("First name", "Mel");
    $u->set("Last name", "Gibson");
    $u->set("State", 2);  // Arizona
    $u->set("Country", 222);// USA
    $u->set("Post code", "45551");
    $u->set("City", "Washington");
    $u->set("Street", "Banana st. 25");
    $u->set("Married", FALSE);
    $u->set("Age", 53);
    $u->set("Date of birth", new Date("1948-11-13"));
    $u->set("About me", $demoText);
    $u->set("Picture", "jpg");
    create($u);

    // Cronjobok ( a constants.php-ban felvett id-kkel itt objektumokat
    // krealunk):
    $c = new CronJob;
    $c->id = Cronjob_checkExpiration;
    $c->title = "Check advertisement expirations";
    $c->frequency=24; //hours
    $c->function = "checkExpiration();";
    create($c);

    $c = new CronJob;
    $c->id = Cronjob_deleteExpired;
    $c->title = "Delete expired advertisements";
    $c->frequency=24; //hours
    $c->function = "deleteExpiredAds();";
    create($c);

    $c = new CronJob;
    $c->id = Cronjob_deleteInactiveUsers;
    $c->title = "Delete inactive guests";
    $c->frequency=24; //hours
    $c->function = "deleteInactiveGuests();";
    create($c);

    // Notificationok ( a constants.php-ban felvett id-kkel itt
    // objektumokat krealunk):
    $n = new Notification;
    $n->id = Notification_initialPassword;
    $n->title = $lll["notif_initpass_tit"];
    $n->subject=$lll["notif_initpass_subj"];
    $n->body="notifications/email_initial_password.html";
    $n->variables="uname, pwd, url";
    $n->active=TRUE;
    $n->langDependent=TRUE;
    create($n);

    $n = new Notification;
    $n->id = Notification_remindPassword;
    $n->title = $lll["notif_remindpass_tit"];
    $n->subject=$lll["notif_remindpass_subj"];
    $n->body="notifications/email_remind_password.html";
    $n->variables="name, pwd, url";
    $n->active=TRUE;
    $n->langDependent=TRUE;
    create($n);

    $n = new Notification;
    $n->id = Notification_adCreated;
    $n->title = "Sent to admin upon ad creation or modification";
    $n->subject="Ad creation, or modification";
    $n->body="notifications/email_ad_created.html";
    $n->variables="title";
    $n->active=TRUE;
    $n->langDependent=FALSE;
    create($n);

    $n = new Notification;
    $n->id = Notification_adDeleted;
    $n->title = "Sent to the owner when his ad has been deleted";
    $n->subject="Ad expiration";
    $n->body="notifications/email_ad_deleted.html";
    $n->variables="category, title";
    $n->langDependent=FALSE;
    create($n);

    $n = new Notification;
    $n->id = Notification_adExpired;
    $n->title = "Sent to the owner when his ad is about to expire";
    $n->subject="Ad expiration warning";
    $n->body="notifications/email_ad_expired.html";
    $n->variables="daysLeft, category, title";
    $n->langDependent=FALSE;
    create($n);

    $n = new Notification;
    $n->id = Notification_adApproved;
    $n->title = "Sent to the owner when his ad have been approved";
    $n->subject="Ad approval";
    $n->body="notifications/email_ad_approved.html";
    $n->variables="title";
    $n->langDependent=FALSE;
    create($n);

    $n = new Notification;
    $n->id = Notification_adReply;
    $n->title = "Reply to a posting";
    $n->subject="Reply to your posting";
    $n->body="notifications/email_ad_replied.html";
    $n->variables="listing, url, name, email, message";
    $n->langDependent=TRUE;
    create($n);

    $n = new Notification;
    $n->id = Notification_adToAFriend;
    $n->title = "Mail to a friend";
    $n->subject="Check this out";
    $n->body="notifications/email_to_friend.html";
    $n->variables="name, url, message";
    $n->langDependent=TRUE;
    create($n);

    $n = new Notification;
    $n->id = Notification_autoNotify;
    $n->title = "Auto notify email";
    $n->subject="Auto notify: a new ad has been submitted";
    $n->body="notifications/email_subscription.html";
    $n->variables="title, unsubUrl";
    $n->langDependent=FALSE;
    create($n);
    
    /*
    for( $j=1; $j<101; $j++ )
    {
        $c2 = new AppCategory;
        $c2->up = 0;
        $c2->sortId = 100*$j;
        $c2->name = $c2->wholeName = "Category $j";
        create($c2);
    }
    */
    // Tesztkategoriak:
    global $fatherCatList;
    $carC = new AppCategory;
    $carC->name="Cars";
    $carC->description="A lot of cars, different classes, little and large ones, different manufacturers, you can check for the price as well...";
    $carC->up=0;
    $carC->picture="jpg";
    $carC->create(TRUE);

    $v = new ItemField;
    $v->cid = $carC->id;
    $v->name = "Title";
    $v->type = customfield_text;
    $v->seo = customfield_title;
    $v->showInList = customfield_forAll;
    $v->mandatory = TRUE;
    $v->searchable = customfield_forAll;
    $v->sortable = TRUE;
    $v->create();
    $v = new ItemField;
    $v->cid = $carC->id;
    $v->name = "Description";
    $v->type = customfield_textarea;
    $v->seo = customfield_description;
    $v->showInList = customfield_forAll;
    $v->innewline=TRUE;
    $v->searchable = customfield_forAll;
    $v->allowHtml = TRUE;
    $v->useMarkitup = TRUE;
    $v->create();
    $v = new ItemField;
    $v->cid = $carC->id;
    $v->name = "Consumption";
    $v->type = customfield_text;
    $v->subType = customfield_float;
    $v->formatPostfix = ' l/mile';
    $v->showInList = customfield_forAll;
    $v->searchable = customfield_forAll;
    $v->sortable = TRUE;
    $v->create();
    $v = new ItemField;
    $v->cid = $carC->id;
    $v->name = "Broken";
    $v->type = customfield_bool;
    $v->showInList = customfield_forAll;
    $v->searchable = customfield_forAll;
    $v->sortable = TRUE;
    $v->create();
    $v = new ItemField;
    $v->cid = $carC->id;
    $v->name = "Price";
    $v->type = customfield_text;
    $v->subType = customfield_float;
    $v->formatPrefix = '$ ';
    $v->showInList = customfield_forAll;
    $v->searchable = customfield_forAll;
    $v->sortable = TRUE;
    $v->create();
    $v = new ItemField;
    $v->cid = $carC->id;
    $v->name = "Picture";
    $v->isCommon = 1;
    $v->type = customfield_picture;
    $v->mainPicture = 1;
    $v->searchable = customfield_forAll;
    $v->showInList = customfield_forAll;
    $v->rowspan = TRUE;
    $v->create();
    $v = new ItemField;
    $v->cid = $carC->id;
    $v->name = "Pic2";
    $v->type = customfield_picture;
    $v->create();
    $v = new ItemField;
    $v->cid = $carC->id;
    $v->name = "Pic3";
    $v->type = customfield_picture;
    $v->create();
    $v = new ItemField;
    $v->cid = $carC->id;
    $v->name = "Pic4";
    $v->type = customfield_picture;
    $v->create();
    $v = new ItemField;
    $v->cid = $carC->id;
    $v->name = "Pic5";
    $v->type = customfield_picture;
    $v->create();
    $v = new ItemField;
    $v->cid = $carC->id;
    $v->name = "Pic6";
    $v->type = customfield_picture;
    $v->create();
    $v = new ItemField;
    $v->cid = $carC->id;
    $v->name = "Pic7";
    $v->type = customfield_picture;
    $v->create();
    $v = new ItemField;
    $v->cid = $carC->id;
    $v->name = "Pic8";
    $v->type = customfield_picture;
    $v->create();
    $v = new ItemField;
    $v->cid = $carC->id;
    $v->name = "Pic9";
    $v->type = customfield_picture;
    $v->create();    

    $fatherCatList = 0;
    $hardC = new AppCategory;
    $hardC->name="Hardware";
    $hardC->description="Find hardware into your computer, from memory to CD-Rom, from hard disk to monitor, whatever you want...";
    $hardC->up=0;
    $hardC->picture="jpg";
    $hardC->create(TRUE);

    $v = new ItemField;
    $v->cid = $hardC->id;
    $v->name = "Title";
    $v->type = customfield_text;
    $v->seo = customfield_title;
    $v->showInList = customfield_forAll;
    $v->mandatory = TRUE;
    $v->searchable = customfield_forAll;
    $v->sortable = TRUE;
    $v->create();
    $v = new ItemField;
    $v->cid = $hardC->id;
    $v->name = "Description";
    $v->type = customfield_textarea;
    $v->seo = customfield_description;
    $v->showInList = customfield_forAll;
    $v->innewline=TRUE;
    $v->searchable = customfield_forAll;
    $v->allowHtml = TRUE;
    $v->useMarkitup = TRUE;
    $v->create();
    $v = new ItemField;
    $v->cid = $hardC->id;
    $v->name = "Type";
    $v->type = customfield_selection;
    $v->showInList = customfield_forAll;
    $v->values="Pc, Mac";
    $v->default_text="Pc";
    $v->searchable = customfield_forAll;
    $v->sortable = TRUE;
    $v->create();
    $v = new ItemField;
    $v->cid = $hardC->id;
    $v->name = "Price";
    $v->type = customfield_text;
    $v->subType = customfield_float;
    $v->formatPrefix = '$ ';
    $v->showInList = customfield_forAll;
    $v->searchable = customfield_forAll;
    $v->sortable = TRUE;
    $v->create();
    
    $fatherCatList = 0;
    $cottC = new AppCategory;
    $cottC->name="Cottages";
    $cottC->description="Find a house for your family! Nice weekends, fishing in the lake, climbing to the mountains, near to your...";
    $cottC->up=0;
    $cottC->picture="jpg";
    $cottC->create(TRUE);

    $v = new ItemField;
    $v->cid = $cottC->id;
    $v->name = "Title";
    $v->type = customfield_text;
    $v->seo = customfield_title;
    $v->showInList = customfield_forAll;
    $v->mandatory = TRUE;
    $v->searchable = customfield_forAll;
    $v->sortable = TRUE;
    $v->create();
    $v = new ItemField;
    $v->cid = $cottC->id;
    $v->name = "Description";
    $v->type = customfield_textarea;
    $v->seo = customfield_description;
    $v->showInList = customfield_forAll;
    $v->innewline=TRUE;
    $v->searchable = customfield_forAll;
    $v->allowHtml = TRUE;
    $v->useMarkitup = TRUE;
    $v->create();
    $v = new ItemField;
    $v->cid = $cottC->id;
    $v->name = "Price";
    $v->type = customfield_text;
    $v->subType = customfield_float;
    $v->formatPrefix = '$ ';
    $v->showInList = customfield_forAll;
    $v->searchable = customfield_forAll;
    $v->sortable = TRUE;
    $v->create();
    
    $fatherCatList = 0;
    $datC = new AppCategory;
    $datC->name="Dating";
    $datC->description="Are you searching for your partner for a long time? The search is over, thousands are looking for love here...";
    $datC->up=0;
    $datC->picture="jpg";
    $datC->allowAd=FALSE;
    $datC->create(TRUE);

    $v = new ItemField;
    $v->cid = $datC->id;
    $v->name = "Title";
    $v->type = customfield_text;
    $v->seo = customfield_title;
    $v->showInList = customfield_forAll;
    $v->mandatory = TRUE;
    $v->searchable = customfield_forAll;
    $v->create();
    $v = new ItemField;
    $v->cid = $datC->id;
    $v->name = "About me";
    $v->seo = customfield_description;
    $v->type = customfield_textarea;
    $v->showInList = customfield_forAll;
    $v->innewline=TRUE;
    $v->searchable = customfield_forAll;
    $v->allowHtml = TRUE;
    $v->useMarkitup = TRUE;
    $v->create();
    $v = new ItemField;
    $v->cid = $datC->id;
    $v->name = "Searching for a";
    $v->type = customfield_selection;
    $v->showInList = customfield_forAll;
    $v->values="Man, Woman, Couple";
    $v->default_text="Man";
    $v->searchable = customfield_forAll;
    $v->sortable = TRUE;
    $v->create();
    $v = new ItemField;
    $v->cid = $datC->id;
    $v->name = "About the partner";
    $v->type = customfield_textarea;
    $v->showInList = customfield_forAll;
    $v->searchable=customfield_forAll;
    $v->innewline=TRUE;
    $v->searchable = customfield_forAll;
    $v->allowHtml = TRUE;
    $v->useMarkitup = TRUE;
    $v->create();
    $v = new ItemField;
    $v->cid = $datC->id;
    $v->name = "Purpose";
    $v->type = customfield_selection;
    $v->showInList = customfield_forAll;
    $v->values="Friendship, Marriage, Sex";
    $v->default_text="Friendship";
    $v->searchable = customfield_forAll;
    $v->sortable = TRUE;
    $v->create();

    $fatherCatList = 0;
    $ecoC = new AppCategory;
    $ecoC->name="Economy cars";
    $ecoC->description="If you don't want to pay much at your petrol station and you dont't want problems during parking, search here.";
    $ecoC->up=$carC->id;
    $ecoC->picture="jpg";
    $ecoC->create(TRUE);

    $fatherCatList = 0;
    $jeepC = new AppCategory;
    $jeepC->name="Pickups";
    $jeepC->description="You always have been dreaming about a nice picup? Check it out here...";
    $jeepC->up=$carC->id;
    $jeepC->picture="jpg";
    $jeepC->create(TRUE);

    $fatherCatList = 0;
    $diskC = new AppCategory;
    $diskC->name="Hard disks";
    $diskC->up=$hardC->id;
    $diskC->create(TRUE);

    $fatherCatList = 0;
    $softC = new AppCategory;
    $softC->name="Memory chips";
    $softC->up=$hardC->id;
    $softC->create(TRUE);

    $fatherCatList = 0;
    $menC = new AppCategory;
    $menC->name="Men";
    $menC->up=$datC->id;
    $menC->create(TRUE);

    $fatherCatList = 0;
    $womC = new AppCategory;
    $womC->name="Women";
    $womC->up=$datC->id;
    $womC->create(TRUE);

    $featured = new ItemField;
    $featured->cid = $carC->id;
    $featured->name = "Promotion level";
    $featured->isCommon = 1;
    $featured->type = customfield_multipleselection;
    $featured->values = "None,Gold,Silver,Bronze";
    $featured->default_multiple = "None";
    $featured->searchable = customfield_forAdmin;
    $featured->showInForm = customfield_forAdmin;
    $featured->showInList = customfield_forNone;
    $featured->expl = "This is an example common field that has been set up so that only admin can see and set it. It is used in the search conditions of the demo 'Featured ads' custom lists to fill those lists with the Gold, Silver and Bronze level featured ads.";
    $featured->searchable = customfield_forAdmin;
    $featured->create();

    // Teszthirdetesek:
    $n = new Item;
    $n->cid = $ecoC->id;
    $n->col_0 = "Susuki Swift";
    $n->col_1 = "4 wheelsssss, 4 seats, low consumpion car for sale, 4 years old, in good condition";
    $n->col_2 = "10";
    $n->col_3 = TRUE;
    $n->col_4 = "5000";
    $n->{$featured->columnIndex}="1,2,3";
    $n->ownerId=10;//$john->id;
    $n->status=1;
    $n->create(TRUE);
    
    $n = new Item;
    $n->cid = $ecoC->id;
    $n->col_0 = "Toyota Yaris";
    $n->col_1 = "3 wheels, 5 seats, high consumpion car for sale, 2 years old, broken";
    $n->col_2 = "20";
    $n->col_3 = FALSE;
    $n->col_4 = "50000";
    $n->ownerId=10;//$john->id;
    $n->status=TRUE;
    $n->{$featured->columnIndex}="1,2,3";
    $n->create(TRUE);

    $n = new Item;
    $n->cid = $ecoC->id;
    $n->col_0 = "Fiat";
    $n->col_1 = "3 seats, metalgreen, high consumpion car for sale, 2 years old, broken";
    $n->col_2 = "12";
    $n->col_3 = TRUE;
    $n->col_4 = "52000";
    $n->ownerId=10;//$james->id;
    $n->status=TRUE;
    $n->{$featured->columnIndex}="1,2,3";
    $n->create(TRUE);

    $n = new Item;
    $n->cid = $carC->id;
    $n->col_0 = "Audi TT";
    $n->col_1 = "4 seats, metal, high consumpion car for sale, 4 years old, broken";
    $n->col_2 = "13";
    $n->col_3 = FALSE;
    $n->col_4 = "6000";
    $n->col_16 = "jpg";
    $n->col_17 = "jpg";
    $n->col_18 = "jpg";
    $n->col_19 = "jpg";
    $n->col_20 = "jpg";
    $n->col_21 = "jpg";
    $n->col_22= "jpg";
    $n->col_23 = "jpg";
    $n->col_24 = "jpg";
    $n->ownerId=10;//$james->id;
    $n->status=TRUE;
    $n->{$featured->columnIndex}="1,2,3";
    $n->create(TRUE);

    $n = new Item;
    $n->cid = $carC->id;
    $n->col_0 = "Ferrari 308";
    $n->col_1 = "2 seats, metalred, high consumpion car for sale, 10 years old, in good condition";
    $n->col_2 = "30";
    $n->col_3 = FALSE;
    $n->col_4 = "54000";
    $n->col_16 = "jpg";
    $n->ownerId=10;//$john->id;
    $n->status=TRUE;
    $n->{$featured->columnIndex}="1,2,3";
    $n->create(TRUE);

    global $item_typ;
    include("item_typ.php");
    $n = new Item;
    $n->cid = $hardC->id;
    $n->col_17 = "Asus motherboard";
    $n->col_18 = "With Intel Pentium 4 processor and integrated sound card";
    $n->col_19 = 0;
    $n->col_20 = "4000";
    $n->ownerId=10;//$john->id;
    $n->status=TRUE;
    $n->{$featured->columnIndex}="1,2,3";
    $n->create(TRUE);

    $n = new Item;
    $n->cid = $hardC->id;
    $n->col_17 = "Matrox G400 video card";
    $n->col_18 = "A very fast card for low price";
    $n->col_19 = 1;
    $n->col_20 = "2000";
    $n->ownerId=10;//$james->id;
    $n->status=TRUE;
    $n->{$featured->columnIndex}="1,2,3";
    $n->create(TRUE);

    $n = new Item;
    $n->cid = $hardC->id;
    $n->col_17 = "Olympus C2000 Zoom digital camera";
    $n->col_18 = "2.1 M, 1600x1200 maxiimal resolution, 3x optical zoom, aperture priority, shutter priority, and more";
    $n->col_19 = 0;
    $n->col_20 = "1000";
    $n->ownerId=10;//$john->id;
    $n->status=TRUE;
    $n->{$featured->columnIndex}="1,2,3";
    $n->create(TRUE);

    include("item_typ.php");
    $n = new Item;
    $n->cid = $menC->id;
    $n->col_17 = "30 years old engineer";
    $n->col_18 = "I am a years old engineer";
    $n->col_19 = 1;
    $n->col_20 = "I am searching for a wife who is good in bed and kitchen";
    $n->col_21 = 1;
    $n->col_16 = "jpg";
    $n->ownerId=10;//$john->id;
    $n->status=TRUE;
    $n->{$featured->columnIndex}="1,2,3";
    $n->create(TRUE);

    $n = new Item;
    $n->cid = $menC->id;
    $n->col_17 = "Don't live me alone!";
    $n->col_18 = "I am very handsome, I have a good job, but I am very shy with women.";
    $n->col_19 = 1;
    $n->col_20 = "I want a girl who chain my heart";
    $n->col_21 = 2;
    $n->col_16 = "jpg";
    $n->ownerId=10;//$john->id;
    $n->status=TRUE;
    $n->{$featured->columnIndex}="1,2,3";
    $n->create(TRUE);

    $n = new Item;
    $n->cid = $womC->id;
    $n->col_17 = "18 years old girl";
    $n->col_18 = "I am a 18 years old girl with nice hair";
    $n->col_19 = 0;
    $n->col_20 = "I am searching for a real men";
    $n->col_21 = 2;
    $n->col_16 = "jpg";
    $n->ownerId=10;//$john->id;
    $n->status=TRUE;
    $n->{$featured->columnIndex}="1,2,3";
    $n->create(TRUE);

    include("item_typ.php");
    $n = new Item;
    $n->cid = $cottC->id;
    $n->ownerId=10;//$john->id;
    $n->status=TRUE;
    $n->col_17 = "Unique Home for Sale by Owner";
    $n->col_18 = "Wood Blinds, tiled main areas and wood floors in rooms. Crown moldings. 4 bedroom 3 bath. Upgraded master bath. Will accept offers.";
    $n->{$featured->columnIndex}="1,2,3";
    $n->create(TRUE);
    
    $n = new Item;
    $n->cid = $cottC->id;
    $n->ownerId=10;//$john->id;
    $n->status=TRUE;
    $n->col_17 = "Land for Sale by Owner";
    $n->col_18 = "The home was designed and constructed in 1998 by the owner on a 150 x 160 landscaped lot to enjoy the panoramic view of the golf course
<br>A 600s/f 12' ceiling patio and a 400s/f sunroom were added in 2003 facing East and the golf course (Hidden from the evening sun) for a total of 3165s/f AC and 5600s/f under roof
 <br>Entertaining is a breeze with two large entertaining areas as the sunroom flows into the large living area, kitchen/dining and the outside patio
 <br>Gleaming hard wood floors, built-in bookshelves, gas fireplace and wet bar compliment the living areas
 <br>The master suite, complete with gas fireplace, has adjoining room to be use as an exercise area, study or additional sleeping area
 <br>A large walk in cedar lined closet adjoins the master bath
 <br>Three bedrooms with two and a half bathrooms. The third bedroom/study features a queen size Murphey bed and built-in book- shelves";
    $n->{$featured->columnIndex}="1,2,3";
    $n->create(TRUE);
    
    $n = new Item;
    $n->cid = $cottC->id;
    $n->ownerId=10;//$john->id;
    $n->status=TRUE;
    $n->col_17 = "Unique Home for Sale by Owner";
    $n->col_18 = "The Oldest Summer Resort in Australia.
<br><br>
Build your trophy home in Waterfall Bay on beautiful Lake Winnettou.
190 feet of water frontage, boathouse with clear, deep water dock. Westerly exposure with million dollar breathtaking sunsets. 180 degree view of lake and mountains, premier location. Walking distance to all amenities. This property is a real gem!
<br><br>
3 million or best offer. For sale by owner. Serious inquiries only. ";
    $n->{$featured->columnIndex}="1,2,3";
    $n->create(TRUE);
    
    $n = new Item;
    $n->cid = $cottC->id;
    $n->ownerId=10;//$john->id;
    $n->status=TRUE;
    $n->col_17 = "Townhouse for Sale by Owner";
    $n->col_18 = "This building has passed all city codes for occupancy for a day care center, 35 kids per shift ages infants to 12 yrs 6:00am to 11:00pm.1,000 sq. ft. of play area, w/new paved lot, five car parking in back, plus handicap stall Land has been added to this building for the parking.Inside 1,300 sq. ft. New air conditioning, heating system, and ventilation. The lower 1654 daycare center have been completely gutted and remodeled The upper 1656 Tenants have been there 10 yrs and is on rent assistant. Have all ten years of maintenance records ";
    $n->{$featured->columnIndex}="1,2,3";
    $n->create(TRUE);
    
    $n = new Item;
    $n->cid = $cottC->id;
    $n->ownerId=10;//$john->id;
    $n->status=TRUE;
    $n->col_17 = "Mix use/Commercial for Sale by Owner";
    $n->col_18 = "WOW! Don't miss this one! Beautiful new condo in a wonderful gated community with full amenities off US1 (Federal) . Close to the beach. Light and Bright. Partial water view. Split Bedrooms with Walk-In Closets. Master Bath with Roman Tub. Large Designer Kitchen with lots of counterspace and GE Appliances. Neutral carpet and tile. Washer/Dryer in unit. Low maintenance includes DSL and Direct TV. Bike to the beach or a short drive to XY Avenue. A great new home or investment property! ";
    $n->{$featured->columnIndex}="1,2,3";
    $n->create(TRUE);
    
    $n = new Item;
    $n->cid = $cottC->id;
    $n->ownerId=10;//$john->id;
    $n->status=TRUE;
    $n->col_17 = "Must See Home for Sale by Owner";
    $n->col_18 = "New hardwood floors throughout 1st floor. Partially finished basement. Newly renovated kitchen and bath. Large wrap-around deck overlooking spacious backyard with Koi Pond! Adjacent subdivided lot for VALUABLE off-street parking and the ability to bulid on. Newer roof and hot water heater. Location close to local park, public transportation, and shopping. ";
    $n->{$featured->columnIndex}="1,2,3";
    $n->create(TRUE);
    
    /*
    for( $i=1; $i<6; $i++)
    {
        $n = new Item;
        $n->cid = $cottC->id;
        $n->ownerId=10;//$john->id;
        $n->status=TRUE;
        $n->col_17 = "Unique Home for Sale by Owner";
        $n->{$featured->columnIndex}="1,2,3";
        $n->create(TRUE);
    }
    */
    if( class_exists('rss') ) Rss::initialize();
    
    // setting up the Custom Lists
    CustomList::addCustomColumns();   
    CustomList::addDefaultCustomLists();   
        
    /*
    G::load( $cats, "select * from category where up=0" );
    $num=20;
    foreach( $cats as $cat )
    {
        for( $i=0; $i<$num; $i++ )
        {
            $c = new AppCategory;
            $c->up = $cat->id;
            $c->name = "Category $i";
            create($c);
            for( $j=0; $j<$num; $j++ )
            {
                $c2 = new AppCategory;
                $c2->up = $c->id;
                $c2->name = "Category $i/$j";
                create($c2);
            }        
        }        
    }
    */
    
}

?>
