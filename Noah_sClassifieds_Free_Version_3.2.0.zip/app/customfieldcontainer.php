<?php
defined('_NOAH') or die('Restricted access');

class CustomFieldContainer extends Object
{

var $fields=0;

// The id that identifies the group of customfields that belongs to this object.
// (In case of Item, this is the "cid" field, in case of User, this is 0)
function getCid()
{
    return 0;
}

// Find a field by columnIndex:
function getField( $which )
{
    $fields = $this->getFields();
    foreach( $fields as $field ) if( $field->columnIndex==$which ) return $field;
}

// Find a field value by name:
function get( $which )
{
    $fields = $this->getFields();
    foreach( $fields as $field ) if( $field->name==$which ) return $this->{$field->columnIndex};
    return "";
}

// Set a field value by name:
function set( $which, $value )
{
    $fields = $this->getFields();
    foreach( $fields as $field ) if( $field->name==$which ) $this->{$field->columnIndex}=$value;
}

function showNewTool($rights)
{
    global $gorumroll, $lll;

    // csak a kategoriahoz tartozo adok listaja eseten tesszuk ki:
    $s="";
    hasAdminRights( $isAdm );
    if( $gorumroll->list==$this->get_class() && $isAdm )
    {
        $ctrl =& new AppController($this->getCustomFieldClass() . "/sortfield_form/$gorumroll->rollid");
        $s=$ctrl->generAnchor($lll["customFields"]);
    }
    return $s;
}

function showListVal($attr)
{
    global $gorumroll, $lll;
    global $gorumuser, $gorumrecognised;

    $s=FALSE;
    if( ($s=parent::showListVal($attr))!==FALSE )
    {
        return $s;
    }
    elseif ($attr=="description") {
        $s=$this->getDescription();
    }
    elseif( $attr=="creationtime" )
    {
        $this->{$attr}->setIgnoreHour(TRUE);
        $s=$this->{$attr}->format();
    }
    elseif( preg_match("/col_\d+/", $attr) || $attr=="id" ) // ha valtozo mezorol van szo
    {
        $typ =& $this->getTypeInfo(TRUE);
        $attrInfo =& $typ["attributes"][$attr];
        $field = $this->getField($attr);
        if( in_array("text", $attrInfo) || in_array("textarea", $attrInfo) )
        {
            if( $this->{$attr}==="" ) $s="";
            else
            {
                if (in_array("allow_html", $attrInfo)) $s=$this->getAttr($attr);
                else  $s=nl2br(htmlspecialchars($this->getAttr($attr)));
                if( $field->subType==customfield_integer && $field->thousandsSeparator )
                {
                    $s = number_format( $s, 0, '', $field->getAttr("thousandsSeparator") );
                }
                if( $field->subType==customfield_float )
                {
                    $s = number_format( $s, $field->precision, $field->getAttr("precisionSeparator"), $field->getAttr("thousandsSeparator") );
                }
                if( $field->formatPrefix ) $s = $field->getAttr("formatPrefix").$s;
                if( $field->formatPostfix ) $s = $s.$field->getAttr("formatPostfix");
                if( $field->format )
                {
                    // ha definialva van egy spec formatum, akkor alkallmazzuk:
                    $s = sprintf( $field->getAttr("format"), $s );
                }
                $this->applyDisplayLengthLimit( $s, $attrInfo );
                if( in_array("titleTag", $attrInfo) && $gorumroll->method == "showhtmllist" )
                {
                    $ctrl =& new AppController($this->get_class() . "/$this->id");
                    $s=$ctrl->generAnchor($s, "", FALSE, "", FALSE);  // no encoding
                }
            }
        }
        elseif( in_array("bool", $attrInfo) )
        {
            $s = $this->{$attr} ? $lll["yes"] : $lll["no"];
        }
        elseif( in_array("url", $attrInfo) )
        {
            // htmlspecialchars nelkul:
            $s = $this->{$attr};
        }
        elseif( in_array("selection", $attrInfo) )
        {
            $s = $lll[$this->get_class()."_$attrInfo[helpindex]_".$this->{$attr}];
        }
        elseif( in_array("multipleselection", $attrInfo) || in_array("checkbox", $attrInfo))
        {
            if(  $this->{$attr}!="" )
            {
                $first = TRUE;
                $vals = split(", *", $this->{$attr});
                foreach( $vals as $val )
                {
                    if( !$first ) $s.=", ";
                    else $first = FALSE;
                    $s.=$lll[$this->get_class()."_$attrInfo[helpindex]_".$val];
                    //TODO: ha az $s-ben 0 van, az valahogy nem jelenik meg a details pagen
                }
            }
        }
        elseif( in_array("media", $attrInfo) )
        {
            if( $this->{$attr} )
            {
                $s="<a href='".$this->getUploadDir()."/$this->id"."_".$this->{$attr}."' target='_blank'>".
                   htmlspecialchars($this->{$attr})."</a>";
            }
            else $s="";
        }
        elseif( in_array("file", $attrInfo) )
        {
            /*
            if( $this->id==4 )
            {
            echo("$attr<br>");
            var_dump($field);
            var_dump($this);
            die();
            }*/
            $picInfo = $this->showPicture($attr);
            $s = $picInfo["tag"];
        }
        elseif( in_array("date", $attrInfo) )
        {
            $this->{$attr}->setIgnoreHour(TRUE);
            $s=$this->{$attr}->format();
        }
        else
        {
            $s=parent::showListVal($attr, "safetext");
        }
    }
    return $s;
}

function applyDisplayLengthLimit( &$s, &$attrInfoOrDisplayLength )
{
    global $gorumroll;
    
    $dl = is_array($attrInfoOrDisplayLength) && isset($attrInfoOrDisplayLength["displaylength"]) ? 
          $attrInfoOrDisplayLength["displaylength"] : (is_array($attrInfoOrDisplayLength) ? 0 : $attrInfoOrDisplayLength);
    if( $dl && $gorumroll->method=="showhtmllist")
    {
        if( strlen($s)>$dl )
        {
            $arr = split(" ", $s);
            $count=0;
            $s="";
            foreach( $arr as $i )
            {
                if( ($count+=strlen($i))<$dl ) $s.="$i ";
                else break;
            }
            $s.="...";
        }
    }
}

function showPicture( $attr, $thSize="medium", $noHref=FALSE )
{
    global $thumbnailSizes, $gorumroll;
    
    $picInfo = array();
    if( !isset($thumbnailSizes[$thSize]) ) $thSize = "medium";
    if( $this->{$attr} )
    {
        $index = split("_", $attr);
        $index = $index[1];
        $picName = $this->getPicDir() . "/{$this->id}_$index.".$this->{$attr};
        if( file_exists($picName) )
        {
            $thName = $this->getPicDir() . "/th_{$thSize}_$this->id"."_$index.".$this->{$attr};
            if( file_exists($thName) || 
                file_exists($thName = $this->getPicDir() . "/th_$this->id"."_$index.".$this->{$attr}) )  // alternative thumbnail naming for 1.3 backward compatibility
            {
                $size = getimagesize( $thName );
                $width = $size[0];
                $height = $size[1];
            }
            else  // no GD
            {
                $thName = $picName;
                shrinkPicture($width, $height,$thumbnailSizes[$thSize]["width"],
                              $thumbnailSizes[$thSize]["height"], $picName );
            }
            if( $thSize=="small" )
            {
                shrinkPicture($largeWidth, $largeHeight,$thumbnailSizes["large"]["width"],
                              $thumbnailSizes["large"]["height"], $picName );
                $dim = "rel='{$largeWidth}x{$largeHeight}'";
            }
            else $dim="";
            $img = "<img src='$thName' width='$width' height='$height' border='0' $dim>";
            if( !$noHref )
            {
                // ha eppen az ad details page-en vagyunk, akkor a kepre kattintva a teljes meretu kep jelenik meg - kulonben az ad details page-e:
                if( $gorumroll->method=="showdetails" && $gorumroll->rollid==$this->id )
                {
                    $s="<a class='picture' href='$picName' target='_blank'>$img</a>";
                }
                else 
                {
                    $ctrl = & new AppController("item/$this->id");
                    $s="<a class='picture' href='".$ctrl->makeUrl()."'>$img</a>";
                }
                if( $gorumroll->method=="showhtmllist" ) $s = "<div class='picture'>$s</div>";
            }
            else $s = $img;
            $picInfo["width"] = $width;
            $picInfo["height"] = $height;
        }
        else $s= $gorumroll->method=="showhtmllist" ? $this->showEmptyPicture() : "";
    }
    else $s= $gorumroll->method=="showhtmllist" ? $this->showEmptyPicture() : "";
    $picInfo["tag"] = $s;
    return $picInfo;
}

function showEmptyPicture()
{
    global $lll;
    return "<div class='picture'>$lll[noPicture]</div>";
}

function setDefaultsOfFieldsThatDontAppearInForm()
{
    $typ =& $this->getTypeInfo(TRUE);
    foreach( $typ["attributes"] as $attr=>$val )
    {
        if( !isset($this->$attr) && isset($val["default"]) ) $this->$attr = $val["default"];
    }
}

function getSpecialSortAttrs()
{
    global $gorumroll;
    
    $sorting = new Sorting($this);
    $sortAttrs = $sorting->getAttrs();
    $s = "";
    foreach( $sortAttrs as $attr )
    {
        if( ($sortType = CustomField::getSortType($gorumroll->rollid, $attr))==customfield_integer )
        {
            $s.= ", 0+n.$attr AS $attr";
        }
        elseif( $sortType==customfield_float ) 
        {
            $s.= ", 0.0+n.$attr AS $attr";
        }
        elseif( $sortType==customfield_date ) 
        {
            $s.= ", IFNULL(CAST(n.$attr AS DATE), '') AS $attr";
        }
    }
    return $s;
}

function activateVariableFields()
{
    global $lll, $defaultPrecisionSeparator, $gorumroll, $item_typ;

    $typ =& $this->getTypeInfo(TRUE);
    hasAdminRights($isAdm);
    if( empty($this->cid ) && $this->get_class()!="user" ) $fields = ItemField::getFixAndCommonFields();
    else $fields = $this->getFields();
    $typ["order"] = array_keys($typ["attributes"]);
    for( $i=0; $i<count($fields); $i++ )
    {
        $v = & $fields[$i];
        // juzer fieldek nem lehetnek formban:
        if( $gorumroll->method=="create" && !empty($v->userField) ) continue; 
        // ha mar benne van, kivesszuk, hogy a sorrend stimmeljen:
        if( ($key=array_search($v->columnIndex, $typ["order"]))!==FALSE ) unset($typ["order"][$key]);
        $typ["order"][]=$v->columnIndex;
        if( !isset($typ["attributes"][$v->columnIndex]) ) $typ["attributes"][$v->columnIndex] = array("type"=>"TEXT");
        $attrInfo = & $typ["attributes"][$v->columnIndex];
        $attrInfo["fieldIndex"] = "$i";
        if( !isset($lll[$lllLabel = $this->get_class()."_$v->columnIndex"]) ) $lll[$lllLabel]=$v->getAttr("name");
        if( $v->mandatory )
        {
            $attrInfo[]="mandatory";
            $attrInfo["min"]="1";
        }
        if( $v->rowspan ) $attrInfo[]="rowspan";
        if( $v->sortable )
        {
            $attrInfo[]="sorta";
            if( $v->subType==customfield_integer || $v->subType==customfield_float ) $attrInfo[]="sortasint";
        }
        if( !$v->displayLabel ) $attrInfo[]="widecontent_details";
        if( $v->detailsPosition!=customfield_normal )
        {
            if( $v->detailsPosition==customfield_topright ) $attrInfo["sidebar"]="top";
            elseif( $v->detailsPosition==customfield_bottomright ) $attrInfo["sidebar"]="bottom";
        }
        if( $v->expl && !isset($lll[$lllLabel = $this->get_class()."_$v->columnIndex"."_expl"]) ) $lll[$lllLabel]=$v->getAttr("expl");
        
        if( $gorumroll->method=="showdetails" ) $v->displayInDetails( $attrInfo, isset($this->ownerId) ? $this->ownerId : 0 );
        elseif( $gorumroll->method=="showhtmllist" ) $v->displayInList( $attrInfo );
        else $v->displayInForm($attrInfo);
        
        switch( $v->type )
        {
        case customfield_text:
            $attrInfo[]="text";
            $attrInfo["default"]=$v->default_text;
            $attrInfo["subtype"]=$v->subType;
            if( $v->format ) $attrInfo["format"]=$v->format;
            if( $v->allowHtml ) $attrInfo[]="allow_html";
            if( $v->seo==customfield_title ) $attrInfo[]="titleTag";
            if( $v->seo==1 ) $attrInfo[]="descriptionTag";
            if( $v->seo==customfield_keywords ) $attrInfo[]="keywordsTag";
            if( $v->displaylength ) $attrInfo["displaylength"]=$v->displaylength;
            if( $v->subType==customfield_integer ) $attrInfo["filterCharacters"]="numeric()";
            if( $v->subType==customfield_float ) $attrInfo["filterCharacters"]="numeric({allow:'$defaultPrecisionSeparator'})";
            break;
        case customfield_textarea:
            $attrInfo[]="textarea";
            $attrInfo["default"]=$v->default_multiple;
            $attrInfo["rows"]=10;
            if( $v->allowHtml ) $attrInfo[]="allow_html";
            if( $v->innewline ) $attrInfo[]="in new line";
            if( $v->displaylength ) $attrInfo["displaylength"]=$v->displaylength;
            if( $v->seo==customfield_title ) $attrInfo[]="titleTag";
            if( $v->seo==customfield_description ) $attrInfo[]="descriptionTag";
            if( $v->seo==customfield_keywords ) $attrInfo[]="keywordsTag";
            if( $v->useMarkitup )
            {
                $attrInfo["markitup"]=array("set"=>"ad_html");
                $attrInfo[]="widecontent_form";
            }
            else $attrInfo["cols"]=50;
            break;
        case customfield_bool:
            $attrInfo[]="bool";
            $attrInfo["default"]=$v->default_bool;
            break;
        case customfield_selection:
            $attrInfo[]="selection";
            $attrInfo["helpindex"]=$v->columnIndex;
            $vals = split(", *", $v->getAttr("values"));
            $valNum = count($vals);
            if( !isset($attrInfo["values"]) )
            {
                for( $j=0; $j<$valNum; $j++ )
                {
                    $attrInfo["values"][]=$j;
                    $lll[$this->get_class()."_$v->columnIndex"."_$j"]=$vals[$j];
                    if( $vals[$j]==$v->getAttr("default_text") ) $attrInfo["default"]="$j";
                }
            }
            break;
        case customfield_multipleselection:
            $attrInfo[]="multipleselection";
            $attrInfo["helpindex"]=$v->columnIndex;
            $vals = split(", *", $v->getAttr("values"));
            $defs = split(", *", $v->getAttr("default_multiple"));
            $valNum = count($vals);
            $attrInfo["size"]=min(10, $valNum);
            $attrInfo["default"]="";
            $first=TRUE;
            $attrInfo["values"]=array();
            for( $j=0; $j<$valNum; $j++ )
            {
                $attrInfo["values"][]=$j;
                if( !isset($lll[$lllLabel = $this->get_class()."_$v->columnIndex"."_$j"]) ) $lll[$lllLabel]=$vals[$j];
                if( in_array($vals[$j], $defs) )
                {
                    if( !$first ) $attrInfo["default"].=",";
                    else $first=FALSE;
                    $attrInfo["default"].=$j;
                }
            }
            break;
        case customfield_checkbox:
            $attrInfo[]="checkbox";
            $attrInfo["helpindex"]=$v->columnIndex;
            $vals = split(", *", $v->getAttr("values"));
            $defs = split(", *", $v->getAttr("default_multiple"));
            $valNum = count($vals);
            $attrInfo["cols"]=$v->checkboxCols;
            $attrInfo["default"]="";
            $first=TRUE;
            $attrInfo["values"]=array();
            for( $j=0; $j<$valNum; $j++ )
            {
                $attrInfo["values"][]=$j;
                if( !isset($lll[$lllLabel = $this->get_class()."_$v->columnIndex"."_$j"]) ) $lll[$lllLabel]=$vals[$j];
                if( in_array($vals[$j], $defs) )
                {
                    if( !$first ) $attrInfo["default"].=",";
                    else $first=FALSE;
                    $attrInfo["default"].=$j;
                }
            }
            break;
        case customfield_separator:
            $attrInfo[]="section";
            $attrInfo["name"]=$v->name;
            $lll[$v->columnIndex] = $v->getAttr("name");
            break;
        case customfield_picture:
            $attrInfo[]="file";
            $attrInfo["name"]=$v->name;
            $lll[$v->columnIndex] = $v->getAttr("name");
            if( !empty($v->mainPicture) ) $attrInfo[]="pictureTag";
            break;
        case customfield_media:
            $attrInfo[]="file";
            $attrInfo[]="media";
            $attrInfo["name"]=$v->name;
            $lll[$v->columnIndex] = $v->getAttr("name");
            break;
        case customfield_url:
            $attrInfo[]="url";
            $attrInfo["length"]=20;
            break;
        case customfield_date:
            $attrInfo["type"]="DATETIME";
            $attrInfo["prototype"]="date";
            $attrInfo["format"]="([0-9]{4})-([0-9]{2})-([0-9]{2})$";
            $attrInfo["order"]=array("year", "month", "day");
            $attrInfo["display_format"]="Y-m-d";
            $attrInfo["length"]=16;
            $attrInfo[]="jscalendar";
            $attrInfo[]="datetext";
            $attrInfo["fromyear"]=$v->fromyear ? $v->fromyear : "now";
            $attrInfo["toyear"]=$v->toyear ? $v->toyear : "now";
            if( $v->dateDefaultNow ) $attrInfo[]="defaultnow";
        default:
            break;
        }
    }
    if( !isset($typ["listOrder"]) ) $typ["listOrder"] = $typ["order"];
}

function hasCaptchaInForm()
{
    if( $ret = $this->hasCaptcha("_form") )
    {
        $typ = & $this->getTypeInfo();
        // ha mar benne van, kivesszuk, hogy a sorrend stimmeljen:
        if( isset($typ["order"]) )
        {
            if( ($key=array_search("captchaField", $typ["order"]))!==FALSE ) unset($typ["order"][$key]);
            $typ["order"][]="captchaField";
        }
    }
    return $ret;
}

function iterateNonUserFieldAndDoSomething( $what )
{
    $typ =& $this->getTypeInfo(TRUE);
    foreach( $this->getFields() as $field )
    {
        if( !empty($field->userField) || !isset($typ["attributes"][$field->columnIndex]) ) continue;
        $attrInfo = & $typ["attributes"][$field->columnIndex];
        // a core fg-nek TRUE-t kell visszaadni az iteracio leallitasara,
        // es ez a fg is TRU-val jelzi, hogy az iteracio felbeszakadt
        if( $ret = $this->$what($attrInfo, $field) ) return TRUE;
    }
}

function delete( $whereFields="" )
{    
    $this->activateVariableFields();
    load($this);
    $this->iterateNonUserFieldAndDoSomething("deleteCore");
    parent::delete($whereFields);
}

function deleteCore( $attrInfo, &$field )
{
    global $thumbnailSizes;
    
    $ind = substr( $field->columnIndex, 4 );
    if( in_array("media", $attrInfo) && $this->{$field->columnIndex}) // ha media tipusu
    {
        $ret=@unlink($this->getUploadDir() . "/{$this->id}_".$this->{$field->columnIndex});
    }
    elseif( in_array("file", $attrInfo) && $this->{$field->columnIndex}) // ha picture tipusu
    {
        $ret=@unlink($this->getPicDir() . "/{$this->id}_$ind.".$this->{$field->columnIndex});
        $ret=@unlink($this->getPicDir() . "/th_{$this->id}_$ind.".$this->{$field->columnIndex});
        foreach( $thumbnailSizes as $thName=>$dimensions )
        {
            $ret=@unlink($this->getPicDir() . "/th_{$thName}_{$this->id}_$ind.".$this->{$field->columnIndex});
        } 
    }
}

function valid()
{
    return $this->iterateNonUserFieldAndDoSomething("validCore");
}

function validCore($attrInfo, &$field)
{
    global $lll;

    if( in_array("file", $attrInfo) ) // ha picture, v. media tipusu
    {
        if( in_array("media", $attrInfo) ) $this->validMedia($field->columnIndex);
        else $this->validPicture($field->columnIndex);
        if( Roll::isFormInvalid() )
        {
            Roll::addInfoText("whichPictureAttribute", $lll[$field->columnIndex]);
            return TRUE;  // to stop iteration
        }
    }
}

function checkMandatoryFileUpload()
{
    return $this->iterateNonUserFieldAndDoSomething("checkMandatoryFileUploadCore");
}

function checkMandatoryFileUploadCore($attrInfo, &$field)
{
    if( in_array("mandatory", $attrInfo) &&
        ((in_array("file", $attrInfo) && empty($_FILES[$field->columnIndex]["name"])) ||
        (in_array("bool", $attrInfo) && !$this->{$field->columnIndex})) )
    {
        Roll::setFormInvalid("mandatoryField", $field->showListVal("name"));
        return TRUE;  // to stop iteration
    }
}

function storeAttachment()
{
    $this->iterateNonUserFieldAndDoSomething("storeAttachmentCore");
}

function storeAttachmentCore($attrInfo, &$field)
{
    if( in_array("file", $attrInfo) ) // ha picture, v. media tipusu
    {
        if( in_array("media", $attrInfo) ) $this->storeOneMedia($field->columnIndex, substr($field->columnIndex, 4));
        else $this->storeOnePicture($field->columnIndex, substr($field->columnIndex, 4));
    }
}

function validPicture($attr)
{
    if (!isset($_FILES[$attr]["name"]) || $_FILES[$attr]["name"]=="") return;
    if ($_FILES[$attr]["size"]==0) return Roll::setFormInvalid("picFileSizeNull");
    if ($_FILES[$attr]["tmp_name"]=="none") return Roll::setFormInvalid("picFileSizeToLarge1");
    if ($this->s->maxPicSize && $_FILES[$attr]["size"]>$this->s->maxPicSize) 
    {
        return Roll::setFormInvalid("picFileSizeToLarge2", $this->s->maxPicSize);
    }
    if (!is_uploaded_file($_FILES[$attr]["tmp_name"]))
    {
        handleError("Possible attack");
    }
    $fname=$_FILES[$attr]["tmp_name"];
    $size = getimagesize( $fname );
    if (!$size) return Roll::setFormInvalid("notValidImageFile");
    $type = $size[2]; // az image tipus, 1=>GIF, 2=>JPG, 3=>PNG
    $extensions = array("", "gif", "jpg", "png");
    if (!isset($extensions[$type]) ) return Roll::setFormInvalid("notValidImageFile");
    if( ($this->s->maxPicWidth && $size[0]>$this->s->maxPicWidth) || ($this->s->maxPicHeight && $size[1]>$this->s->maxPicHeight) )
    {
        return Roll::setFormInvalid("picFileDimensionToLarge", $this->s->maxPicWidth, $this->s->maxPicHeight);
    }
}

function validMedia($attr)
{
    if (!isset($_FILES[$attr]["name"]) || $_FILES[$attr]["name"]=="") return;
    if ($_FILES[$attr]["size"]==0) return Roll::setFormInvalid("picFileSizeNull");
    if ($_FILES[$attr]["tmp_name"]=="none") return Roll::setFormInvalid("picFileSizeToLarge1");
    if ($this->s->maxMediaSize && $_FILES[$attr]["size"]>$this->s->maxMediaSize) 
    {
        return Roll::setFormInvalid("picFileSizeToLarge2", $this->s->maxMediaSize);
    }
    if (!is_uploaded_file($_FILES[$attr]["tmp_name"])) handleError("Possible attack");
}

function storeOnePicture($attr, $i=0)
{
    global $thumbnailSizes;

    if (empty($_FILES[$attr]["name"]) ) return ok;
    $fname=$_FILES[$attr]["tmp_name"];
    if( !($f=fopen($fname,"r")) ) 
    {
        $attErrTxt = "Error opening attached file!";
        return nok;
    }
    // mas fg-eket kell hivni az image tipusnak megfeleloen:
    $create_fg = array("", "ImageCreateFromGIF", "ImageCreateFromJPEG", "ImageCreateFromPNG");
    $save_fg = array("", "ImageGIF", "ImageJPEG", "ImagePNG");
    $extensions = array("", "gif", "jpg", "png");
    $size = getimagesize( $fname );
    $width = $size[0];
    $height = $size[1];
    $type = $size[2]; // az image tipus, 1=>GIF, 2=>JPG, 3=>PNG
    $ext = $extensions[$type];
    $supported=FALSE;
    if( defined("IMG_GIF") && function_exists("ImageTypes"))//van GD
    {
        $checkBits = array(0, IMG_GIF, IMG_JPG, IMG_PNG);
        $supported = isset($checkBits[$type]) && ((ImageTypes() & $checkBits[$type]));
    }
    // ha az adott image tipus supportalva van:
    $memoryLimit = byteStr2num(ini_get('memory_limit'));
    if( $supported )
    {
        foreach( $thumbnailSizes as $thSize=>$dimensions )
        {
            shrinkPicture($newWidth, $newHeight, $dimensions["width"], $dimensions["height"], $fname );
            if( function_exists('memory_get_usage') && $memoryLimit && $memoryLimit!=-1 /* unlimited */ )
            {
                $channels = isset($size['channels']) ? $size['channels'] : 1;  // png has no channels
                $memoryNeeded = Round(($size[0] * $size[1] * $size['bits'] * $channels / 8 + Pow(2, 16)) * 1.65);
                $usage = memory_get_usage();
                // FP::log("Current usage: $usage, limit: $memoryLimit, new to allocate: $memoryNeeded, rest after allocate: ". ($memoryLimit-$usage-$memoryNeeded));
                // skipping if ImageCreate would exceed the memory limit:
                if( $usage + $memoryNeeded > $memoryLimit ) continue;
            }                
            $src_im = $create_fg[$type]($fname);
            $dst_im = ImageCreateTrueColor ($newWidth, $newHeight);
            imagecopyresampled ($dst_im, $src_im, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
            $th_foname = $this->getPicDir() . "/th_{$thSize}_{$this->id}_$i.$ext";   // pictures/ads/th_medium_2345_5.jpg
            $save_fg[$type]( $dst_im, $th_foname );
            imagedestroy($src_im);
        }
    }
    $file = fread($f,$_FILES[$attr]["size"]);
    $foname = $this->getPicDir() . "/$this->id"."_$i.".$ext;
    $fo = fopen($foname,"w");
    //TODO: error handle
    fwrite( $fo,$file);
    fclose( $fo );
    // A picture-ben csak azt taroljuk el, hogy mi a kiterjesztes:
    executeQuery( "UPDATE @" . $this->get_class() . " SET `attr`=#ext# WHERE id=#this->id#", $attr, $ext, $this->id );
    $_FILES[$attr]["name"]="";
}

function storeOneMedia($attr, $i=0)
{
    if (!isset($_FILES[$attr]["name"]) || $_FILES[$attr]["name"]=="") return;
    $tmp=$_FILES[$attr]["tmp_name"];
    $name = $_FILES[$attr]["name"];
    $uploadFile = $this->getUploadDir() . "/$this->id"."_$name";
    if( !move_uploaded_file($tmp, $uploadFile)) return;
    // ha modify-rol van szo, akkor toroljuk a regi media file-t:
    if( isset($this->{"$attr"}) && $this->{"$attr"} )
    {
        @unlink($this->getUploadDir() . "/$this->id"."_".$this->{"$attr"});
    }
    executeQuery( "UPDATE @" . $this->get_class() . " SET `attr`=#name# WHERE id=#this->id#", $attr, $name, $this->id );
    $_FILES[$attr]["name"]="";
}

} // end class

function shrinkPicture(&$width, &$height, $boxWidth, $boxHeight, $pictureFile)
{
    $size = getimagesize( $pictureFile );
    $width = $size[0];
    $height = $size[1];
    if( $width>$boxWidth || $height>$boxHeight )
    {
        $ratio = $width/$boxWidth;
        if( $height/$ratio>$boxHeight ) $ratio=$height/$boxHeight;
        $width = round($width/$ratio);
        $height = round($height/$ratio);
    }
}

?>
