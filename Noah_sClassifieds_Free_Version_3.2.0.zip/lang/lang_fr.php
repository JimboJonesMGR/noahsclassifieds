<?php
// Translation rate: 64%
// (100% means fully translated, 0% means not translated at all)

// If you edit this file, save it in UTF-8 character encoding! 
// Most text editors allow you to select the character encoding you use - even notepad.
// Saving in UTF-8 is important for Noah's Classifieds to be able to display special characters correctly.

// If you make a new translation (or make fixes in an existing one)and want to share 
// your work with other people, too, send us the language file and we will include it 
// in the next release of Noah's.

// You can read more more about the internationalization in the Noah's documentation under:
// http://www.noahsclassifieds.org/documentation/translation

// Content begins:

// Added in 3.1.3:
$lll["cantRegisterUntilLoggedIn"]="You can't register yourself while you are logged in.";


// Added in 3.1.0:
$lll["item_creationtime"]="Created";
$lll["allowedLanguages_ar"]="Arabic";
$lll["defaultLanguage_ar"]="Arabic";
$lll["listNotFound"]="The requested ad list has not been found";
$lll["categorySearch"]="Category search";
$lll["search_cid_expl"]="If you select a category, the page will be refreshed and the custom fields of the given category will be displayed in the search form, too.";
$lll["hasUploaded"]=" has been uploaded";
$lll["search_status"]="Status";
$lll["search_status_-1"]="-- Any --";
$lll["search_status_0"]="Inactive";
$lll["search_status_1"]="Active";
$lll["search_ownerId"]="Owner is";
$lll["search_creationtime_from"]="Created after";
$lll["search_creationtime_to"]="Created before";
$lll["search_expirationTime_from"]="Expires after";
$lll["search_expirationTime_to"]="Expires before";
$lll["adminsettDescription"]="Configure all the global parameters of the program here. This is the highest level admin tool - the one you should start the setup of the program with.";
$lll["contentManagementDescription"]="Customize the layout of the program here and insert new content into the pages. Enable and disable menu points.";
$lll["usersDescription"]="Manage the list of users. Modify or delete them, create custom user fields that appear on the profile pages and in the registration form.";
$lll["customLists"]="Custom lists";
$lll["customListsDescription"]="Set up custom advertisement lists that can be used throughout the program. Customize their columns and the places they appear. Create a featured ads list!";
$lll["date_years"]="years";
$lll["date_months"]="months";
$lll["date_days"]="days";
$lll["date_hours"]="hours";
$lll["date_minutes"]="minutes";
$lll["date_seconds"]="seconds";
$lll["date_ago"]="ago";
$lll["date_fromNow"]="from now";
$lll["rssLatestOfUser"]="Latest %s ads of this user";


// Added in 3.0.0:
$lll["allowedLanguages_tk"]="Turkish";
$lll["defaultLanguage_tk"]="Turkish";
$lll["allowedLanguages_br"]="Brazilian Portuguese";
$lll["defaultLanguage_br"]="Brazilian Portuguese";
$lll["allowedLanguages_pl"]="Polish";
$lll["defaultLanguage_pl"]="Polish";
$lll["cannotAcceptCookieFav"]="Your browser can not accept cookies, you can't add ads to the favorities.";
$lll["unmoderated"]="Unmoderated";
$lll["immediateAppear_expl"]="Disabling this field makes the category moderated: admin has to approve new ads before they appear for the public.";
$lll["usersearch_create_form"]="Search for users";
$lll["user_search_ttitle"]="Search Result";
$lll["isAnyOf"]=" is any of";
$lll["contentManagement"]="Content";
$lll["mainSite"]="Main site";


// Added in 2.4.0:
$lll["invalidEmail"]="Please, enter a valid email address!";
$lll["appcategory_expiration_expl"]="0 means that the ads never expire per default. However, if you enable the expiration override below, the owner of the ad may still choose an arbitrary expiration time!";
$lll["item_expiration_expl_1"]="Leave it blank for never expire";
$lll["item_expiration_expl_2"]="%s days is the maximum you can enter!";


// Added in 2.3.0:
$lll["URL"]="URL";
$lll["captchaField"]="Validate the form by entering the following characters";
$lll["invalidCaptcha"]="Invalid code entered";

$lll["allowedLanguages_en"]="English";
$lll["defaultLanguage_en"]="English";
$lll["allowedLanguages_ru"]="Russian";
$lll["defaultLanguage_ru"]="Russian";
$lll["allowedLanguages_ja"]="Japanese";
$lll["defaultLanguage_ja"]="Japanese";
$lll["allowedLanguages_zh"]="Chinese";
$lll["defaultLanguage_zh"]="Chinese";
$lll["allowedLanguages_it"]="Italian";
$lll["defaultLanguage_it"]="Italian";
$lll["allowedLanguages_es"]="Spanish";
$lll["defaultLanguage_es"]="Spanish";
$lll["allowedLanguages_de"]="German";
$lll["defaultLanguage_de"]="German";
$lll["allowedLanguages_fr"]="French";
$lll["defaultLanguage_fr"]="French";
$lll["allowedLanguages_el"]="Greek";
$lll["defaultLanguage_el"]="Greek";
$lll["allowedLanguages_lt"]="Lithuanian";
$lll["defaultLanguage_lt"]="Lithuanian";
$lll["allowedLanguages_nl"]="Dutch";
$lll["defaultLanguage_nl"]="Dutch";
$lll["allowedLanguages_pt"]="Portuguese";
$lll["defaultLanguage_pt"]="Portuguese";
$lll["allowedLanguages_af"]="Afrikaans";
$lll["defaultLanguage_af"]="Afrikaans";
$lll["allowedLanguages_da"]="Danish";
$lll["defaultLanguage_da"]="Danish";
$lll["allowedLanguages_hu"]="Hungarian";
$lll["defaultLanguage_hu"]="Hungarian";
$lll["allowedLanguages_id"]="Indonesian";
$lll["defaultLanguage_id"]="Indonesian";
$lll["allowedLanguages_sv"]="Swedish";
$lll["defaultLanguage_sv"]="Swedish";
$lll["user_name"]="Nom d'utilisateur";
$lll["user_ttitle"]="Utilisateurs";
$lll["user"]="utilisateur";
$lll["user_newitem"]="Ajouter un nouvel utilisateur";
$lll["email"]="Email";
$lll["user_lastClickTime"]="Dernier click";
$lll["user_passwordCopy"]="Réentrer le mot de passe";
$lll["user_create_form"]="S'enregistrer";
$lll["user_rememberPassword"]="Enregistrer le mot de passe";
$lll["changePassword"]="Changement de mot de passe";
$lll["user_remind_password_form"]="Me rappeler mon mot de passe";
$lll["remind_me_pw"]="J'ai perdu mon mot de passe, merci de m'en envoyer un nouveau par mail!";
$lll["remind_remind_password_form"]="Redonner un mot de passe";
$lll["remindmail_subj"]="Redonner un mot de passe";
$lll["remindmail_text"]="Votre nom d'utilisateur est : %s
Su Votre mot de passe est : %s
Pulse Cliquez sur le lien suivant pour activer le mot de passe, en suite essayer de vous connectez en :
%s

Se Il est recommandé de changer votre mot de passe à la 1 ère connexion.";
$lll["remindmail_sent"]="Un mail vous a été envoyé avec votre nouveau mot de passe";
$lll["remind_username"]="Votre identifiant";
$lll["invalid_email"]="Adresse mail non valide! Il n'y a pas d'utilisateur avec cette adresse mail dans le système.";
$lll["mistypedPassword"]="Vous n'avez pas entré votre mot de passe.";
$lll["passwordTooShort"]="La longueur minimum du mot de passe doit être de %s caractères.";
$lll["userAllreadyExists"]="L'identifiant donné existe déjà.";
$lll["cannotAcceptCookie"]="Votre navigateur n'accepte pas les cookies, vous ne pouvez pas vous enregistrer.";
$lll["wellcomeNewlyRegistered"]="Le nouvel utilisateur %s a été enregistré avec succès.";
$lll["greeting"]="Bonjour, %s!";
$lll["loginInvalid"]="L'identifiant et le mot de passe ne sont pas valides.";
$lll["never"]="Jamais";
$lll["user_login_form"]="Identification";
$lll["user_modify_form"]="Modifier le profil de l'utilisateur";
$lll["goodbye"]="Au revoir %s";
$lll["user_change_password_form"]="Changement de mot de passe";
$lll["passwordModified"]="Le mot de passe a été changé avec succès.";
$lll["timeoutExpired"]="temps dépassé. SVP reconnectez-vous!";
$lll["youWillGetAEmailCheckEmail"]="Vous êtes enregistré avec succès. Vous recevrez bientôt un mail avec votre mot de passe initial.";
$lll["userAllreadyExistsWithEmail"]="Un utilisateur existe déjà avec cette adresse mail.";
$lll["userAllreadyExistsWithName"]="Un utilisateur existe déjà avec cet identifiant.";
$lll["viewAds"]="Click here to view the ads of this user!";
$lll["viewAdsLink"]="Advertisements";
$lll["categories"]="Catégories";
$lll["appcategory"]="Catégorie";
$lll["category_create_form"]="Créer une nouvelle Catégorie";
$lll["category_newitem"]="Créer une nouvelle Catégorie";
$lll["category_modify_form"]="Modifier une catégorie";
$lll["subcats"]="Sous-Catégorie";
$lll["appcategory_allowAd"]="Annonces autorisé";
$lll["appcategory_picture"]="Photos";
$lll["appcategory_ttitle"]="Catégories d'annonce";
$lll["directsubcats"]="Direct Sous-Catégorie";
$lll["directitemnum"]="Direct Annonce";
$lll["appcategory_keywords"]="Keywords";
$lll["appcategory_keywords_expl"]="Used to populate the KEYWORDS meta tag for SEO";
$lll["customAdListTitle"]="Custom item list title";
$lll["customAdListTitle_expl"]="A category specific text that can appear in the header of the ad list instead of 'Advertisements in this category'";
$lll["expiration"]="Ad expiration in days";
$lll["immediateAppear"]="A new ad appears immediatelly";
$lll["mySubscriptions"]="My subscriptions";
$lll["subscription_my_ttitle"]="My subscriptions";
$lll["catSubscriptions"]="Subscriptions on this category";
$lll["subscription_cat_ttitle"]="Subscriptions on this category";
$lll["subscription"]="subscription";
$lll["subscription_create_form"]="Your email address";
$lll["subscription_userName"]="User";
$lll["subscription_catName"]="Category name";
$lll["autoNotifyCat"]="Notify me when new ads are submitted in this category";
$lll["unsubscribeCat"]="Unsubscribe from this category";
$lll["emailMandatory"]="You must supply your email address";
$lll["subscribed"]="You have successfully subscribed to this category.<br>You will be automatically notified by email when a new ad is submitted here.";
$lll["alreadySubscribed"]="You have already subscribed to this category with this email address.";
$lll["unsubscribed"]="You have successfully unsubscribed";
$lll["items"]="Éléments";
$lll["item"]="élément";
$lll["item_create_form"]="Créer un élément";
$lll["item_newitem"]="Ajouter un nouvel élément";
$lll["item_modify_form"]="Modifier un élément ";
$lll["title"]="Title";
$lll["item_ttitle"]=" Éléments ";
$lll["item_my_ttitle_own"]="My Advertisements";
$lll["item_my_ttitle"]="Mes annonces";
$lll["item_cName"]="Catégorie";
$lll["item_cid"]="Catégorie";
$lll["item_clicked"]="Vues";
$lll["item_id"]="ID";
$lll["item_responded"]="Réponses";
$lll["item_expirationTime"]="Jours restant avant expiration";
$lll["keepPrivate"]="Cacher les champs personnels";
$lll["expirationProlonged"]="L'heure d'expiration a été prolongée avec succès.";
$lll["prolongExp"]="Prolonger";
$lll["lastRenewal"]="<br>C'été le dernier renouvellement.";
$lll["item_inactive_title"]="Enregistrement inactif";
$lll["ad_limit_exc"]="La longueur Maximal d'une annonce est %s caractères. Vous avez entré %s caractères! SVP faite une annonce plus courte!";
$lll["item_active"]="Activer";
$lll["item_picture"]="Photo";
// Changed in version 2.4.0. Old text:
//$lll["item_active_ttitle"]="Approved items";
// New text:
//$lll["item_active_ttitle"]="Recent ads";
$lll["item_active_ttitle"]="Recent ads";
$lll["item_inactive_ttitle"]="Annonces en attente";
$lll["approve"]="accepté";
$lll["adApproved"]="L'annonce a été acceptée";
$lll["adScheduled"]="En cours d'acceptation. Vous recevrez un email de confirmation.";
$lll["N/A"]="N/A";
$lll["item_popular_ttitle"]="Liste des annonces les plus consultées.";
$lll["noPicture"]="No Picture";
$lll["adNotFound"]="Advertisement not found";
$lll["selectCategory"]="-- Select category --";
$lll["item_status"]="Status";
$lll["item_status_0"]="Inactive";
$lll["item_status_1"]="Active";
$lll["item_ownerId"]="Owner";
$lll["item_ownerName"]="Owner";
$lll["whichPictureAttribute"]=" - %s";
$lll["selectCategoryNecessary"]="You must select a category";
$lll["new_resp"]="Répondre à cette annonce";
$lll["response_create_form"]="Répondre à cette annonce";
$lll["yourname"]="Votre nom";
$lll["youremail"]="Votre email";
$lll["friendsname"]="Nom de votre ami";
$lll["friendsemail"]="Email de votre ami";
$lll["response_mess"]="Votre message";
$lll["friendmail_mess"]="Votre message";
$lll["mail_sent"]="Nous avons renvoyé votre message à la personne qui a mis cette annonce.";
$lll["mail_fr_sent"]="Nous avons envoyé le message à votre ami.";
$lll["new_frie"]="Envoyer à un ami";
$lll["friendmail_create_form"]=" Envoyer à un ami ";
$lll["move"]="move";
$lll["item_move_form"]="Move item into an other category";
$lll["onlyCompatibleExpl"]="You may only move an ad into an other category if its custom fields are \"compatible\" with the custom fields of the category
                              of this ad! This means if its custom fields has the same type and they are in the same order. If you can't see any other categories
                              in the drop down list, it means there are no compatible categories at all and you can't move the ad than.";
$lll["adMoved"]="The ad has been successfully moved into the new category.";
$lll["removeFavorities"]="remove from favorites";
$lll["addFavorities"]="add to favorites";
$lll["favAdded"]="The ad has been added to your favorites.";
$lll["favRemoved"]="The ad has been removed from your favorites.";
$lll["favorities"]="Favorites";
$lll["item_favorities_ttitle"]="My favorites";
$lll["picFileSizeToLarge1"]="Erreur! Impossible d'ouvrir la photo, ou la taille de la photo peut être trop grande.";
$lll["picFileSizeNull"]="La taille de la photo est nulle.";
$lll["picFileSizeToLarge2"]="La taille de la photo dépasse le maximum de %s bite";
$lll["picFileDimensionToLarge"]="Les dimensions de la photo dépassent le maximum de %s x %s";
$lll["notValidImageFile"]="Le fichier joint n'est pas une image valide(format obligatoire gif ou jpg).";
$lll["cantOpenFile"]="Erreur d'ouverture du fichier joint!";
$lll["cantdelfile"]="Certaines images chargées ne peuvent pas être effacées.";
$lll["advancedSearch"]="Recherche avancée dans une catégorie spécifique :";
$lll["search_relationBetweenFields_1"]="Toutes les conditions";
$lll["search_relationBetweenFields_2"]="Une des conditions";
$lll["search_create_form"]="Rechercher";
$lll["search_relationBetweenFields"]="Rechercher les résultats qui correspondent à";
$lll["search_cid"]="Catégorie";
$lll["allCategories"]="Toutes Catégories";
$lll["item_search_ttitle"]="Résultat de la recherche";
$lll["contains"]=" contenue";
$lll["is"]=" est";
// Changed in version 3.1.0. Old text:
//$lll["any"]="Any";
// New text:
$lll["any"]="-- Any --";
$lll["dateRangeSearchExpl"]="You can search for dates between two given date if you supply both the 'after' and 'before' criteria.<br>You can search for all the dates after a specific date if you supply only the 'after' criteria.<br>You can search for all the dates before a specific date if you supply only the 'before' criteria.";
$lll["isAfter"]=" is after";
$lll["isBefore"]=" is before";
$lll["rangeSearchExpl"]="You can also enter a range of numbers here to search for occurances where %s falls in a certain range. E.g. 20-30";
// Changed in version 3.0.0. Old text:
//$lll["search_str"]="Search anywhere in the ads";
// New text:
//$lll["search_str"]="Simple search";
$lll["search_str"]="Simple search";
$lll["search_autoNotify"]="Notification automatique";
$lll["clickHere"]="Cliquez ici";
$lll["saveSearch"]=" pour sauvegarder cette recherche afin de l'utiliser plus tard!";
$lll["applyAutoNotify"]=" si vous voulez être informé de l'arrivé d'une nouvelle annonce correspondante à votre recherche!";
$lll["viewSavedSearches"]=" pour voir et gérer la liste de vos recherches et notifications sauvegardées!";
$lll["searchNameMustBeFilledOut"]="Vous devez fournir un nom unique pour cette recherche.";
$lll["searchNameExists"]="Le nom de la recherche doit être unique. Vous avez déjà défini une recherche avec ce nom.";
$lll["item_my"]="Mes annonces";
$lll["item_Active"]="Annonces validées";
$lll["item_Inctive"]="Annonces en attente";
$lll["item_recent"]="Annonces récentes";
$lll["item_popular"]="Annonces les plus consultées";
$lll["merchants"]="Merchants";
$lll["category_new"]="Ajouter une catégorie";
$lll["category_del"]="Effacer une catégorie";
$lll["category_mod"]="Modifier une catégorie";
$lll["home"]="Accueil";
$lll["my_profile"]="Mon profil";
$lll["register"]="S'abonner";
$lll["loginDifferrent"]="Changer de connexion";
$lll["login"]="Connexion";
$lll["logout"]="Déconnexion";
$lll["help"]="Aide";
$lll["search"]="Rechercher";
$lll["adminsett"]="Configuration";
$lll["users"]="Utilisateurs";
$lll["ok"]="Ok";
$lll["cancel"]="Annulation";
$lll["back"]="Retour";
$lll["quickhelp"]="Aide";
$lll["emptyList"]="(liste vide)";
$lll["nothingSelected"]="(aucune selection)";
$lll["orSelectConcreteTime"]="ou sélectionnez une heure concrète";
$lll["youMustSelectOne"]="Vous devez sélectionner un élément dans la liste";
$lll["onlyOneCanBeSelected"]="Vous ne pouvez pas choisir plus d'un élément pour cette opération";
$lll["yes"]="Oui";
$lll["no"]="Non";
$lll["linkText"]="Link text";
$lll["permission_denied"]="Permission refusée";
$lll["operation_cancelled"]="Opération annulée";
$lll["create_completed"]="Le nouvel %s a été créé avec succès.";
$lll["modify_completed"]="Le %s a été modifié avec succès.";
$lll["delete_completed"]="Le %s a été effacé avec succès.";
$lll["beforeDelete"]="Voulez-vous réellement supprimer le %s?";
$lll["wrongPasswordToDelete"]="Mauvais mot de passe! SVP, Réessayer encore!";
$lll["mustBeInt"]="Le champ \"%s\" doit être un nombre";
$lll["mustBeFloat"]="Le champ \"%s\" doit être un décimal";
$lll["mustBeGreaterInt"]="Le champ \"%s\" doit être plus grand que ou égal à %s";
$lll["mustBeSmallerInt"]="Le champ \"%s\" doit être plus petit que ou égal à %s";
$lll["mustBeString"]="Le champ \"%s\" doit être Chaîne";
$lll["mustBeGreaterString"]="La longueur du champ \"%s\" doit être au minimum de %s";
$lll["mandatoryField"]="'%s' est un champ obligatoire";
$lll["mustBeSmallerString"]="La longueur du champ \"%s\" doit être au maximum de %s";
$lll["invalidDate"]="La date donnée n'est pas valide";
$lll["spacenoatt"]="Le nom des pièces jointes ne peut pas contenir d'espaces.";
$lll["selectAtLeastOne"]="Au moins %s doivent être selectionnés dans la liste à %s.";
$lll["icon_desc"]="décroissant";
$lll["icon_asc"]="croissant";
$lll["icon_details"]="détails";
$lll["icon_modify"]="modifier";
$lll["icon_delete"]="effacer";
$lll["detail_info"]="%s Détails";
$lll["prev"]="précédent";
$lll["next"]="suivant";
$lll["first"]="premier";
$lll["last"]="dernier";
$lll["allowedThemes_classic"]="Classic";
$lll["defaultTheme_classic"]="Classic";
$lll["allowedThemes_modern"]="Modern";
$lll["defaultTheme_modern"]="Modern";
$lll["changeTheme"]="-- Change theme --";
$lll["changeLanguage"]="-- Change language --";
// Changed in version 3.0.0. Old text:
//$lll["creationtime"]="Created";
// New text:
//$lll["creationtime"]="create_completed";
// Changed in version 3.1.0. Old text:
//$lll["creationtime"]="create_completed";
// New text:
$lll["creationtime"]="Created";
$lll["registerOrLoginToSubmit"]="SVP abonnez-vous ou connectez-vous pour envoyer une annonce!";
$lll["loggedas"]="Vous êtes connecté comme %s.";
$lll["logorreg"]="SVP abonnez-vous ou connectez-vous pour envoyer une annonce.";
$lll["name"]="Nom";
$lll["emptylist"]="La liste est vide";
$lll["popuphelp_tit"]="Aide Popup";
$lll["not_found_in_db"]="Non trouvé dans la DB.";
$lll["deep_struct"]="Erreur de structure d'arborescence,  Trop long ou incorrect.";
$lll["no_father"]="Erreur de structure d'arborescence, le père n'existe pas.";
$lll["not_found_deleted"]="Objet non trouvé, il a peut être été supprimé du système.";
$lll["rssLatest"]="Latest %s ads";
$lll["rssLatestInCategory"]="Latest %s ads in this category";
$lll["pages"]="pages";
?>