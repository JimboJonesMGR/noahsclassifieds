<?php
defined('_NOAH') or die('Restricted access');
// A notificationok applikacionkent fixek. Az installibben kell oket 
// letrehozni. A user nem hozhat letre ujat es nem torolhet ki egyet 
// sem, maximum modosithatja oket

global $notification_typ;
$notification_typ =  
    array(
        "attributes"=>array(   
            "id"=>array(
                "type"=>"INT",
                "form hidden",
            ),    
            "fixRecipent"=>array(
                "type"=>"INT",
                "bool",
                "default"=>"0",
                "form hidden"
            ),    
            "fixCC"=>array(
                "type"=>"INT",
                "bool",
                "default"=>"1",
                "form hidden"
            ),            
            "recipent"=>array(
                "type"=>"VARCHAR",
                "max" =>"255",
                "text",
                "mandatory",
            ),            
            "cc"=>array(
                "type"=>"VARCHAR",
                "max" =>"255",
                "text",
                "details",
            ),            
            "title"=>array(
                "type"=>"VARCHAR",
                "max" =>"120",
                "list",
                "details",
                "form readonly",
                "detailslink",
            ),
            "subject"=>array(
                "type"=>"VARCHAR",
                "max" =>"120",
                "min" =>"1",
                "text",
                "mandatory",
                "details",
                "safetext",
            ),
            "variables"=>array(
                "type"=>"TEXT",
                "details",
                "form readonly",
                "safetext",
            ),
            "body"=>array(  
                "type"=>"TEXT",
                "textarea",
                "cols"=>50,
                "rows"=>5,
                "mandatory",
                "details",
                "safetext_br"
            ),    
            "active"=>array(
                "type"=>"INT",
                "bool",
                "default"=>"1",
                "list",
                "details",
                "yesno"
            ),    
            "langDependent"=>array(
                "type"=>"INT",
                "default"=>"1",
            )
        ),    
        "primary_key"=>"id",
        "sort_criteria_attr"=>"id",
        "sort_criteria_dir"=>"d"
    );

// Egy ilyen objektumban adjuk at a send fuggvenynek azokat a 
// parametereket, amik a kuldeshez szuksegesek:
class SendingParameters
{
    var $to; // ez az egy mandatory
    var $cc;
    var $replyTo;
    var $replyToName;
    
    function SendingParameters()
    {
        $this->to = $this->cc = $this->replyTo = $this->replyToName = "";
    }    
}

class Notification extends Object
{
    function hasObjectRights(&$hasRight, $method, $giveError=FALSE)
    {
        global $lll;
        hasAdminRights($isAdm);
        $hasRight->objectRight = ($isAdm && $method=="modify") || $method=="load";
        $hasRight->generalRight = TRUE;
        if( !$hasRight->objectRight && $giveError )
        {
            handleError($lll["permission_denied"]);
        }
        return ok;
    } 
     
    function showDetailsTool()
    {
        return "";
    }   
     
    function showDetails($whereFields="", $withLoad=TRUE,$headText="")
    {
        global $notification_typ, $gorumroll;
        
        $this->id = $gorumroll->rollid;
        load($this);
        if( $this->fixRecipent )
        {
            $notification_typ["attributes"]["recipent"][]="details";
        }
        else
        {
            $notification_typ["attributes"]["recipent"][]="form invisible";
        }
        parent::showDetails($whereFields, FALSE);
    }
    
    function generForm()
    {
        global $notification_typ, $gorumroll;
        
        if( $this->fixRecipent )
        {
            $notification_typ["attributes"]["recipent"][]="details";
        }
        else
        {
            $notification_typ["attributes"]["recipent"][]="form invisible";
        }
        parent::generForm();
    }
    
    function modify()
    {
        global $notification_typ;
        
        if( $this->fixRecipent )
        {
            $notification_typ["attributes"]["recipent"]["min"]=1;
        }
        parent::modify();
    } 
    
    // param vagy egy SendingParameters objektum, vagy a visszafele
    // kompatibilitas miatt egy string ami a cimzett emailcimet 
    // tartalmazza. Ha egy objektum, akkor magaban foglalja a kuldeshez
    // szukseges osszes parametert - vagyis a cimzetten kivul meg a 
    // 'reply to'-t, a 'cc'-t, stb.
    //
    // param utan meg valtozo szamu tovabbi argumentumot kaphat a 
    // fuggveny - ott jonnek a valtozok, amiket az email szovegbe be 
    // kell helyettesiteni.
    function send( $param )
    {
        global $htmlNotifications, $logNotifications, $ommitNotifications, $language;
        
        $variableNames = explode(", ", $this->variables);
        $variables = func_get_args(); 
        array_shift($variables); // levagjuk a param-ot
        // levagjuk az osszes tobbi parametert es inicializaljuk
        // veluk a valtozokat:
        foreach( $variableNames as $v ) $$v=array_shift($variables);
        
        // a visszafele kompatibilitas miatt, arra az esetre, ha param
        // csak egy string:
        if( !is_object($param) )
        {   
            $p = new SendingParameters;
            $p->to = $param;
            $param = $p;
        }
        
        if( $this->fixRecipent ) $param->to = $this->recipent;
        if( $this->fixCC ) $param->cc = $this->cc;
        // Ha programozott cc is van es db-bol jovo cc is van:
        if( !$this->fixCC && $this->cc ) 
        {
            $param->cc = array($param->cc, $this->cc);
        }    
        
        // Ha a bodyban csak egy html file nev van, akkor betoltjuk es
        // azt vesszuk template-nek:
        if( ereg("\.html$",$this->body) ) 
        {
            $settings =& new AppSettings; 
            if( !$this->langDependent || $language==$settings->defaultLanguage || 
                !(file_exists($fileName = str_replace(".html", "_$language.html", $this->body))) )
            {
                $fileName = $this->body;
            }
            $this->body=join('', file(NOAH_BASE . "/$fileName"));
            if( preg_match( "{<title>(.*)</title>}i", $this->body, $matches ) ) $this->subject = $matches[1];
        }
        // Kulonben nem lehetne eval-ozni:
        $withoutQuote = addcslashes ($this->body, '"');  
        
        // behelyettesitjuk a valtozokat:
        eval ("\$mailText = \"$withoutQuote\";");
        if( $param->replyTo ) $replyTo = $param->replyTo;
        else $replyTo = $this->s->adminEmail;
        if( $param->replyToName ) $replyToName = $param->replyToNamereplyToName;
        else $replyToName = $this->s->adminFromName;
        $from = $this->s->adminEmail;
        $fromName = $this->s->adminFromName;
        $retpath = $param->replyTo ? $param->replyTo : "";
        if( $logNotifications )
        {
            $f = fopen("mailtest.html", "a");
            fputs($f, "<font color='darkgreen'><i>Sending mail: <ul><li>to: $param->to, <li>subject: $this->subject, <li>replyTo: ".htmlspecialchars($replyTo).", <li>from: ".htmlspecialchars($from).", <li>body:</ul></i></font><p><font color='blue'>$mailText</font></p>");
        }
        if( $ommitNotifications ) $err=0;
        else $err = $this->gmail($error, $param->to, $this->subject, $mailText, $fromName, 
                                 $htmlNotifications, $replyTo, $from, $this->cc);
        if( $logNotifications )
        {
            if( $err ) fputs($f, "<font color='red'><i>Error occured during sending the mail</i>: $error</font><br><br>");
            else fputs($f, "<font color='red'><i>Mail sent.</i></font><br><br>");
            fclose($f);
        }
    }
    
    function gmail(&$error, $to, $subject,$body, $fromName="",$html=0,$repto="",$from="", $cc="", $reptoName="")
    {
        global $errorReportingLevel;
        
        require_once GORUM_DIR . "/SwiftMailer/Swift.php";
        
        $settings =& new AppSettings();
        error_reporting(0);
        Swift_Errors::expect($e, "Swift_Exception");
        if( !$repto ) $repto = $from;
        if( $settings->smtpServer )
        {
            require_once GORUM_DIR . "/SwiftMailer/Swift/Connection/SMTP.php";
            if( $settings->fallBackNative )
            {
                require_once GORUM_DIR . "/SwiftMailer/Swift/Connection/NativeMail.php";
                require_once GORUM_DIR . "/SwiftMailer/Swift/Connection/Multi.php";
                $connections = array();
                $conn =& new Swift_Connection_SMTP($settings->smtpServer);
                $conn->setUsername($settings->smtpUser);
                $conn->setPassword($settings->smtpPass);
                if( $e!==null ) 
                {
                    $error = $e->getMessage();
                    return;
                }
                $connections[] =& $conn;
                // Fall back to native mail:
                $connections[] =& new Swift_Connection_NativeMail();
                if( $e!==null ) 
                {
                    $error = $e->getMessage();
                    return;
                }
                $swift =& new Swift(new Swift_Connection_Multi($connections));
            }
            else
            {
                $connection =& new Swift_Connection_SMTP($settings->smtpServer);
                $connection->setUsername($settings->smtpUser);
                $connection->setPassword($settings->smtpPass);
                if( $e!==null ) 
                {
                    $error = $e->getMessage();
                    return;
                }
                $swift =& new Swift($connection);
            }
        }
        else 
        {
            require_once GORUM_DIR . "/SwiftMailer/Swift/Connection/NativeMail.php";
            $swift =& new Swift(new Swift_Connection_NativeMail());
        }
        error_reporting($errorReportingLevel);
        if( $e!==null ) 
        {
            $error = $e->getMessage();
            return;
        }
        else 
        {
            $error="";
            Swift_Errors::clear("Swift_Exception");
        }
         
        $subject  =  str_replace(array("&lt;", "&gt;"), array("<", ">"), $subject);
        
        $charset = "utf-8";
        $message =& new Swift_Message($subject);
        $message->setCharset($charset);
        $part1 = & new Swift_Message_Part($body, "text/html");
        $part1->setCharset($charset);
        $message->attach($part1);
        $part2 = & new Swift_Message_Part(strip_tags($body));
        $part2->setCharset($charset);
        $message->attach($part2);
        $message->setReplyTo(new Swift_Address($repto, $reptoName));
        
        error_reporting(0);
        Swift_Errors::expect($e, "Swift_Exception");
        $recipients = new Swift_RecipientList();
        $recipients->addTo($to);
        if( $this->cc ) $recipients->addCc($this->cc);
        $swift->send($message, $recipients, new Swift_Address($from, $fromName));
        if( $e!==null ) $error = $e->getMessage();
        else 
        {
            $error="";
            Swift_Errors::clear("Swift_Exception");
        }

        $swift->disconnect();
        error_reporting($errorReportingLevel);
    }

}
?>
