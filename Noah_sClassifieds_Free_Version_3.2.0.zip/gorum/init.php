<?php
defined('_NOAH') or die('Restricted access');

class Init
{
function initializeSystemSettings()
{
    global $dbHost, $dbUser, $dbUserPw, $dbName, $includeDumpJs;
    global $gorumroll, $speedStopWatch, $gorumview, $jQueryLib;

    $_GET = filterInput($_GET);
    $_COOKIE = filterInput($_COOKIE);
    $_SERVER = filterInput($_SERVER);
    $_FILES = filterInput($_FILES);
    if( class_exists("speedstat") ) {
        $speedStopWatch = new Stopwatch;
        $speedStopWatch->start();
    }
    ini_set("session.use_cookies", 1);
    ini_set("session.use_only_cookies", 1);
    ini_set("session.use_trans_sid", 0);
	session_start();
    // http://hu.php.net/manual/en/reserved.variables.session.php#85448:
    // azert, hogy az infoTextek ne ragadjanak be:
    if (ini_get('register_globals'))
    {
        foreach ($_SESSION as $key=>$value)
        {
            if (isset($GLOBALS[$key])) unset($GLOBALS[$key]);
        }
    }
    connectDb($dbHost, $dbUser, $dbUserPw, $dbName);
    $gorumroll = new Roll();
    $gorumroll->isAction() ? include(GORUM_DIR . "/gorum_action.php") : include(GORUM_DIR . "/gorum_view.php"); 
    authenticate();
    $this->initializeUserSettings();
    if( class_exists("cronjob") ) executeCronJobs();
    
    if( !$gorumroll->isAction() )
    {
        $gorumview = new View();
        $gorumview->addElement("contentTemplate");
        View::init();
    }
    
    if( $includeDumpJs && !$gorumroll->isAction() )
    {
        JavaScript::addInclude(GORUM_JS_DIR . $jQueryLib);
        JavaScript::addInclude(GORUM_JS_DIR . "/jquery/jquery.dump.js");
        JavaScript::addInclude(GORUM_JS_DIR . "/dump.js");
    }
}

function initializeUserSettings()
{
    global $lll, $emailAccount, $user_typ, $language, $langDir;

    // a megfelelo nyelvi file-okat behozzuk:
    include(LANG_DIR . "/lang_$language.php");
    include(LANG_DIR . "/lang_admin_$language.php");
    if( file_exists(LANG_DIR . "/lang_custom_$language.php") ) include(LANG_DIR . "/lang_custom_$language.php");
    $settings = & new AppSettings;
    if( isset($langDir) ) $settings->langDir = $langDir;
    if( function_exists("postLangInclude") ) postLangInclude();
    if( isset($user_typ["attributes"]["email"]) )
    {
        if( $emailAccount )
        {
            //$user_typ["attributes"]["email"][]="modify_form: readonly";
            $user_typ["attributes"]["name"][]="login_form: form invisible";
            $user_typ["unique_keys"]="email";
            $lll["user_name"]=$lll["user_displayName"];
            $lll["userAllreadyExists"]=$lll["userAllreadyExistsWithName"];
        }
        else
        {
            //$user_typ["attributes"]["name"][]="modify_form: readonly";
            $user_typ["attributes"]["email"][]="login_form: form invisible";
        }
    }
}

function showUserStatus()
{
    global $gorumrecognised,$gorumuser,$lll;
    $s="";
    if ($gorumrecognised) {
       $s.=sprintf($lll["loggedas"],htmlspecialchars($gorumuser->name));
    }
    else $s.=$lll["logorreg"];
    return $s;
}

// Ez a fg hatarozza meg, hogy mely menupont milyen feltetellel lesz
// kirakva. Ha az applikacioban uj menupontokat akarunk felvenni, vagy
// elvenni a menupontokbol, vagy mas feltetelhez kotni a kirakasukat,
// ezt a fg-t kell felulirni
function display( $what )
{
    global $itemClassName, $gorumroll;
    global $gorumrecognised, $fixCss;
    hasAdminRights($isAdm);
    switch( $what )
    {
    case Init_register:
        return !$gorumrecognised;
    case Init_login:
        return !$gorumrecognised;
    case Init_loginDifferent:
        return FALSE;
    case Init_cangePwd:
        return $gorumrecognised;
    case Init_logout:
        return $gorumrecognised;
    case Init_myProfile:
        return $gorumrecognised;
    case Init_search:
        return $gorumrecognised && class_exists("search");
    case Init_home:
        return TRUE;
    case Init_modStyle:
        return $isAdm && !isset($fixCss);
    default:
        return FALSE;
    }
}

// A leszarmazott irja felul:
function getTemplate()
{
}

// A leszarmazott irja felul:
function getTemplateAfter()
{
}

function processMethodCompleted()
{
}

}//End Class
//----------------------------------------------------------------------
function hackImageInput()
{
    if (isset($_POST["cancel_x"]))  $_POST["gsubmit"]="Cancel";//TODO: internacion.
}
//Ez direkt nincs az osztalyban!
function showPopupHelp()
{
    $helpText = $_GET["expl"];
    $helpTitle = $_GET["title"];
    if( function_exists("showAppPopupHelp") )
    {
        showAppPopupHelp($helpTitle, $helpText);
    }
    else
    {
        echo "<center><b>$helpTitle</b></center><br><br>\n";
        echo $helpText;
        die();
    }
}
/*
Ezt a fuggvenyt csak azert nem torlom ki, mert annyira szep!

function regGlob(&$a,$vn,$e="")
{
    foreach($a as $key=>$val) {
        if (is_array($val) && get_magic_quotes_gpc()) {
            regGlob($val,$vn,$e."['$key']");
        }
        else {
            if (get_magic_quotes_gpc()) {
                $command="\$GLOBALS$e"."['$key']=".
                         "stripslashes(\$$vn$e"."['$key']);";
            }
            else {
                $command="\$GLOBALS$e"."['$key']=".
                         "(\$$vn$e"."['$key']);";
            }
            //echo "comm:$command.<br>\n";
            eval($command);
        }
    }
}
*/
?>
