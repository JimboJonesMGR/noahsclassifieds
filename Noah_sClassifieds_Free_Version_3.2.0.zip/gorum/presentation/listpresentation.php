<?php
defined('_NOAH') or die('Restricted access');
if( !isset($gorumlisttemplate) ) $gorumlisttemplate = "default_list.tpl.php";

class ListPresentation extends Presentation
{

var $tableSort;
var $tableFilter;
var $tableRowHighlight;
var $zebraList;

function ListPresentation(&$base, $typ=0)
{
    global $gorumroll, $jQueryLib;
    
    $this->Presentation($base, "list", $typ);
    $this->tableSort = G::getSetting($this->typ, "clientSideTableSort" );
    $this->tableFilter = G::getSetting($this->typ, "clientSideTableFilter", "enable" );
    $this->tableRowHighlight = G::getSetting($this->typ, "tableRowHighlight" );
    $this->zebraList = G::getSetting($this->typ, "zebraList" );
    if( $this->tableSort || $this->tableFilter || $this->tableRowHighlight )
    {
        JavaScript::addInclude(GORUM_JS_DIR . $jQueryLib);
    }
    if( $this->tableSort || $this->tableFilter )
    {
        JavaScript::addInclude(GORUM_JS_DIR . "/jquery/tablesort.js");
        if( $this->tableFilter )
        {
            require_once(GORUM_DIR . "/presentation/filter.php");
            $this->tableFilter =& new Filter($this->typ);
        }
    }
    if( $this->tableRowHighlight )
    {
        JavaScript::addInclude(GORUM_JS_DIR . "/jquery/tablehover.js");
    }
}

function gener(&$view)
{
    $view->setEmpty($isEmpty = parent::gener($view));
    return $isEmpty;
}

function processContent(&$tpl)
{
    global $lll,$colspNum, $headerHeight, $gorumroll, $enableCsvExport ;

    $this->base->loadHtmlList($list);
    if( $tpl->wrapForm = in_array("wrap_form", $this->typ) ) 
    {
        $this->getFormHeader($tpl);
        $this->getFormSubmit( $tpl->submits );
        $tpl->additionalHiddens = $this->base->getAdditionalHiddens($list);
    }
    $this->base->hasGeneralRights($rights);
    if( !in_array("no_pager", $this->typ) ) 
    {
        $pager =& $this->base->getPager();
        $tpl->pager = $pager->showPagerTool();
    }
    else $tpl->pager = "";
    $tpl->footer = "";
    $tpl->listAndMethod = "$gorumroll->list-$gorumroll->method";
    $tpl->zebraList = $this->zebraList;
    if( $this->tableRowHighlight )
    {
        JavaScript::addOnload("$('#$tpl->listAndMethod table').tableHover({rowClass: 'hover-row', clickClass: 'hover-click'});");
    }
    $isEmptyList = !count($list);
    if( $isEmptyList && in_array("empty_list", $this->typ) )
    {
        return 1;  // ezzel azt jelezzuk, a hivo fg-nek, hogy ures sztringgel kell visszaternie rogton
    }
    $tpl->listAndMethod = "$gorumroll->list-$gorumroll->method";
    if( $this->tableSort ) $tpl->tableClass = "table-autosort";
    
    $tpl->headerAttrs = "colspan='$colspNum'";
    $tpl->title = $lll[$gorumroll->list."_ttitle"];
    
    $attributeList = isset($this->typ["listOrder"]) ? $this->typ["listOrder"] : array_keys($this->typ["attributes"]);
    $normalColumnList = array();
    $inNewLineList    = array();
    $rowspanList      = array();
    $colspNum = $colspNumForNewLineRow = 0;
    $rowspNum = 1;
    foreach( $attributeList as $attr ) 
    {
        $val = & $this->typ["attributes"][$attr];
        $isList = in_array("list",$val);
        if( $isList && $isNewLine = in_array("in new line", $val) ) $inNewLineList[]=$attr;
        elseif( $isList && $isRowSpan = in_array("rowspan", $val) ) $rowspanList[]=$attr;
        elseif( $isList )                                           $normalColumnList[]=$attr;
        if( $isList && !$isNewLine) $colspNum++;
        elseif( $isList && $isNewLine ) $rowspNum++;
        if( $isList && !$isNewLine && !in_array("rowspan", $val) ) $colspNumForNewLineRow++;
    }
    // Ezzel atrendezzuk az $attributeList-et ugy, hogy elol legyenek a normal oszlopok, 
    // utana a rowspanos oszlopok es vegul az uj sorba szant oszlopok:
    $attributeList = array_merge($normalColumnList, $rowspanList, $inNewLineList);
    if( !in_array("notools", $this->typ) ) 
    {
        $colspNum++;
        $colspNumForNewLineRow++;
    }
    
    $tpl->headerMethods=array();
    if( $s=$this->base->showNewTool($rights) ) $tpl->headerMethods[]=$s;
    if( $enableCsvExport ) 
    {
        if( $s=$this->base->showCsvExportTool() ) $tpl->headerMethods[]=$s;
    }    

    $tpl->colHeaders=array();
    $tpl->colHeaderAttrs=array();
    $tpl->colHeaderClasses=array();
    $tpl->filterHeaders=array();
    if( !in_array("nocolheaders", $this->typ) ) 
    {
        if( !in_array("notools", $this->typ) ) 
        {
            // ha nincs header, de vannak header methodok, azokat ide ficcantjuk be:
            if( !$tpl->title && count($tpl->headerMethods) ) $tpl->colHeaders[]=implode(" | ", $tpl->headerMethods);
            else $tpl->colHeaders[]="&nbsp;";
            $tpl->colHeaderAttrs[]= isset($headerHeight) ? "height='$headerHeight'" : "";
            $tpl->colHeaderClasses[]="";
            if( $this->tableFilter )
            {
                $tpl->filterHeaders[]="Filter:";
            }
        }
        foreach( $attributeList as $attr )
        {
            $val = & $this->typ["attributes"][$attr];
            if( in_array("in new line", $val) ) continue;
            $lllProp =& new LllProperties( $this->base, $attr );
            $temp = $lllProp->getColHeader();
            if( !$temp ) $temp = $lllProp->getLabel();
            if( $this->tableSort )
            {
                $tpl->colHeaderClasses[] = isset($val["sort"]) ? "table-sortable:".$val["sort"] : "";             
            }
            else
            {
                $temp.=Sorting::showSortTool($this->base, $attr);
                $tpl->colHeaderClasses[] = "";
            }
            $tpl->colHeaders[]=$temp;
            $tpl->colHeaderAttrs[]= isset($headerHeight) ? "nowrap height='$headerHeight'" : "nowrap";
            if( $this->tableFilter )
            {
                if( isset($val["filter"]) )
                {
                    $tpl->filterHeaders[]=$this->tableFilter->generField($val["filter"], $list, $attr);
                }
                else $tpl->filterHeaders[]="";
            }
        }
    }    
    $tpl->listMethods=array();
    $tpl->cells=array();
    $tpl->cellAttrs=array();
    for( $i=0; $i<count($list); $i++ ) 
    {
        $listItem = $list[$i];
        // egy az objektum osztalyaban feluldefinialt fg-el lehetoseget adunk
        // arra, hogy az objektum erteketol fuggoen belemanipulaljunk a 
        // typeInfo-ba:
        $listItem->preprocessRow();
        if( !in_array("notools", $this->typ) )
        {
            $tpl->listMethods[$i]=array();
            $s = $gorumroll->method!="showdetails" ? $listItem->showDetailsTool() : "";
            if( $s ) $tpl->listMethods[$i][]=$s;
            if( $s=$listItem->showModTool($rights) ) $tpl->listMethods[$i][]=$s;
            if( $s=$listItem->showDelTool($rights) ) $tpl->listMethods[$i][]=$s;
        }
        $tpl->cells[$i]     = array();
        $tpl->cellAttrs[$i] = array();
        foreach( $attributeList as $attr )
        {
            $listItem->preprocessCell($this->typ["attributes"][$attr], $attr);
            $val = & $this->typ["attributes"][$attr];
            $props = "";
            if (in_array("centered",$val)) $props.=" align='center'";
            if (in_array("nowrap",$val)) $props.=" nowrap";
            if (isset($val["fixwidth"])) $props.=" width='$val[fixwidth]'";
            if (isset($val["style"])) $props.=" style='$val[style]'";
            if (in_array("alignright",$val)) $props.=" align='right'";
            if (in_array("widecell",$val)) $props.=" width='100%'";
            if (in_array("rowspan",$val)) $props.=" rowspan='$rowspNum'";
            if( in_array("in new line", $val) ) $props.=" colspan='$colspNumForNewLineRow'";
            elseif( in_array("rowspan", $val) ) $props.=" rowspan='$rowspNum'";
            $cellValue = $listItem->showListVal($attr);
            $tpl->cells[$i][]=$cellValue==="" ? "&nbsp;" : $cellValue;
            $tpl->cellAttrs[$i][]=$props;
        }
    }
    if( !in_array("notools", $this->typ) )
    {
        // kitalaljuk, hogy van-e legalabbegy olyan sor, amiben van listMethod:
        $found=FALSE;
        foreach( $tpl->listMethods as $listMethods )
        {
            if( $found = count($listMethods) ) break;
        }
        // ha nincs listMethodos sor, nem kell a legelso ures oszlopot megmutatni:
        if( !$found ) 
        {
            $tpl->listMethods=array();
            array_shift($tpl->colHeaders);
            array_shift($tpl->colHeaderAttrs);
            array_shift($tpl->colHeaderClasses);
            // az eddig beirt colspanokat is csokkenteni kell egyel:
            for( $i=0; $i<count($tpl->cellAttrs); $i++ )
            {
                for( $j=0; $j<count($tpl->cellAttrs[$i]); $j++ )
                {
                    $tpl->cellAttrs[$i][$j] = 
                        preg_replace_callback( 
                            "/(.*colspan=')(\d+)('.*)/", create_function(
                                '$matches',
                                'return $matches[1] . (intval($matches[2])-1) . $matches[3];'
                            ), $tpl->cellAttrs[$i][$j]
                        );
                }                
            }
        }
    }
    if( $tpl->emptyList = $isEmptyList )
    {        
        $tpl->cells[]=array($lll["emptylist"]);
        $tpl->cellAttrs[]=array("align='center' colspan='$colspNum'");
    }
    return ok;
}

} // end class
?>
