<?php
defined('_NOAH') or die('Restricted access');
if( file_exists(NOAH_APP . "/include_action.php") ) include(NOAH_APP . "/include_action.php");
?>
