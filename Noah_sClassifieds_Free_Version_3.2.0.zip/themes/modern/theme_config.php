<?php
global $categoryColumnsNum, $zebraList, $tableRowHighlight, $curvyCorners, $zebraList, $zebraDetails, $tableRowHighlight, $contentSeparator;

// The number of columns the categories are displayed in:
$categoryColumnsNum=4;
// Alternating colors in list rows:
$zebraList=TRUE;
// Rows in lists are highlighted when the cursor is moved over:
$tableRowHighlight="list";
// To make the corners of lists, forms and details panels rounded:
$curvyCorners=TRUE;
// Alternating colors in lists:
$zebraList=TRUE;
// Alternating colors in details panels:
$zebraDetails=TRUE;
// Hover effect on the rows of lists:
$tableRowHighlight="list";
// If a page contains more than one elements - e.g. two forms, they are separated with the below structure to keep some spacing between them:
$contentSeparator = "<p style='height:20px;'>";

class ThemeConfig
{
    
function init()
{
    global $gorumroll;
    
    JavaScript::addInclude(GORUM_JS_DIR . "/jquery/jquery.curvycorners.js");
    JavaScript::addInclude(THEME_DIR . "/javascripts/modern.js");
    if( ($gorumroll->list=="item" || $gorumroll->list=="user") && $gorumroll->method=="showdetails" ) 
    {
        JavaScript::addInclude(GORUM_JS_DIR . "/jquery/jquery.preload.js");
        JavaScript::addOnload("
          $('.smallpic img').preload({
              find:'small',
              replace:'large'
          });
          $('.smallpic a').hover(function(){
              var dim = $(this).find('img').attr('rel').split('x');
              var src = $(this).find('img').attr('src');
              $('.mainpic img').attr({
                  src: src.replace('small','large'),
                  width: dim[0],
                  height: dim[1]
              });
              $('.mainpic a').attr('href', this.href);
          },function(){});
        ");    
    }
}

}
?>
