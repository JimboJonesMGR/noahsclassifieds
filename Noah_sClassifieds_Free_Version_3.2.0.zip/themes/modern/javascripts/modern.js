$(function() {
  // Rounded corners:
  
    $('#userStatusBar').corner({
        tl: { radius: 6 }, 
        tr: { radius: 6 }, 
        bl: { radius: 0 }, 
        br: { radius: 0 },
        autoPad: false}); 
    $('.loginMenu').corner({
        tl: { radius: 4 }, 
        tr: { radius: 4 }, 
        bl: { radius: 4 }, 
        br: { radius: 4 },
        autoPad: false}); 
    $('#infoTextBar').corner({
        tl: { radius: 0 }, 
        tr: { radius: 0 }, 
        bl: { radius: 6 }, 
        br: { radius: 6 },
        autoPad: false}); 
    $('.friend').corner({
        tl: { radius: 4 }, 
        tr: { radius: 4 }, 
        bl: { radius: 4 }, 
        br: { radius: 4 },
        autoPad: false}); 

});
