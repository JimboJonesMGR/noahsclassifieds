<?php
$_POST["list"]="purchase";
$_POST["method"]="silent_post";
include("index.php");
?>
