<?php
$_POST["list"]="purchase";
$_POST["method"]="showhtmllist";
include("index.php");
?>
