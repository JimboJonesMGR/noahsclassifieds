var loadingAnimation = "<img class='loadingAnimation' src='themes/modern/images/loadingAnimation.gif' width=208 height=13 style='border:0px;'>";

