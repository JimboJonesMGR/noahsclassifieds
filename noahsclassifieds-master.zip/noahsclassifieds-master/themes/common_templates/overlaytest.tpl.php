<?php defined('_NOAH') or die('Restricted access'); ?>

<ol style='text-align:left'>
    <li><a rel="#overlay_0" href=''>Egyszeru overlay automatikus ID szamozassal: 0</a></li>
    <li><a rel="#overlay_1" href=''>Egyszeru overlay automatikus ID szamozassal: 1</a><br><br></li>
    
    <li><a rel="#overlay1" href=''>Egyszeru overlay adott ID-vel: 1</a></li>
    <li><a rel="#overlay2" href=''>Egyszeru overlay adott ID-vel: 2</a><br><br></li>
    
    <li><a rel="#overlay5" href=''>Egyszeru sztring-parameteres overlay</a></li>
    <li><a rel="#overlay6" href=''>$lll a sztring-parameterben</a></li>
    <li><a rel="#overlay7" href=''>Controller parameter</a><br><br></li>

    <li><a rel="#overlay8" href=''>$lll a tomb-parameterben</a></li>
    <li><a rel="#overlay9" href=''>Controller a tomb-parameterben</a></li>
    <li><a rel="#overlay10" href=''>Osztalynev-metodus par a content</a></li>
    <li><a rel="#overlay12" href=''>URL a content</a></li>
    <li><a rel="#overlay13" href=''>Relativ URL a content</a><br><br></li>
    
    <li><a rel="#overlay14" href='clonecat/create_form/1'>Ajax a HREF-bol</a><br><br></li>
    
    <li><a rel="#overlay15" href=''>Expose</a><br><br></li>
</ol>
