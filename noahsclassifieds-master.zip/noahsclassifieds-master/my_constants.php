<?php
defined('_NOAH') or die('Restricted access');

// If you want to apply any tweeking on variables that have been set 
// in other configuration files of Noah's 
// (typically in app/constants.php or gorum/constants.php),
// it's a good place to insert them into this file.

// The settings you insert here will overrule those of the other 
// configuration files and because this file won't ever been overwritten 
// by the Noah's updates, your changes remain untouched. 
// (As opposed to this, if you change anything in app/constants.php,
// you must re-do your changes after every update!)

/* Place your variable assignments below this line, but above the trailing ?> tag! */ 

?>
