Markup language: 
Html for the HEAD section

Description:
Special HTML markup set for the HEAD section of an HTML document.

Install:
- Download the zip file
- Unzip it in your markItUp! sets folder
- Modify your JS link to point at this set.js
- Modify your CSS link to point at this style.css