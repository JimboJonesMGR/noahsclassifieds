<?php
defined('_NOAH') or die('Restricted access');
include(NOAH_APP . "/item_detailspresentation.php");
include(NOAH_APP . "/item_listpresentation.php");
include(NOAH_APP . "/staticpage.php");
include_once(NOAH_APP . "/js_css_map.php");
?>
