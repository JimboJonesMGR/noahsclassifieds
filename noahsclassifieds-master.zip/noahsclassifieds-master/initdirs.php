<?php
define( '_NOAH', 1 );

define('NOAH_BASE', "." );
define('NOAH_APP', NOAH_BASE . '/' . 'app' );
$CONFIG_FILE_DIR = NOAH_APP;
?>
